#ifdef WIN32
#include <sys/timeb.h>
#else
#include <unistd.h>
#include <sys/time.h>
#include <sys/times.h>
#endif

void StartClock();
void StopClock();
double TimeElapsed();

extern double fTotalTime;
extern int iSeed;