#include "MaxDegree.h"
#include "Utility.cpp"

unsigned MaxDegree::getTopVtx(unsigned *arrayTop, unsigned numTop){
	unsigned i=0;
	unsigned degree=0;
	vector<pair<unsigned,unsigned> > vtx_degrees;
	vector<pair<unsigned,unsigned> >::const_iterator vpuuiter;	
	set<unsigned>::const_iterator siiter_1;
	set<unsigned>::const_iterator siiter_2;

	set<unsigned> remainVtxSet;
	for(i=0;i<m_numVtx;i++){
		if(m_topVtxSet.count(i))
			continue;
		else 
			remainVtxSet.insert(i);		
	}

	unsigned numtop=min(numTop,unsigned(remainVtxSet.size()));

	if(numtop==0)
		return 0;

	for(siiter_1=remainVtxSet.begin();siiter_1!=remainVtxSet.end();siiter_1++){
		degree=0;
		const set<unsigned> & sources=m_MC_A.getTypeModel().getGraph().getVertex(*siiter_1).getSources();
		const set<unsigned> & targets=m_MC_A.getTypeModel().getGraph().getVertex(*siiter_1).getTargets();
		for(siiter_2=sources.begin();siiter_2!=sources.end();siiter_2++){
			if(remainVtxSet.count(*siiter_2))
				degree++;
		}
		if(!(m_MC_A.getTypeModel().getGraph().isDirected())){//undirected graph
			if(m_MC_A.getTypeModel().getGraph().vtxHasSelfloop(*siiter_1))//the current vertex has selfloop
				degree++;
		}
		else{//directed graph
			for(siiter_2=targets.begin();siiter_2!=targets.end();siiter_2++){
				if(remainVtxSet.count(*siiter_2))
					degree++;
			}
		}
		//if(remainVtxSet.count(*siiter_1)&&m_MC_A.getTypeModel().getGraph().vtxHasSelfloop(*siiter_1))
		//	degree--;
		pair<unsigned,unsigned> pair_vtxno_degree(*siiter_1,degree);
		vtx_degrees.push_back(pair_vtxno_degree);		
	}

	sort(vtx_degrees.begin(),vtx_degrees.end(),Larger_Pair_Second<unsigned,unsigned>());

	unsigned lRange=0;
	unsigned rRange=numtop;
	vpuuiter=vtx_degrees.begin()+numtop-1;
	unsigned degreevalue_numtop=(*vpuuiter).second;
	while((++vpuuiter)!=vtx_degrees.end()){
		if((*vpuuiter).second==degreevalue_numtop)
			rRange++;
		else
			break;
	}
	lRange=rRange-1;
	vpuuiter=vtx_degrees.begin()+rRange-1;
	while(vpuuiter!=vtx_degrees.begin()){
		if((*(--vpuuiter)).second==degreevalue_numtop)
			lRange--;
		else
			break;
	}
	if(rRange==numtop){//output all first "numtop" vertices
		for(i=0,vpuuiter=vtx_degrees.begin();(i<numtop)&&(vpuuiter!=vtx_degrees.end());i++,vpuuiter++){
			arrayTop[i]=(*vpuuiter).first;
			cout<<arrayTop[i]<<"\t"<<(*vpuuiter).second<<endl;
		}
	}
	else{
		vector<unsigned> indicespool;
		unsigned randindex=0;
		unsigned index=0;
		for(i=lRange;i<rRange;i++)
			indicespool.push_back(i);
		for(i=0;i<lRange;i++){
			arrayTop[i]=vtx_degrees[i].first;
			cout<<arrayTop[i]<<"\t"<<vtx_degrees[i].second<<endl;
		}
		for(i=lRange;i<numtop;i++){
			randindex=randN(indicespool.size());
			index=indicespool[randindex];
			indicespool.erase(indicespool.begin()+randindex);
			arrayTop[i]=vtx_degrees[index].first;
			cout<<arrayTop[i]<<"\t"<<vtx_degrees[index].second<<endl;
		}
	}

	return numtop;
}
ostream& MaxDegree::printPhaseResult(ostream& os) const{
	//unsigned i,j;
	os<<"Query Vertex with Max Degree in the Remaining Graph"<<endl;
	/*for(i=0,j=0;i<m_arraysize;i++,j++){
		while(j<m_arrayVtxNo[i]){
			os<<"Node "<<j<<" :\t"<<"Queried"<<"\n";	
			j++;
		}
		os<<"Node "<<m_arrayVtxNo[i]<<" :\t"<<"Not Queried"<<"\n";		
	}
	while(j<m_numVtx){
		os<<"Node "<<j<<" :\t"<<-1.0<<"\n";	
		j++;
	}*/
	return os;
}