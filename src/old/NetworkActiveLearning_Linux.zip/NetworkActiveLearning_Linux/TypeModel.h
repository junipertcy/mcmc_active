#ifndef TYPEMODEL_H
#define TYPEMODEL_H

#include "Graph.h"


class TypeModel{
	friend class MCMC;
public:		
	/*
	-Constructor
	*/
	TypeModel(const Graph & graph, unsigned numtype/*including frozen types*/, set<unsigned> & frozentypes/*frozen types defined in graph*/);
	/*
	-Copy constructor
	*/
	TypeModel(const TypeModel & tm);
	/*
	-Assignment constructor
	*/
	TypeModel & operator=(const TypeModel & tm);
	/*
	-Deconstructor
	*/
	~TypeModel();
public:	
	/*
	-Get the number of types in the model, including frozen types
	*/
	unsigned getNumType() const {/*cout<<m_numType;*/ return m_numType;}
	/*
	-Print the model information
	@input: ostream&=cout
	*/
	ostream& printModelInfo(ostream& = cout) const;
	/*
	-Get the number of active types (the types that vertices can be mutated into) in the model
	*/
	unsigned getNumActiveType() const {return m_numActiveType;}
	/*
	-Get the active type ID with the corresponding index
	@input:  unsigned typeIndex
	@output: unsigned typeID
	*/
	//unsigned getActiveType(unsigned typeindex) const {return m_activeTypeArray[typeindex];}
	/*
	-Check whether the given vertex belongs to some active type
	@input:  unsigned vtxNo
	@output: bool result
	*/
	//bool belongActiveType(unsigned vtxno) const {return m_activeTypeSet.count(m_graph.getVertex(vtxno).getType());}
	/*
	-Check whether the given vertex belongs to some frozen type
	@input:  unsigned vtxNo
	@output: bool result
	*/
	//bool belongFrozenType(unsigned vtxno) const {return m_frozenTypeSet.count(m_graph.getVertex(vtxno).getType());}
	/*
	-Get the graph reference of the type model 
	*/
	const Graph& getGraph() const {return m_graph;}
	unsigned getVtxType(unsigned vtxno) const {return m_vtxTypeTable[vtxno];}
	bool isVtxMutable(unsigned vtxno) const;/* if the vertex is the only vertex in that group, the function return false, otherwise, return true*/
	bool isMTypeFrozen(unsigned mtype) const {
		if(mtype>=m_numActiveType&&mtype<m_numType)
			return true;
		else 
			return false;
	};
	bool isGTypeFrozen(unsigned gtype) const {
		if(m_frozenTypesInGraph.count(gtype)!=0)
			return true;
		else 
			return false;
	};
public:
	
	void initVtxClassifiMatrix();
	void updateVtxClassifiMatrix();
	double ** getVtxClassifiMatrix();
private:
	void initGroupConnMatrix();
	void updateGroupConnMatrix();
	double ** getGroupConnMatrix();
	void randInitGroups();
	void randInitGroups(const set<unsigned>& topVtxSet);
	void randInitGroups(unsigned * vettypetable);
	void mutate(unsigned v,unsigned t);
public:
	vector<set<unsigned> > m_groupSets;
	unsigned * m_vtxTypeTable;
	unsigned * m_groupCardiTable;
	const Graph & m_graph;
	unsigned ** m_numTargetVtxGroup;//m_numTargetVtxGroup[v][i] number of targets that vertex v has in group i
	unsigned ** m_numTargetGroupVtx;//m_numTargetGroupVtx[i][v] number of vertices in group i that has target of vertex v
	unsigned ** m_numEdgesOf2Groups;//m_numEdgesOf2Groups[i][j] number of edges begin from group i, and end at group j
	unsigned * m_groupDegrees;//m_groupDegrees[i] is the sum of degrees of vertices in group i.
	unsigned * m_groupInDegrees;//m_groupInDegrees[i] is the sum of in-degrees of vertices in group i.Only valid for directed graphs.
	unsigned * m_groupOutDegrees;//m_groupDegrees[i] is the sum of out-degrees of vertices in group i.Only valid for directed graphs.
private:	
	unsigned m_numActiveType;
	//unsigned m_numFrozenType;
	unsigned m_numType;
	unsigned m_numVtx;
	//set<unsigned> m_activeTypeSet;
	set<unsigned> m_frozenTypesInGraph;
	map<unsigned,unsigned> m_mapFzntyMty2Gty;
	map<unsigned,unsigned> m_mapFzntyGty2Mty;
	//set<unsigned> m_frozenTypesInModel;
	//vector<unsigned> m_activeTypeArray;	
private:
	double ** groupConnMatrix;
	long long numAccuGCM;
	long long ** lvtxClassifiMatrix;
	double ** dvtxClassifiMatrix;
};

#endif
