#ifndef AVGAGREE_H
#define AVGAGREE_H

#include "Learner.h"

class AvgAgree : public Learner
{
public:
	AvgAgree(MCMC & mca,MCMC & mcb,const set<unsigned> & topVtxSet);
	~AvgAgree(void);
public:
	virtual void resetForNextPhase();	
	virtual void resetForNextInit();
	virtual unsigned getTopVtx(unsigned *arrayTop, unsigned numTop);
	virtual void updateData();
	virtual ostream& printPhaseResult(ostream& = cout) const;
	virtual string getMethodName() const {return m_methodName;}
	virtual unsigned getNumVtx() const {return Learner::getNumVtx();}
	virtual unsigned getNumTypeGraph() const {return Learner::getNumTypeGraph();}
	virtual unsigned getNumTypeModel() const {return Learner::getNumTypeModel();}
private:
	long long * m_avgAgreeNume;
	long long * m_avgAgreeDeno;
	bool m_needInitUpdate;
	set<unsigned> m_agreeVtxSet;
private:
	void initUpdate();
	void updateData_Local();
	void testAgreeNum();
};

#endif
