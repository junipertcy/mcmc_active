#include "MCMC.h"
#include "Utility.cpp"
double MCMC::PI=3.141592653589793;
double MCMC::W_BAR=0.1;

MCMC::MCMC(TypeModel& tm, int blockmodeltype, bool groupcorrected):m_typeModel(tm), m_blockModelType(blockmodeltype), m_groupCorrected(groupcorrected)//,m_bestTypeModel(tm)
{
	unsigned i;
	m_numVtx=tm.getGraph().getNumVtx();
	m_numType=tm.getNumType();

	m_transProbSelect=new double[tm.getNumActiveType()];

	m_maxsizeLogtable=m_numVtx*m_numVtx+1;
	initLogTable(m_maxsizeLogtable);
	initLogGammaTable(2+m_numVtx*m_numVtx);

	m_accumuMargDistri=0;
	m_numAccumuMargDistri=0;

	dvtxClassifiMatrix=new double*[m_numVtx];
	for(i=0;i<m_numVtx;i++){
		dvtxClassifiMatrix[i]=new double[m_numType];		
	}

	m_bestEdgeConnMatrix=new long * [m_numType];
	for(i=0;i<m_numType;i++){
		m_bestEdgeConnMatrix[i]=new long[m_numType];
	}
	m_bestGroupCardi=new long [m_numType];
	m_bestVtxTypeTable=new unsigned [m_numVtx];
	MAXLOGDOUBLE=log(numeric_limits<double>::max())-50;//-50 prevents the accumulation exceeding double limit
	MINLOGDOUBLE=log(numeric_limits<double>::min())+50;//	

	m_LLHVariTable=new double[m_numType];

	
}

MCMC::~MCMC(void)
{
	unsigned i;
	delete [] m_transProbSelect;
	delete [] m_logfactable;
	for(i=0;i<m_numVtx;i++){
		delete [] dvtxClassifiMatrix[i];	
	}
	delete [] dvtxClassifiMatrix;
	for(i=0;i<m_numType;i++){
		delete m_bestEdgeConnMatrix[i];
	}
	if(m_accumuMargDistri!=0){
		for(i=0;i<m_numVtx;i++){
  			delete [] m_accumuMargDistri[i];
		}	
		delete [] m_accumuMargDistri;
		delete [] m_numAccumuMargDistri;
	}
	delete m_bestEdgeConnMatrix;
	delete m_bestGroupCardi;
	delete m_bestVtxTypeTable;
	delete m_LLHVariTable;
}
unsigned MCMC::getTargetType(unsigned mutateVtxNo){
	calcLHVari(mutateVtxNo, m_typeModel);	
	return calcTargetType();
}
void MCMC::calcLHVari(unsigned vtxNo,TypeModel& typeModel){
	m_LHVariPairs.clear();
	bool isDirected=typeModel.getGraph().isDirected();
	if(isDirected&&m_blockModelType==1)
		calcLHVariDM1(vtxNo,typeModel);
	else if(isDirected&&m_blockModelType==2)
		calcLHVariDM2(vtxNo,typeModel);
	else if(isDirected&&m_blockModelType==3)
		calcLHVariDM3(vtxNo,typeModel);
	else if(isDirected&&m_blockModelType==4)
		calcLHVariDM4(vtxNo,typeModel);
	else if(isDirected&&m_blockModelType==5)
		calcLHVariDM5(vtxNo,typeModel);
	else if(isDirected&&m_blockModelType==6)
		calcLHVariDM6(vtxNo,typeModel);
	else if(isDirected&&m_blockModelType==7)
		calcLHVariDM7(vtxNo,typeModel);
	else if(isDirected&&m_blockModelType==8)
		calcLHVariDM8(vtxNo,typeModel);
	else if(!isDirected&&m_blockModelType==1)
		calcLHVariUDM1(vtxNo,typeModel);	
	else if(!isDirected&&m_blockModelType==2)
		calcLHVariUDM2(vtxNo,typeModel);
	else if(!isDirected&&m_blockModelType==3)
		calcLHVariUDM3(vtxNo,typeModel);
	else if(!isDirected&&m_blockModelType==4)
		calcLHVariUDM4(vtxNo,typeModel);
	else if(!isDirected&&m_blockModelType==5)
		calcLHVariUDM3(vtxNo,typeModel);
	else if(!isDirected&&m_blockModelType==6)
		calcLHVariUDM3(vtxNo,typeModel);
	else if(!isDirected&&m_blockModelType==7)
		calcLHVariUDM3(vtxNo,typeModel);
	else if(!isDirected&&m_blockModelType==8)
		calcLHVariUDM3(vtxNo,typeModel);
	else
		cerr<<"unrecognized model type! -- MCMC::calcLHVari()"<<endl;
}
//case 1.1: directed with integral pij model
void MCMC::calcLHVariDM1(unsigned v,TypeModel& typeModel){
	unsigned s,t,o;
	s=typeModel.getVtxType(v);
	unsigned ns=typeModel.m_groupCardiTable[s];
	unsigned nsv=typeModel.m_numTargetGroupVtx[s][v];
	unsigned nvs=typeModel.m_numTargetVtxGroup[v][s];
	bool hasSelfLoop=typeModel.getGraph().hasSelfloop();
	unsigned lvv=0;
	double LHVari;
	if(typeModel.getGraph().vtxHasSelfloop(v))
		lvv=1;
	pair<unsigned,double> lhvariPair(s,0.0);
	m_LHVariPairs.push_back(lhvariPair);
	m_LLHVariTable[s]=0.0;
	for(t=0;t<typeModel.getNumActiveType();t++){
		//t=m_typeModel.getActiveType(t_index);
		if(t==s)
			continue;
		unsigned nt=typeModel.m_groupCardiTable[t];
		if(m_groupCorrected)
			LHVari=(ns-1)*getLog(ns-1)+(nt+1)*getLog(nt+1)-ns*getLog(ns)-nt*getLog(nt);//ns'*log(ns')+nt'*log(nt')-ns*log(ns)-nt*log(nt)
		else
			LHVari=0.0;
		for(o=0;o<m_numType;o++){
			if(o==s||o==t)
				continue;
			//s<->o
			unsigned eso=typeModel.m_numEdgesOf2Groups[s][o];
			unsigned eos=typeModel.m_numEdgesOf2Groups[o][s];
			unsigned nvo=typeModel.m_numTargetVtxGroup[v][o];
			unsigned nov=typeModel.m_numTargetGroupVtx[o][v];
			unsigned no=typeModel.m_groupCardiTable[o];
			LHVari+=getLogDivFac(eso-nvo,eso);
			LHVari+=getLogDivFac(eos-nov,eos);
			LHVari+=2*getLogDivFac(ns*no+1,ns*no-no+1);
			LHVari+=getLogDivFac(ns*no-eso-no+nvo,ns*no-eso);
			LHVari+=getLogDivFac(ns*no-eos-no+nov,ns*no-eos);	
			//t<->o
			unsigned eto=typeModel.m_numEdgesOf2Groups[t][o];
			unsigned eot=typeModel.m_numEdgesOf2Groups[o][t];
			LHVari+=getLogDivFac(eto+nvo,eto);
			LHVari+=getLogDivFac(eot+nov,eot);
			LHVari+=2*getLogDivFac(nt*no+1,nt*no+no+1);
			LHVari+=getLogDivFac(nt*no-eto+no-nvo,nt*no-eto);
			LHVari+=getLogDivFac(nt*no-eot+no-nov,nt*no-eot);
		}
		//s<->t
		unsigned est=typeModel.m_numEdgesOf2Groups[s][t];
		unsigned ets=typeModel.m_numEdgesOf2Groups[t][s];
		unsigned nvt=typeModel.m_numTargetVtxGroup[v][t];
		unsigned ntv=typeModel.m_numTargetGroupVtx[t][v];
		if(hasSelfLoop){
			LHVari+=getLogDivFac(est-nvt+nsv-lvv,est); 
			LHVari+=getLogDivFac(ets-ntv+nvs-lvv,ets);
			LHVari+=2*getLogDivFac(ns*nt+1,(ns-1)*(nt+1)+1);
			LHVari+=getLogDivFac((ns-1)*(nt+1)-est+nvt-nsv+lvv,ns*nt-est);
			LHVari+=getLogDivFac((ns-1)*(nt+1)-ets+ntv-nvs+lvv,ns*nt-ets);
		}else{
			LHVari+=getLogDivFac(est-nvt+nsv,est); 
			LHVari+=getLogDivFac(ets-ntv+nvs,ets);
			LHVari+=2*getLogDivFac(ns*nt+1,(ns-1)*(nt+1)+1);
			LHVari+=getLogDivFac((ns-1)*(nt+1)-est+nvt-nsv,ns*nt-est);
			LHVari+=getLogDivFac((ns-1)*(nt+1)-ets+ntv-nvs,ns*nt-ets);
		}
		//s<->s
		unsigned ess=typeModel.m_numEdgesOf2Groups[s][s];
		if(hasSelfLoop){
			LHVari+=getLogDivFac(ess-nsv-nvs+lvv,ess);
			LHVari+=getLogDivFac(ns*ns+1,(ns-1)*(ns-1)+1);
			LHVari+=getLogDivFac((ns-1)*(ns-1)-ess+nsv+nvs-lvv,ns*ns-ess);
		}else{
			LHVari+=getLogDivFac(ess-nsv-nvs,ess);
			LHVari+=getLogDivFac(ns*(ns-1)+1,(ns-1)*(ns-2)+1);
			LHVari+=getLogDivFac((ns-1)*(ns-2)-ess+nsv+nvs,ns*(ns-1)-ess);
		}
		//t<->t
		unsigned ett=typeModel.m_numEdgesOf2Groups[t][t];
		if(hasSelfLoop){
			LHVari+=getLogDivFac(ett+nvt+ntv+lvv,ett);
			LHVari+=getLogDivFac(nt*nt+1,(nt+1)*(nt+1)+1);
			LHVari+=getLogDivFac((nt+1)*(nt+1)-ett-nvt-ntv-lvv,nt*nt-ett);
		}else{
			LHVari+=getLogDivFac(ett+nvt+ntv,ett);
			LHVari+=getLogDivFac(nt*(nt-1)+1,(nt+1)*nt+1);
			LHVari+=getLogDivFac((nt+1)*nt-ett-nvt-ntv,nt*(nt-1)-ett);
		}
		//
		pair<unsigned,double> lhvariPair(t,LHVari);
		m_LHVariPairs.push_back(lhvariPair);
		m_LLHVariTable[t]=LHVari;
	}
}
//case 1.2: directed with mle pij model
void MCMC::calcLHVariDM2(unsigned v,TypeModel& typeModel){
	unsigned s,t,o;
	s=typeModel.getVtxType(v);
	unsigned ns=typeModel.m_groupCardiTable[s];
	unsigned ns2=ns-1;	
	unsigned nsv=typeModel.m_numTargetGroupVtx[s][v];
	unsigned nvs=typeModel.m_numTargetVtxGroup[v][s];
	bool hasSelfLoop=typeModel.getGraph().hasSelfloop();
	unsigned lvv=0;
	if(typeModel.getGraph().vtxHasSelfloop(v))
		lvv=1;
	double LHVari;
	pair<unsigned,double> lhvariPair(s,0.0);
	m_LHVariPairs.push_back(lhvariPair);
	m_LLHVariTable[s]=0.0;
	for(t=0;t<typeModel.getNumActiveType();t++){
		//t=m_typeModel.getActiveType(t_index);
		if(t==s)
			continue;
		unsigned nt=typeModel.m_groupCardiTable[t];
		if(m_groupCorrected)
			LHVari=(ns-1)*getLog(ns-1)+(nt+1)*getLog(nt+1)-ns*getLog(ns)-nt*getLog(nt);//ns'*log(ns')+nt'*log(nt')-ns*log(ns)-nt*log(nt)
		else
			LHVari=0.0;
		unsigned nt2=nt+1;
		for(o=0;o<m_numType;o++){
			if(o==s||o==t)
				continue;
			//s<->o
			unsigned eso=typeModel.m_numEdgesOf2Groups[s][o];
			unsigned eos=typeModel.m_numEdgesOf2Groups[o][s];
			unsigned nvo=typeModel.m_numTargetVtxGroup[v][o];
			unsigned nov=typeModel.m_numTargetGroupVtx[o][v];
			unsigned no=typeModel.m_groupCardiTable[o];
			unsigned eso2=eso-nvo;	
			unsigned no2=no;
			unsigned eos2=eos-nov;
			///
			if(eso2!=0)
				LHVari+=eso2*(log((double)eso2)-log((double)ns2)-log((double)no2));
			if(ns2*no2-eso2!=0)
				LHVari+=(ns2*no2-eso2)*(log((double)(ns2*no2-eso2))-log((double)ns2)-log((double)no2));
			if(eso!=0)
				LHVari-=eso*(log((double)eso)-log((double)ns)-log((double)no));
			if(ns*no-eso!=0)
				LHVari-=(ns*no-eso)*(log((double)ns*no-eso)-log((double)(ns*no)));
			///
			if(eos2!=0)
				LHVari+=eos2*(log((double)eos2)-log((double)ns2)-log((double)no2));
			if(ns2*no2-eos2!=0)
				LHVari+=(ns2*no2-eos2)*(log((double)(ns2*no2-eos2))-log((double)ns2)-log((double)no2));
			if(eos!=0)
				LHVari-=eos*(log((double)eos)-log((double)ns)-log((double)no));
			if(ns*no-eos!=0)
				LHVari-=(ns*no-eos)*(log((double)ns*no-eos)-log((double)(ns*no)));
			//t<->o
			unsigned eto=typeModel.m_numEdgesOf2Groups[t][o];
			unsigned eot=typeModel.m_numEdgesOf2Groups[o][t];
			unsigned eto2=eto+nvo;	
			unsigned eot2=eot+nov;
			///
			if(eto2!=0)
				LHVari+=eto2*(log((double)eto2)-log((double)nt2)-log((double)no2));
			if(nt2*no2-eto2!=0)
				LHVari+=(nt2*no2-eto2)*(log((double)(nt2*no2-eto2))-log((double)nt2)-log((double)no2));
			if(eto!=0)
				LHVari-=eto*(log((double)eto)-log((double)nt)-log((double)no));
			if(nt*no-eto!=0)
				LHVari-=(nt*no-eto)*(log((double)nt*no-eto)-log((double)(nt*no)));
			///
			if(eot2!=0)
				LHVari+=eot2*(log((double)eot2)-log((double)nt2)-log((double)no2));
			if(nt2*no2-eot2!=0)
				LHVari+=(nt2*no2-eot2)*(log((double)(nt2*no2-eot2))-log((double)nt2)-log((double)no2));
			if(eot!=0)
				LHVari-=eot*(log((double)eot)-log((double)nt)-log((double)no));
			if(nt*no-eot!=0)
				LHVari-=(nt*no-eot)*(log((double)nt*no-eot)-log((double)(nt*no)));
		}
		//s<->t
		unsigned est=typeModel.m_numEdgesOf2Groups[s][t];
		unsigned ets=typeModel.m_numEdgesOf2Groups[t][s];
		unsigned nvt=typeModel.m_numTargetVtxGroup[v][t];
		unsigned ntv=typeModel.m_numTargetGroupVtx[t][v];		
		unsigned est2=est-nvt+nsv;
		unsigned ets2=ets-ntv+nvs;
		if(hasSelfLoop){
			est2-=lvv;
			ets2-=lvv;
		}
		///
		if(est2!=0)
			LHVari+=est2*(log((double)est2)-log((double)ns2)-log((double)nt2));
		if(ns2*nt2-est2!=0)
			LHVari+=(ns2*nt2-est2)*(log((double)(ns2*nt2-est2))-log((double)ns2)-log((double)nt2));
		if(est!=0)
			LHVari-=est*(log((double)est)-log((double)ns)-log((double)nt));
		if(ns*nt-est!=0)
			LHVari-=(ns*nt-est)*(log((double)ns*nt-est)-log((double)(ns*nt)));
		///
		if(ets2!=0)
			LHVari+=ets2*(log((double)ets2)-log((double)ns2)-log((double)nt2));
		if(ns2*nt2-ets2!=0)
			LHVari+=(ns2*nt2-ets2)*(log((double)(ns2*nt2-ets2))-log((double)ns2)-log((double)nt2));
		if(ets!=0)
			LHVari-=ets*(log((double)ets)-log((double)ns)-log((double)nt));
		if(ns*nt-ets!=0)
			LHVari-=(ns*nt-ets)*(log((double)ns*nt-ets)-log((double)(ns*nt)));
		//s<->s
		unsigned ess=typeModel.m_numEdgesOf2Groups[s][s];
		unsigned ess2=0;
		if(hasSelfLoop){
			ess2=ess-nsv-nvs+lvv;
			if(ess2!=0)
				LHVari+=ess2*(log((double)ess2)-log((double)ns2)-log((double)ns2));
			if(ns2*ns2-ess2!=0)
				LHVari+=(ns2*ns2-ess2)*(log((double)(ns2*ns2-ess2))-log((double)ns2)-log((double)ns2));
			if(ess!=0)
				LHVari-=ess*(log((double)ess)-log((double)ns)-log((double)ns));
			if(ns*ns-ess!=0)
				LHVari-=(ns*ns-ess)*(log((double)ns*ns-ess)-log((double)(ns*ns)));
		}
		else{
			ess2=ess-nsv-nvs;
			if(ess2!=0)
				LHVari+=ess2*(log((double)ess2)-log((double)ns2)-log((double)ns2-1));
			if(ns2*(ns2-1)-ess2!=0)
				LHVari+=(ns2*(ns2-1)-ess2)*(log((double)(ns2*(ns2-1)-ess2))-log((double)ns2)-log((double)ns2-1));
			if(ess!=0)
				LHVari-=ess*(log((double)ess)-log((double)ns)-log((double)ns-1));
			if(ns*(ns-1)-ess!=0)
				LHVari-=(ns*(ns-1)-ess)*(log((double)ns*(ns-1)-ess)-log((double)(ns*(ns-1))));
		}
		//t<->t
		unsigned ett=typeModel.m_numEdgesOf2Groups[t][t];
		unsigned ett2=0;
		if(hasSelfLoop){
			ett2=ett+nvt+ntv+lvv;
			if(ett2!=0)
				LHVari+=ett2*(log((double)ett2)-log((double)nt2)-log((double)nt2));
			if(nt2*nt2-ett2!=0)
				LHVari+=(nt2*nt2-ett2)*(log((double)(nt2*nt2-ett2))-log((double)nt2)-log((double)nt2));
			if(ett!=0)
				LHVari-=ett*(log((double)ett)-log((double)nt)-log((double)nt));
			if(nt*nt-ett!=0)
				LHVari-=(nt*nt-ett)*(log((double)nt*nt-ett)-log((double)(nt*nt)));
		}else{
			ett2=ett+nvt+ntv;
			if(ett2!=0)
				LHVari+=ett2*(log((double)ett2)-log((double)nt2)-log((double)nt2-1));
			if(nt2*(nt2-1)-ett2!=0)
				LHVari+=(nt2*(nt2-1)-ett2)*(log((double)(nt2*(nt2-1)-ett2))-log((double)nt2)-log((double)nt2-1));
			if(ett!=0)
				LHVari-=ett*(log((double)ett)-log((double)nt)-log((double)nt-1));
			if(nt*(nt-1)-ett!=0)
				LHVari-=(nt*(nt-1)-ett)*(log((double)nt*(nt-1)-ett)-log((double)(nt*(nt-1))));
		}
		//
		pair<unsigned,double> lhvariPair(t,LHVari);
		m_LHVariPairs.push_back(lhvariPair);
		m_LLHVariTable[t]=LHVari;
	}
}
//case 1.3: directed with degree-corrected block model
void MCMC::calcLHVariDM3(unsigned v,TypeModel& typeModel){
	unsigned s,t,o;
	s=typeModel.getVtxType(v);
	unsigned ns=typeModel.m_groupCardiTable[s];
	//
	unsigned dov=typeModel.m_graph.getVertex(v).getOutDegree();
	unsigned div=typeModel.m_graph.getVertex(v).getInDegree();
	unsigned dos=typeModel.m_groupOutDegrees[s];//out-degree of group s
	unsigned dos2=dos-dov;//out-degree of group s'
	unsigned dis=typeModel.m_groupInDegrees[s];//in-degree of group s
	unsigned dis2=dis-div;//in-degree of group s'
	//	
	unsigned nsv=typeModel.m_numTargetGroupVtx[s][v];
	unsigned nvs=typeModel.m_numTargetVtxGroup[v][s];
	bool hasSelfLoop=typeModel.getGraph().hasSelfloop();
	unsigned lvv=0;
	double LHVari;
	if(typeModel.getGraph().vtxHasSelfloop(v))
		lvv=1;
	pair<unsigned,double> lhvariPair(s,0.0);
	m_LHVariPairs.push_back(lhvariPair);
	m_LLHVariTable[s]=0.0;
	for(t=0;t<typeModel.getNumActiveType();t++){
		//t=m_typeModel.getActiveType(t_index);
		if(t==s)
			continue;
		unsigned nt=typeModel.m_groupCardiTable[t];
		if(m_groupCorrected)
			LHVari=(ns-1)*getLog(ns-1)+(nt+1)*getLog(nt+1)-ns*getLog(ns)-nt*getLog(nt);//ns'*log(ns')+nt'*log(nt')-ns*log(ns)-nt*log(nt)
		else
			LHVari=0.0;
		//
		unsigned dot=typeModel.m_groupOutDegrees[t];//out-degree of group t
		unsigned dot2=dot+dov;//out-degree of group t'
		unsigned dit=typeModel.m_groupInDegrees[t];//in-degree of group t
		unsigned dit2=dit+div;//in-degree of group t'
		//
		for(o=0;o<m_numType;o++){
			if(o==s||o==t)
				continue;
			//
			unsigned doo=typeModel.m_groupOutDegrees[o];//out-degree of group o
			unsigned dio=typeModel.m_groupInDegrees[o];//in-degree of group o
			//s<->o
			unsigned eso=typeModel.m_numEdgesOf2Groups[s][o];
			unsigned eos=typeModel.m_numEdgesOf2Groups[o][s];
			unsigned nvo=typeModel.m_numTargetVtxGroup[v][o];
			unsigned nov=typeModel.m_numTargetGroupVtx[o][v];
			unsigned eso2=eso-nvo;	
			unsigned eos2=eos-nov;
			///
			if(eso2!=0)
				LHVari+=eso2*(getLog(eso2)-getLog(dos2)-getLog(dio));
			if(eso!=0)
				LHVari-=eso*(getLog(eso)-getLog(dos)-getLog(dio));
			///
			if(eos2!=0)
				LHVari+=eos2*(getLog(eos2)-getLog(dis2)-getLog(doo));
			if(eos!=0)
				LHVari-=eos*(getLog(eos)-getLog(dis)-getLog(doo));
			//t<->o
			unsigned eto=typeModel.m_numEdgesOf2Groups[t][o];
			unsigned eot=typeModel.m_numEdgesOf2Groups[o][t];
			unsigned eto2=eto+nvo;	
			unsigned eot2=eot+nov;
			///
			if(eto2!=0)
				LHVari+=eto2*(getLog(eto2)-getLog(dot2)-getLog(dio));
			if(eto!=0)
				LHVari-=eto*(getLog(eto)-getLog(dot)-getLog(dio));
			///
			if(eot2!=0)
				LHVari+=eot2*(getLog(eot2)-getLog(dit2)-getLog(doo));
			if(eot!=0)
				LHVari-=eot*(getLog(eot)-getLog(dit)-getLog(doo));
		}
		//s<->t
		unsigned est=typeModel.m_numEdgesOf2Groups[s][t];
		unsigned ets=typeModel.m_numEdgesOf2Groups[t][s];
		unsigned nvt=typeModel.m_numTargetVtxGroup[v][t];
		unsigned ntv=typeModel.m_numTargetGroupVtx[t][v];		
		unsigned est2=est-nvt+nsv;
		unsigned ets2=ets-ntv+nvs;
		if(hasSelfLoop){
			est2-=lvv;
			ets2-=lvv;
		}
		///
		if(est2!=0)
			LHVari+=est2*(getLog(est2)-getLog(dos2)-getLog(dit2));
		if(est!=0)
			LHVari-=est*(getLog(est)-getLog(dos)-getLog(dit));	
		///
		if(ets2!=0)
			LHVari+=ets2*(getLog(ets2)-getLog(dot2)-getLog(dis2));	
		if(ets!=0)
			LHVari-=ets*(getLog(ets)-getLog(dot)-getLog(dis));
		//s<->s
		unsigned ess=typeModel.m_numEdgesOf2Groups[s][s];
		unsigned ess2=0;
		if(hasSelfLoop){
			ess2=ess-nsv-nvs+lvv;
		}
		else{
			ess2=ess-nsv-nvs;
		}
		if(ess2!=0)
			LHVari+=ess2*(getLog(ess2)-getLog(dos2)-getLog(dis2));
		if(ess!=0)
			LHVari-=ess*(getLog(ess)-getLog(dos)-getLog(dis));
		//t<->t
		unsigned ett=typeModel.m_numEdgesOf2Groups[t][t];
		unsigned ett2=0;
		if(hasSelfLoop){
			ett2=ett+nvt+ntv+lvv;
		}else{
			ett2=ett+nvt+ntv;
		}
		if(ett2!=0)
			LHVari+=ett2*(getLog(ett2)-getLog(dot2)-getLog(dit2));
		if(ett!=0)
			LHVari-=ett*(getLog(ett)-getLog(dot)-getLog(dit));
		//
		pair<unsigned,double> lhvariPair(t,LHVari);
		m_LHVariPairs.push_back(lhvariPair);
		m_LLHVariTable[t]=LHVari;
	}
	//showLHVari();
}
//case 1.4: directed with degree-corrected block model (integrate w_ij)
void MCMC::calcLHVariDM4(unsigned v,TypeModel& typeModel){
	unsigned s,t,o;
	s=typeModel.getVtxType(v);
	unsigned ns=typeModel.m_groupCardiTable[s];
	double b=1+1/W_BAR;
	double log_b=log(b);
	//
	unsigned dov=typeModel.m_graph.getVertex(v).getOutDegree();
	unsigned div=typeModel.m_graph.getVertex(v).getInDegree();
	unsigned dos=typeModel.m_groupOutDegrees[s];//out-degree of group s
	unsigned dos2=dos-dov;//out-degree of group s'
	unsigned dis=typeModel.m_groupInDegrees[s];//in-degree of group s
	unsigned dis2=dis-div;//in-degree of group s'
	//	
	unsigned nsv=typeModel.m_numTargetGroupVtx[s][v];
	unsigned nvs=typeModel.m_numTargetVtxGroup[v][s];
	bool hasSelfLoop=typeModel.getGraph().hasSelfloop();
	unsigned lvv=0;
	double LHVari;
	if(typeModel.getGraph().vtxHasSelfloop(v))
		lvv=1;
	pair<unsigned,double> lhvariPair(s,0.0);
	m_LHVariPairs.push_back(lhvariPair);
	m_LLHVariTable[s]=0.0;
	for(t=0;t<typeModel.getNumActiveType();t++){
		//t=m_typeModel.getActiveType(t_index);
		if(t==s)
			continue;
		unsigned nt=typeModel.m_groupCardiTable[t];
		if(m_groupCorrected)
			LHVari=(ns-1)*getLog(ns-1)+(nt+1)*getLog(nt+1)-ns*getLog(ns)-nt*getLog(nt);//ns'*log(ns')+nt'*log(nt')-ns*log(ns)-nt*log(nt)
		else
			LHVari=0.0;
		//
		unsigned dot=typeModel.m_groupOutDegrees[t];//out-degree of group t
		unsigned dot2=dot+dov;//out-degree of group t'
		unsigned dit=typeModel.m_groupInDegrees[t];//in-degree of group t
		unsigned dit2=dit+div;//in-degree of group t'
		//
		for(o=0;o<m_numType;o++){
			if(o==s||o==t)
				continue;
			//
			unsigned doo=typeModel.m_groupOutDegrees[o];//out-degree of group o
			unsigned doo2=doo;
			unsigned dio=typeModel.m_groupInDegrees[o];//in-degree of group o
			//s<->o
			unsigned dio2=dio;
			unsigned eso=typeModel.m_numEdgesOf2Groups[s][o];
			unsigned eos=typeModel.m_numEdgesOf2Groups[o][s];
			unsigned nvo=typeModel.m_numTargetVtxGroup[v][o];
			unsigned nov=typeModel.m_numTargetGroupVtx[o][v];
			unsigned eso2=eso-nvo;	
			unsigned eos2=eos-nov;
			//s<->o
			LHVari+=getLogFac(eso2)-getLogFac(eso);
			LHVari+=eso*log_b-eso2*log_b;
			LHVari+=eso*(getLog(dos)+getLog(dio))-eso2*(getLog(dos2)+getLog(dio2));
			///
			LHVari+=getLogFac(eos2)-getLogFac(eos);
			LHVari+=eos*log_b-eos2*log_b;
			LHVari+=eos*(getLog(doo)+getLog(dis))-eos2*(getLog(doo2)+getLog(dis2));
			//t<->o
			unsigned eto=typeModel.m_numEdgesOf2Groups[t][o];
			unsigned eot=typeModel.m_numEdgesOf2Groups[o][t];
			unsigned eto2=eto+nvo;	
			unsigned eot2=eot+nov;
			///
			LHVari+=getLogFac(eto2)-getLogFac(eto);
			LHVari+=eto*log_b-eto2*log_b;
			LHVari+=eto*(getLog(dot)+getLog(dio))-eto2*(getLog(dot2)+getLog(dio2));
			///
			LHVari+=getLogFac(eot2)-getLogFac(eot);
			LHVari+=eot*log_b-eot2*log_b;
			LHVari+=eot*(getLog(doo)+getLog(dit))-eot2*(getLog(doo2)+getLog(dit2));
		}
		//s<->t
		unsigned est=typeModel.m_numEdgesOf2Groups[s][t];
		unsigned ets=typeModel.m_numEdgesOf2Groups[t][s];
		unsigned nvt=typeModel.m_numTargetVtxGroup[v][t];
		unsigned ntv=typeModel.m_numTargetGroupVtx[t][v];		
		unsigned est2=est-nvt+nsv;
		unsigned ets2=ets-ntv+nvs;
		if(hasSelfLoop){
			est2-=lvv;
			ets2-=lvv;
		}
		///
		LHVari+=getLogFac(est2)-getLogFac(est);
		LHVari+=est*log_b-est2*log_b;
		LHVari+=est*(getLog(dos)+getLog(dit))-est2*(getLog(dos2)+getLog(dit2));
		///
		LHVari+=getLogFac(ets2)-getLogFac(ets);
		LHVari+=ets*log_b-ets2*log_b;
		LHVari+=ets*(getLog(dot)+getLog(dis))-ets2*(getLog(dot2)+getLog(dis2));
		//s<->s
		unsigned ess=typeModel.m_numEdgesOf2Groups[s][s];
		unsigned ess2=0;
		if(hasSelfLoop){
			ess2=ess-nsv-nvs+lvv;
		}
		else{
			ess2=ess-nsv-nvs;
		}
		LHVari+=getLogFac(ess2)-getLogFac(ess);
		LHVari+=ess*log_b-ess2*log_b;
		LHVari+=ess*(getLog(dos)+getLog(dis))-ess2*(getLog(dos2)+getLog(dis2));
		//t<->t
		unsigned ett=typeModel.m_numEdgesOf2Groups[t][t];
		unsigned ett2=0;
		if(hasSelfLoop){
			ett2=ett+nvt+ntv+lvv;
		}else{
			ett2=ett+nvt+ntv;
		}
		LHVari+=getLogFac(ett2)-getLogFac(ett);
		LHVari+=ett*log_b-ett2*log_b;
		LHVari+=ett*(getLog(dot)+getLog(dit))-ett2*(getLog(dot2)+getLog(dit2));
		//
		pair<unsigned,double> lhvariPair(t,LHVari);
		m_LHVariPairs.push_back(lhvariPair);
		m_LLHVariTable[t]=LHVari;
	}
	//showLHVari();
}
//case 1.5: directed with degree-corrected block model (weighted orientation)
void MCMC::calcLHVariDM5(unsigned v,TypeModel& typeModel){
	unsigned s,t,o;
	s=typeModel.getVtxType(v);
	unsigned ns=typeModel.m_groupCardiTable[s];
	unsigned kv=typeModel.getGraph().getVtxDegree(v);//degree of vertex v
	unsigned nvs=typeModel.m_numTargetVtxGroup[v][s];
	unsigned ks=typeModel.m_groupDegrees[s];//degree of group s
	unsigned ks2=ks-kv;//degree of group s'
	bool hasSelfLoop=typeModel.getGraph().hasSelfloop();
	unsigned lvv=0;
	double LHVari;
	if(typeModel.getGraph().vtxHasSelfloop(v))
		lvv=1;
	pair<unsigned,double> lhvariPair(s,0.0);
	m_LHVariPairs.push_back(lhvariPair);
	m_LLHVariTable[s]=0.0;
	for(t=0;t<typeModel.getNumActiveType();t++){
		//t=m_typeModel.getActiveType(t_index);
		if(t==s)
			continue;
		unsigned nt=typeModel.m_groupCardiTable[t];
		if(m_groupCorrected)
			LHVari=(ns-1)*getLog(ns-1)+(nt+1)*getLog(nt+1)-ns*getLog(ns)-nt*getLog(nt);//ns'*log(ns')+nt'*log(nt')-ns*log(ns)-nt*log(nt)
		else
			LHVari=0.0;
		unsigned kt=typeModel.m_groupDegrees[t];//degree of group t
		unsigned kt2=kt+kv;//degree of group t'
		for(o=0;o<m_numType;o++){
			if(o==s||o==t)
				continue;
			//s<->o
			unsigned eso_out=typeModel.m_numEdgesOf2Groups[s][o];	//eso_out
			unsigned eso_in=typeModel.m_numEdgesOf2Groups[o][s];	//eso_in
			unsigned eso=eso_out+eso_in;//total number of edges between s and o			
			unsigned nvo=typeModel.m_numTargetVtxGroup[v][o];
			unsigned eso2_out=eso_out-nvo;	//eso2_out
			unsigned nov=typeModel.m_numTargetGroupVtx[o][v];
			unsigned eso2_in=eso_in-nov;	//eso2_in			
			unsigned eso2=eso2_out+eso2_in;////total number of edges between s and o after mutation
			unsigned ko=typeModel.m_groupDegrees[o];//degree of group o
			//			
			LHVari+=eso2*(getLog(eso2)-getLog(ks2)-getLog(ko));
			LHVari-=eso*(getLog(eso)-getLog(ks)-getLog(ko));	
			//
			LHVari+=m_dfac*eso2_out*(getLog(eso2_out)-getLog(eso2));
			LHVari+=m_dfac*eso2_in*(getLog(eso2_in)-getLog(eso2));
			LHVari-=m_dfac*eso_out*(getLog(eso_out)-getLog(eso));
			LHVari-=m_dfac*eso_in*(getLog(eso_in)-getLog(eso));
			//t<->o
			unsigned eto_out=typeModel.m_numEdgesOf2Groups[t][o];	//eto_out
			unsigned eto_in=typeModel.m_numEdgesOf2Groups[o][t];	//eto_in
			unsigned eto=eto_out+eto_in;//total number of edges between t and o			
			unsigned eto2_out=eto_out+nvo;	//eto2_out
			unsigned eto2_in=eto_in+nov;	//eto2_in			
			unsigned eto2=eto2_out+eto2_in;////total number of edges between t and o after mutation
			LHVari+=eto2*(getLog(eto2)-getLog(kt2)-getLog(ko));
			LHVari-=eto*(getLog(eto)-getLog(kt)-getLog(ko));		
			//
			LHVari+=m_dfac*eto2_out*(getLog(eto2_out)-getLog(eto2));
			LHVari+=m_dfac*eto2_in*(getLog(eto2_in)-getLog(eto2));
			LHVari-=m_dfac*eto_out*(getLog(eto_out)-getLog(eto));
			LHVari-=m_dfac*eto_in*(getLog(eto_in)-getLog(eto));
		}
		//s<->t
		unsigned est_out=typeModel.m_numEdgesOf2Groups[s][t];
		unsigned est_in=typeModel.m_numEdgesOf2Groups[t][s];
		unsigned est=est_out+est_in;
		unsigned nvt=typeModel.m_numTargetVtxGroup[v][t];
		unsigned ntv=typeModel.m_numTargetGroupVtx[t][v];
		unsigned nsv=typeModel.m_numTargetGroupVtx[s][v];
		unsigned nvs=typeModel.m_numTargetVtxGroup[v][s];
		unsigned est2_out=est_out-nvt+nsv-lvv;
		unsigned est2_in=est_in-ntv+nvs-lvv;
		unsigned est2=est2_out+est2_in;	
		LHVari+=est2*(getLog(est2)-getLog(ks2)-getLog(kt2));
		LHVari-=est*(getLog(est)-getLog(ks)-getLog(kt));
		LHVari+=m_dfac*est2_out*(getLog(est2_out)-getLog(est2));
		LHVari+=m_dfac*est2_in*(getLog(est2_in)-getLog(est2));
		LHVari-=m_dfac*est_out*(getLog(est_out)-getLog(est));
		LHVari-=m_dfac*est_in*(getLog(est_in)-getLog(est));
		//s<->s
		unsigned ess=typeModel.m_numEdgesOf2Groups[s][s];
		unsigned ess2=ess-nvs-nsv+lvv;
		LHVari+=ess2*(getLog((2*ess2))-getLog(ks2)-getLog(ks2));
		LHVari-=ess*(getLog((2*ess))-getLog(ks)-getLog(ks));	
		LHVari-=m_dfac*ess2*getLog(2);
		LHVari+=m_dfac*ess*getLog(2);
		//t<->t
		unsigned ett=typeModel.m_numEdgesOf2Groups[t][t];
		unsigned ett2=ett+nvt+ntv+lvv;
		LHVari+=ett2*(getLog((2*ett2))-getLog(kt2)-getLog(kt2));
		LHVari-=ett*(getLog((2*ett))-getLog(kt)-getLog(kt));	
		LHVari-=m_dfac*ett2*getLog(2);
		LHVari+=m_dfac*ett*getLog(2);
		//
		pair<unsigned,double> lhvariPair(t,LHVari);
		m_LHVariPairs.push_back(lhvariPair);
		m_LLHVariTable[t]=LHVari;
	}
}
//case 1.6: directed with degree-corrected block model (test 02, w_ij)
void MCMC::calcLHVariDM6(unsigned v,TypeModel& typeModel){
	unsigned s,t,o;
	s=typeModel.getVtxType(v);
	unsigned ns=typeModel.m_groupCardiTable[s];
	unsigned kv=typeModel.getGraph().getVtxDegree(v);//degree of vertex v
	unsigned nvs=typeModel.m_numTargetVtxGroup[v][s];
	unsigned nsv=typeModel.m_numTargetGroupVtx[s][v];
	unsigned ks=typeModel.m_groupDegrees[s];//degree of group s
	unsigned ks2=ks-kv;//degree of group s'
	bool hasSelfLoop=typeModel.getGraph().hasSelfloop();
	unsigned lvv=0;
	double LHVari;
	if(typeModel.getGraph().vtxHasSelfloop(v))
		lvv=1;
	pair<unsigned,double> lhvariPair(s,0.0);
	m_LHVariPairs.push_back(lhvariPair);
	m_LLHVariTable[s]=0.0;
	for(t=0;t<typeModel.getNumActiveType();t++){
		//t=m_typeModel.getActiveType(t_index);
		if(t==s)
			continue;
		unsigned nt=typeModel.m_groupCardiTable[t];
		if(m_groupCorrected)
			LHVari=(ns-1)*getLog(ns-1)+(nt+1)*getLog(nt+1)-ns*getLog(ns)-nt*getLog(nt);//ns'*log(ns')+nt'*log(nt')-ns*log(ns)-nt*log(nt)
		else
			LHVari=0.0;
		unsigned kt=typeModel.m_groupDegrees[t];//degree of group t
		unsigned kt2=kt+kv;//degree of group t'
		for(o=0;o<m_numType;o++){
			if(o==s||o==t)
				continue;
			//s<->o
			unsigned eso=typeModel.m_numEdgesOf2Groups[s][o];//total number of edges between s and o		
			unsigned eos=typeModel.m_numEdgesOf2Groups[o][s];//total number of edges between o and s		
			unsigned nvo=typeModel.m_numTargetVtxGroup[v][o];
			unsigned nov=typeModel.m_numTargetGroupVtx[o][v];		
			unsigned eso2=eso-nvo;//total number of edges between s and o after mutation
			unsigned eos2=eos-nov;//total number of edges between o and s after mutation
			unsigned ko=typeModel.m_groupDegrees[o];//degree of group o
			//			
			LHVari+=eso2*(getLog(eso2)-getLog(ks2)-getLog(ko));
			LHVari-=eso*(getLog(eso)-getLog(ks)-getLog(ko));	
			LHVari+=eos2*(getLog(eos2)-getLog(ks2)-getLog(ko));
			LHVari-=eos*(getLog(eos)-getLog(ks)-getLog(ko));	
			//
			//t<->o
			unsigned eto=typeModel.m_numEdgesOf2Groups[t][o];	//eto
			unsigned eot=typeModel.m_numEdgesOf2Groups[o][t];	//eot
			unsigned eto2=eto+nvo;//total number of edges between t and o after mutation					
			unsigned eot2=eot+nov;//total number of edges between o and t after mutation
			LHVari+=eto2*(getLog(eto2)-getLog(kt2)-getLog(ko));
			LHVari-=eto*(getLog(eto)-getLog(kt)-getLog(ko));	
			LHVari+=eot2*(getLog(eot2)-getLog(kt2)-getLog(ko));
			LHVari-=eot*(getLog(eot)-getLog(kt)-getLog(ko));			
			//
		}
		//s<->t
		unsigned est=typeModel.m_numEdgesOf2Groups[s][t];
		unsigned ets=typeModel.m_numEdgesOf2Groups[t][s];
		unsigned nvt=typeModel.m_numTargetVtxGroup[v][t];
		unsigned ntv=typeModel.m_numTargetGroupVtx[t][v];
		unsigned est2=est-nvt+nsv-lvv;
		unsigned ets2=ets-ntv+nvs-lvv;
		LHVari+=ets2*(getLog(ets2)-getLog(kt2)-getLog(ks2));
		LHVari-=ets*(getLog(ets)-getLog(kt)-getLog(ks));	
		LHVari+=est2*(getLog(est2)-getLog(kt2)-getLog(ks2));
		LHVari-=est*(getLog(est)-getLog(kt)-getLog(ks));
		//s<->s
		unsigned ess=typeModel.m_numEdgesOf2Groups[s][s];
		unsigned ess2=ess-nvs-nsv+lvv;
		LHVari+=ess2*(getLog(ess2)-getLog(ks2)-getLog(ks2));
		LHVari-=ess*(getLog(ess)-getLog(ks)-getLog(ks));	
		//t<->t
		unsigned ett=typeModel.m_numEdgesOf2Groups[t][t];
		unsigned ett2=ett+nvt+ntv+lvv;
		LHVari+=ett2*(getLog(ett2)-getLog(kt2)-getLog(kt2));
		LHVari-=ett*(getLog(ett)-getLog(kt)-getLog(kt));	
		//
		pair<unsigned,double> lhvariPair(t,LHVari);
		m_LHVariPairs.push_back(lhvariPair);
		m_LLHVariTable[t]=LHVari;
	}
}
//case 1.7: directed with degree-corrected block model (test 03, w_ij, out-degree is used)
void MCMC::calcLHVariDM7(unsigned v,TypeModel& typeModel){
	unsigned s,t,o;
	s=typeModel.getVtxType(v);
	unsigned ns=typeModel.m_groupCardiTable[s];
	unsigned kv=typeModel.getGraph().getVtxDegree(v);//degree of vertex v
	unsigned kv_o=typeModel.m_graph.getVertex(v).getOutDegree();//out-degree of vertex v
	unsigned nvs=typeModel.m_numTargetVtxGroup[v][s];
	unsigned nsv=typeModel.m_numTargetGroupVtx[s][v];
	unsigned ks=typeModel.m_groupDegrees[s];//degree of group s
	unsigned ks_o=typeModel.m_groupOutDegrees[s];//degree of group s
	unsigned ks2=ks-kv;//degree of group s'
	unsigned ks2_o=ks_o-kv_o;//out-degree of group s'
	bool hasSelfLoop=typeModel.getGraph().hasSelfloop();
	unsigned lvv=0;
	double LHVari;
	if(typeModel.getGraph().vtxHasSelfloop(v))
		lvv=1;
	pair<unsigned,double> lhvariPair(s,0.0);
	m_LHVariPairs.push_back(lhvariPair);
	m_LLHVariTable[s]=0.0;
	for(t=0;t<typeModel.getNumActiveType();t++){
		//t=m_typeModel.getActiveType(t_index);
		if(t==s)
			continue;
		unsigned nt=typeModel.m_groupCardiTable[t];
		if(m_groupCorrected)
			LHVari=(ns-1)*getLog(ns-1)+(nt+1)*getLog(nt+1)-ns*getLog(ns)-nt*getLog(nt);//ns'*log(ns')+nt'*log(nt')-ns*log(ns)-nt*log(nt)
		else
			LHVari=0.0;
		unsigned kt=typeModel.m_groupDegrees[t];//degree of group t
		unsigned kt_o=typeModel.m_groupOutDegrees[t];//out-degree of group t
		unsigned kt2=kt+kv;//degree of group t'
		unsigned kt2_o=kt_o+kv_o;//out-degree of group t'
		for(o=0;o<m_numType;o++){
			if(o==s||o==t)
				continue;
			//s<->o
			unsigned eso=typeModel.m_numEdgesOf2Groups[s][o];//total number of edges between s and o		
			unsigned eos=typeModel.m_numEdgesOf2Groups[o][s];//total number of edges between o and s		
			unsigned nvo=typeModel.m_numTargetVtxGroup[v][o];
			unsigned nov=typeModel.m_numTargetGroupVtx[o][v];		
			unsigned eso2=eso-nvo;//total number of edges between s and o after mutation
			unsigned eos2=eos-nov;//total number of edges between o and s after mutation
			unsigned ko=typeModel.m_groupDegrees[o];//degree of group o
			unsigned ko_o=typeModel.m_groupOutDegrees[o];//out-degree of group o
			//			
			LHVari+=eso2*(getLog(eso2)-getLog(ks2_o)-getLog(ko));
			LHVari-=eso*(getLog(eso)-getLog(ks_o)-getLog(ko));	
			LHVari+=eos2*(getLog(eos2)-getLog(ks2)-getLog(ko_o));
			LHVari-=eos*(getLog(eos)-getLog(ks)-getLog(ko_o));	
			//
			//t<->o
			unsigned eto=typeModel.m_numEdgesOf2Groups[t][o];	//eto
			unsigned eot=typeModel.m_numEdgesOf2Groups[o][t];	//eot
			unsigned eto2=eto+nvo;//total number of edges between t and o after mutation					
			unsigned eot2=eot+nov;//total number of edges between o and t after mutation
			LHVari+=eto2*(getLog(eto2)-getLog(kt2_o)-getLog(ko));
			LHVari-=eto*(getLog(eto)-getLog(kt_o)-getLog(ko));	
			LHVari+=eot2*(getLog(eot2)-getLog(kt2)-getLog(ko_o));
			LHVari-=eot*(getLog(eot)-getLog(kt)-getLog(ko_o));			
			//
		}
		//s<->t
		unsigned est=typeModel.m_numEdgesOf2Groups[s][t];
		unsigned ets=typeModel.m_numEdgesOf2Groups[t][s];
		unsigned nvt=typeModel.m_numTargetVtxGroup[v][t];
		unsigned ntv=typeModel.m_numTargetGroupVtx[t][v];
		unsigned est2=est-nvt+nsv-lvv;
		unsigned ets2=ets-ntv+nvs-lvv;
		LHVari+=ets2*(getLog(ets2)-getLog(kt2_o)-getLog(ks2));
		LHVari-=ets*(getLog(ets)-getLog(kt_o)-getLog(ks));	
		LHVari+=est2*(getLog(est2)-getLog(kt2)-getLog(ks2_o));
		LHVari-=est*(getLog(est)-getLog(kt)-getLog(ks_o));
		//s<->s
		unsigned ess=typeModel.m_numEdgesOf2Groups[s][s];
		unsigned ess2=ess-nvs-nsv+lvv;
		LHVari+=ess2*(getLog(ess2)-getLog(ks2)-getLog(ks2_o));
		LHVari-=ess*(getLog(ess)-getLog(ks)-getLog(ks_o));	
		//t<->t
		unsigned ett=typeModel.m_numEdgesOf2Groups[t][t];
		unsigned ett2=ett+nvt+ntv+lvv;
		LHVari+=ett2*(getLog(ett2)-getLog(kt2)-getLog(kt2_o));
		LHVari-=ett*(getLog(ett)-getLog(kt)-getLog(kt_o));	
		//
		pair<unsigned,double> lhvariPair(t,LHVari);
		m_LHVariPairs.push_back(lhvariPair);
		m_LLHVariTable[t]=LHVari;
	}
}
//case 1.8: directed with degree-corrected block model (test 04, w_ij, in-degree is used)
void MCMC::calcLHVariDM8(unsigned v,TypeModel& typeModel){
	unsigned s,t,o;
	s=typeModel.getVtxType(v);
	unsigned ns=typeModel.m_groupCardiTable[s];
	unsigned kv=typeModel.getGraph().getVtxDegree(v);//degree of vertex v
	unsigned kv_i=typeModel.m_graph.getVertex(v).getInDegree();//out-degree of vertex v
	unsigned nvs=typeModel.m_numTargetVtxGroup[v][s];
	unsigned nsv=typeModel.m_numTargetGroupVtx[s][v];
	unsigned ks=typeModel.m_groupDegrees[s];//degree of group s
	unsigned ks_i=typeModel.m_groupInDegrees[s];//degree of group s
	unsigned ks2=ks-kv;//degree of group s'
	unsigned ks2_i=ks_i-kv_i;//out-degree of group s'
	bool hasSelfLoop=typeModel.getGraph().hasSelfloop();
	unsigned lvv=0;
	double LHVari;
	if(typeModel.getGraph().vtxHasSelfloop(v))
		lvv=1;
	pair<unsigned,double> lhvariPair(s,0.0);
	m_LHVariPairs.push_back(lhvariPair);
	m_LLHVariTable[s]=0.0;
	for(t=0;t<typeModel.getNumActiveType();t++){
		//t=m_typeModel.getActiveType(t_index);
		if(t==s)
			continue;
		unsigned nt=typeModel.m_groupCardiTable[t];
		if(m_groupCorrected)
			LHVari=(ns-1)*getLog(ns-1)+(nt+1)*getLog(nt+1)-ns*getLog(ns)-nt*getLog(nt);//ns'*log(ns')+nt'*log(nt')-ns*log(ns)-nt*log(nt)
		else
			LHVari=0.0;
		unsigned kt=typeModel.m_groupDegrees[t];//degree of group t
		unsigned kt_i=typeModel.m_groupInDegrees[t];//out-degree of group t
		unsigned kt2=kt+kv;//degree of group t'
		unsigned kt2_i=kt_i+kv_i;//out-degree of group t'
		for(o=0;o<m_numType;o++){
			if(o==s||o==t)
				continue;
			//s<->o
			unsigned eso=typeModel.m_numEdgesOf2Groups[s][o];//total number of edges between s and o		
			unsigned eos=typeModel.m_numEdgesOf2Groups[o][s];//total number of edges between o and s		
			unsigned nvo=typeModel.m_numTargetVtxGroup[v][o];
			unsigned nov=typeModel.m_numTargetGroupVtx[o][v];		
			unsigned eso2=eso-nvo;//total number of edges between s and o after mutation
			unsigned eos2=eos-nov;//total number of edges between o and s after mutation
			unsigned ko=typeModel.m_groupDegrees[o];//degree of group o
			unsigned ko_i=typeModel.m_groupInDegrees[o];//out-degree of group o
			//			
			LHVari+=eso2*(getLog(eso2)-getLog(ks2)-getLog(ko_i));
			LHVari-=eso*(getLog(eso)-getLog(ks)-getLog(ko_i));	
			LHVari+=eos2*(getLog(eos2)-getLog(ks2_i)-getLog(ko));
			LHVari-=eos*(getLog(eos)-getLog(ks_i)-getLog(ko));	
			//
			//t<->o
			unsigned eto=typeModel.m_numEdgesOf2Groups[t][o];	//eto
			unsigned eot=typeModel.m_numEdgesOf2Groups[o][t];	//eot
			unsigned eto2=eto+nvo;//total number of edges between t and o after mutation					
			unsigned eot2=eot+nov;//total number of edges between o and t after mutation
			LHVari+=eto2*(getLog(eto2)-getLog(kt2)-getLog(ko_i));
			LHVari-=eto*(getLog(eto)-getLog(kt)-getLog(ko_i));	
			LHVari+=eot2*(getLog(eot2)-getLog(kt2_i)-getLog(ko));
			LHVari-=eot*(getLog(eot)-getLog(kt_i)-getLog(ko));			
			//
		}
		//s<->t
		unsigned est=typeModel.m_numEdgesOf2Groups[s][t];
		unsigned ets=typeModel.m_numEdgesOf2Groups[t][s];
		unsigned nvt=typeModel.m_numTargetVtxGroup[v][t];
		unsigned ntv=typeModel.m_numTargetGroupVtx[t][v];
		unsigned est2=est-nvt+nsv-lvv;
		unsigned ets2=ets-ntv+nvs-lvv;
		LHVari+=ets2*(getLog(ets2)-getLog(kt2)-getLog(ks2_i));
		LHVari-=ets*(getLog(ets)-getLog(kt)-getLog(ks_i));	
		LHVari+=est2*(getLog(est2)-getLog(kt2_i)-getLog(ks2));
		LHVari-=est*(getLog(est)-getLog(kt_i)-getLog(ks));
		//s<->s
		unsigned ess=typeModel.m_numEdgesOf2Groups[s][s];
		unsigned ess2=ess-nvs-nsv+lvv;
		LHVari+=ess2*(getLog(ess2)-getLog(ks2_i)-getLog(ks2));
		LHVari-=ess*(getLog(ess)-getLog(ks_i)-getLog(ks));	
		//t<->t
		unsigned ett=typeModel.m_numEdgesOf2Groups[t][t];
		unsigned ett2=ett+nvt+ntv+lvv;
		LHVari+=ett2*(getLog(ett2)-getLog(kt2_i)-getLog(kt2));
		LHVari-=ett*(getLog(ett)-getLog(kt_i)-getLog(kt));	
		//
		pair<unsigned,double> lhvariPair(t,LHVari);
		m_LHVariPairs.push_back(lhvariPair);
		m_LLHVariTable[t]=LHVari;
	}
}
//case 2.1: undirected for model type 1
void MCMC::calcLHVariUDM1(unsigned v,TypeModel& typeModel){
	unsigned s,t,o;
	s=typeModel.getVtxType(v);
	unsigned ns=typeModel.m_groupCardiTable[s];
	unsigned nvs=typeModel.m_numTargetVtxGroup[v][s];
	bool hasSelfLoop=typeModel.getGraph().hasSelfloop();
	unsigned lvv=0;
	if(typeModel.getGraph().vtxHasSelfloop(v))
		lvv=1;
	double LHVari;
	pair<unsigned,double> lhvariPair(s,0.0);
	m_LHVariPairs.push_back(lhvariPair);
	m_LLHVariTable[s]=0.0;
	for(t=0;t<typeModel.getNumActiveType();t++){
		//t=m_typeModel.getActiveType(t_index);
		if(t==s)
			continue;
		unsigned nt=typeModel.m_groupCardiTable[t];
		if(m_groupCorrected)
			LHVari=(ns-1)*getLog(ns-1)+(nt+1)*getLog(nt+1)-ns*getLog(ns)-nt*getLog(nt);//ns'*log(ns')+nt'*log(nt')-ns*log(ns)-nt*log(nt)
		else
			LHVari=0.0;
		for(o=0;o<m_numType;o++){
			if(o==s||o==t)
				continue;
			//s<->o
			unsigned eso=typeModel.m_numEdgesOf2Groups[s][o];
			unsigned nvo=typeModel.m_numTargetVtxGroup[v][o];
			unsigned no=typeModel.m_groupCardiTable[o];
			LHVari+=getLogDivFac(eso-nvo,eso);			
			LHVari+=getLogDivFac(ns*no+1,ns*no-no+1);
			LHVari+=getLogDivFac(ns*no-eso-no+nvo,ns*no-eso);				
			//t<->o
			unsigned eto=typeModel.m_numEdgesOf2Groups[t][o];
			LHVari+=getLogDivFac(eto+nvo,eto);			
			LHVari+=getLogDivFac(nt*no+1,nt*no+no+1);
			LHVari+=getLogDivFac(nt*no-eto+no-nvo,nt*no-eto);			
		}
		//s<->t
		unsigned est=typeModel.m_numEdgesOf2Groups[s][t];
		unsigned nvt=typeModel.m_numTargetVtxGroup[v][t];
		if(hasSelfLoop){
			LHVari+=getLogDivFac(est-nvt+nvs-lvv,est); 			
			LHVari+=getLogDivFac(ns*nt+1,(ns-1)*(nt+1)+1);
			LHVari+=getLogDivFac((ns-1)*(nt+1)-est+nvt-nvs+lvv,ns*nt-est);			
		}else{
			LHVari+=getLogDivFac(est-nvt+nvs,est); 			
			LHVari+=getLogDivFac(ns*nt+1,(ns-1)*(nt+1)+1);
			LHVari+=getLogDivFac((ns-1)*(nt+1)-est+nvt-nvs,ns*nt-est);			
		}
		//s<->s
		unsigned ess=typeModel.m_numEdgesOf2Groups[s][s];
		if(hasSelfLoop){
			LHVari+=getLogDivFac(ess-nvs,ess);
			LHVari+=getLogDivFac(ns*(ns+1)/2+1,ns*(ns-1)/2+1);
			LHVari+=getLogDivFac(ns*(ns-1)/2-ess+nvs,ns*(ns+1)/2-ess);
		}else{
			LHVari+=getLogDivFac(ess-nvs,ess);
			LHVari+=getLogDivFac(ns*(ns-1)/2+1,(ns-1)*(ns-2)/2+1);
			LHVari+=getLogDivFac((ns-1)*(ns-2)/2-ess+nvs,ns*(ns-1)/2-ess);
		}
		//t<->t
		unsigned ett=typeModel.m_numEdgesOf2Groups[t][t];
		if(hasSelfLoop){
			LHVari+=getLogDivFac(ett+nvt+lvv,ett);
			LHVari+=getLogDivFac(nt*(nt+1)/2+1,(nt+1)*(nt+2)/2+1);
			LHVari+=getLogDivFac((nt+1)*(nt+2)/2-ett-nvt-lvv,nt*(nt+1)/2-ett);
		}else{
			LHVari+=getLogDivFac(ett+nvt,ett);
			LHVari+=getLogDivFac(nt*(nt-1)/2+1,(nt+1)*nt/2+1);
			LHVari+=getLogDivFac((nt+1)*nt/2-ett-nvt,nt*(nt-1)/2-ett);
		}
		//
		pair<unsigned,double> lhvariPair(t,LHVari);
		m_LHVariPairs.push_back(lhvariPair);
		m_LLHVariTable[t]=LHVari;
	}
}
//case 2.2: undirected for model type 2
void MCMC::calcLHVariUDM2(unsigned v,TypeModel& typeModel){
	unsigned s,t,o;
	s=typeModel.getVtxType(v);
	unsigned ns=typeModel.m_groupCardiTable[s];
	unsigned nvs=typeModel.m_numTargetVtxGroup[v][s];
	bool hasSelfLoop=typeModel.getGraph().hasSelfloop();
	unsigned lvv=0;
	if(typeModel.getGraph().vtxHasSelfloop(v))
		lvv=1;
	double LHVari;
	pair<unsigned,double> lhvariPair(s,0.0);
	m_LHVariPairs.push_back(lhvariPair);
	m_LLHVariTable[s]=0.0;
	for(t=0;t<typeModel.getNumActiveType();t++){
		//t=m_typeModel.getActiveType(t_index);
		if(t==s)
			continue;
		unsigned nt=typeModel.m_groupCardiTable[t];
		if(m_groupCorrected)
			LHVari=(ns-1)*getLog(ns-1)+(nt+1)*getLog(nt+1)-ns*getLog(ns)-nt*getLog(nt);//ns'*log(ns')+nt'*log(nt')-ns*log(ns)-nt*log(nt)
		else
			LHVari=0.0;
		for(o=0;o<m_numType;o++){
			if(o==s||o==t)
				continue;
			//s<->o
			unsigned eso=typeModel.m_numEdgesOf2Groups[s][o];
			unsigned nvo=typeModel.m_numTargetVtxGroup[v][o];
			unsigned no=typeModel.m_groupCardiTable[o];
			LHVari+=getLogDivFac(eso-nvo,eso);			
			LHVari+=getLogDivFac(ns*no+1,ns*no-no+1);
			LHVari+=getLogDivFac(ns*no-eso-no+nvo,ns*no-eso);				
			//t<->o
			unsigned eto=typeModel.m_numEdgesOf2Groups[t][o];
			LHVari+=getLogDivFac(eto+nvo,eto);			
			LHVari+=getLogDivFac(nt*no+1,nt*no+no+1);
			LHVari+=getLogDivFac(nt*no-eto+no-nvo,nt*no-eto);			
		}
		//s<->t
		unsigned est=typeModel.m_numEdgesOf2Groups[s][t];
		unsigned nvt=typeModel.m_numTargetVtxGroup[v][t];
		if(hasSelfLoop){
			LHVari+=getLogDivFac(est-nvt+nvs-lvv,est); 			
			LHVari+=getLogDivFac(ns*nt+1,(ns-1)*(nt+1)+1);
			LHVari+=getLogDivFac((ns-1)*(nt+1)-est+nvt-nvs+lvv,ns*nt-est);			
		}else{
			LHVari+=getLogDivFac(est-nvt+nvs,est); 			
			LHVari+=getLogDivFac(ns*nt+1,(ns-1)*(nt+1)+1);
			LHVari+=getLogDivFac((ns-1)*(nt+1)-est+nvt-nvs,ns*nt-est);			
		}
		//s<->s
		unsigned ess=typeModel.m_numEdgesOf2Groups[s][s];
		if(hasSelfLoop){
			LHVari+=getLogDivFac(ess-nvs,ess);
			LHVari+=getLogDivFac(ns*(ns+1)/2+1,ns*(ns-1)/2+1);
			LHVari+=getLogDivFac(ns*(ns-1)/2-ess+nvs,ns*(ns+1)/2-ess);
		}else{
			LHVari+=getLogDivFac(ess-nvs,ess);
			LHVari+=getLogDivFac(ns*(ns-1)/2+1,(ns-1)*(ns-2)/2+1);
			LHVari+=getLogDivFac((ns-1)*(ns-2)/2-ess+nvs,ns*(ns-1)/2-ess);
		}
		//t<->t
		unsigned ett=typeModel.m_numEdgesOf2Groups[t][t];
		if(hasSelfLoop){
			LHVari+=getLogDivFac(ett+nvt+lvv,ett);
			LHVari+=getLogDivFac(nt*(nt+1)/2+1,(nt+1)*(nt+2)/2+1);
			LHVari+=getLogDivFac((nt+1)*(nt+2)/2-ett-nvt-lvv,nt*(nt+1)/2-ett);
		}else{
			LHVari+=getLogDivFac(ett+nvt,ett);
			LHVari+=getLogDivFac(nt*(nt-1)/2+1,(nt+1)*nt/2+1);
			LHVari+=getLogDivFac((nt+1)*nt/2-ett-nvt,nt*(nt-1)/2-ett);
		}
		//
		pair<unsigned,double> lhvariPair(t,LHVari);
		m_LHVariPairs.push_back(lhvariPair);
		m_LLHVariTable[t]=LHVari;
	}
}

//case 2.3: undirected for model type 3 -- degree-corrected with mle w_ij
void MCMC::calcLHVariUDM3(unsigned v,TypeModel& typeModel){
	unsigned s,t,o;
	s=typeModel.getVtxType(v);
	unsigned ns=typeModel.m_groupCardiTable[s];
	unsigned kv=typeModel.getGraph().getVtxDegree(v);//degree of vertex v
	unsigned nvs=typeModel.m_numTargetVtxGroup[v][s];
	unsigned ks=typeModel.m_groupDegrees[s];//degree of group s
	unsigned ks2=ks-kv;//degree of group s'
	bool hasSelfLoop=typeModel.getGraph().hasSelfloop();
	unsigned lvv=0;
	double LHVari;
	if(typeModel.getGraph().vtxHasSelfloop(v))
		lvv=1;
	pair<unsigned,double> lhvariPair(s,0.0);
	m_LHVariPairs.push_back(lhvariPair);
	m_LLHVariTable[s]=0.0;
	for(t=0;t<typeModel.getNumActiveType();t++){
		//t=m_typeModel.getActiveType(t_index);
		if(t==s)
			continue;
		unsigned nt=typeModel.m_groupCardiTable[t];
		if(m_groupCorrected)
			LHVari=(ns-1)*getLog(ns-1)+(nt+1)*getLog(nt+1)-ns*getLog(ns)-nt*getLog(nt);//ns'*log(ns')+nt'*log(nt')-ns*log(ns)-nt*log(nt)
		else
			LHVari=0.0;
		unsigned kt=typeModel.m_groupDegrees[t];//degree of group t
		unsigned kt2=kt+kv;//degree of group t'
		for(o=0;o<m_numType;o++){
			if(o==s||o==t)
				continue;
			//s<->o
			unsigned eso=typeModel.m_numEdgesOf2Groups[s][o];
			unsigned nvo=typeModel.m_numTargetVtxGroup[v][o];
			unsigned ko=typeModel.m_groupDegrees[o];//degree of group o
			unsigned eso2=eso-nvo;
			LHVari+=eso2*(getLog(eso2)-getLog(ks2)-getLog(ko));
			LHVari-=eso*(getLog(eso)-getLog(ks)-getLog(ko));			
			//t<->o
			unsigned eto=typeModel.m_numEdgesOf2Groups[t][o];
			unsigned eto2=eto+nvo;
			LHVari+=eto2*(getLog(eto2)-getLog(kt2)-getLog(ko));
			LHVari-=eto*(getLog(eto)-getLog(kt)-getLog(ko));			
		}
		//s<->t
		unsigned est=typeModel.m_numEdgesOf2Groups[s][t];
		unsigned nvt=typeModel.m_numTargetVtxGroup[v][t];
		unsigned est2=est-nvt+nvs-lvv;		
		LHVari+=est2*(getLog(est2)-getLog(ks2)-getLog(kt2));
		LHVari-=est*(getLog(est)-getLog(ks)-getLog(kt));	
		//s<->s
		unsigned ess=typeModel.m_numEdgesOf2Groups[s][s];
		unsigned ess2=ess-nvs;
		LHVari+=ess2*(getLog((2*ess2))-getLog(ks2)-getLog(ks2));
		LHVari-=ess*(getLog((2*ess))-getLog(ks)-getLog(ks));	
		//t<->t
		unsigned ett=typeModel.m_numEdgesOf2Groups[t][t];
		unsigned ett2=ett+nvt+lvv;
		LHVari+=ett2*(getLog((2*ett2))-getLog(kt2)-getLog(kt2));
		LHVari-=ett*(getLog((2*ett))-getLog(kt)-getLog(kt));	
		//
		pair<unsigned,double> lhvariPair(t,LHVari);
		m_LHVariPairs.push_back(lhvariPair);
		m_LLHVariTable[t]=LHVari;
	}
}
//case 2.4: undirected for model type 4 //degree-corrected with integral of w_ij
void MCMC::calcLHVariUDM4(unsigned v,TypeModel& typeModel){
	unsigned s,t,o;
	double a;
	double a2;
	double b=1/2+1/W_BAR;
	s=typeModel.getVtxType(v);
	unsigned ns=typeModel.m_groupCardiTable[s];
	unsigned nvs=typeModel.m_numTargetVtxGroup[v][s];
	unsigned kv=typeModel.getGraph().getVtxDegree(v);//degree of vertex v
	unsigned ks=typeModel.m_groupDegrees[s];//degree of group s
	unsigned ks2=ks-kv;//degree of group s'
	bool hasSelfLoop=typeModel.getGraph().hasSelfloop();
	unsigned lvv=0;
	double LHVari;
	if(typeModel.getGraph().vtxHasSelfloop(v))
		lvv=1;
	pair<unsigned,double> lhvariPair(s,0.0);
	m_LHVariPairs.push_back(lhvariPair);
	m_LLHVariTable[s]=0.0;
	for(t=0;t<typeModel.getNumActiveType();t++){
		//t=m_typeModel.getActiveType(t_index);
		if(t==s)
			continue;
		unsigned nt=typeModel.m_groupCardiTable[t];
		unsigned kt=typeModel.m_groupDegrees[t];//degree of group t
		unsigned kt2=kt+kv;//degree of group t'
		if(m_groupCorrected)
			LHVari=(ns-1)*getLog(ns-1)+(nt+1)*getLog(nt+1)-ns*getLog(ns)-nt*getLog(nt);//ns'*log(ns')+nt'*log(nt')-ns*log(ns)-nt*log(nt)
		else
			LHVari=0.0;
		for(o=0;o<m_numType;o++){
			if(o==s||o==t)
				continue;
			//s<->o
			unsigned eso=typeModel.m_numEdgesOf2Groups[s][o];
			unsigned nvo=typeModel.m_numTargetVtxGroup[v][o];
			unsigned no=typeModel.m_groupCardiTable[o];
			unsigned ko=typeModel.m_groupDegrees[o];//degree of group o
			unsigned eso2=eso-nvo;
			a=(double)eso/2;
			a2=(double)eso2/2;
			LHVari+=2*((1+a)*log(b)-(1+a2)*log(b));
			LHVari+=2*(m_loggammatable[2+(int)(2*a2)]-m_loggammatable[2+(int)(2*a)]);	
			LHVari+=eso*(getLog(ks)+getLog(ko))-eso2*(getLog(ks2)+getLog(ko));
			//t<->o
			unsigned eto=typeModel.m_numEdgesOf2Groups[t][o];
			unsigned eto2=eto+nvo;
			a=(double)eto/2;
			a2=(double)eto2/2;
			LHVari+=2*((1+a)*log(b)-(1+a2)*log(b));
			LHVari+=2*(m_loggammatable[2+(int)(2*a2)]-m_loggammatable[2+(int)(2*a)]);		
			LHVari+=eto*(getLog(kt)+getLog(ko))-eto2*(getLog(kt2)+getLog(ko));
		}
		//s<->t
		unsigned est=typeModel.m_numEdgesOf2Groups[s][t];
		unsigned nvt=typeModel.m_numTargetVtxGroup[v][t];
		unsigned est2=est-nvt+nvs;
		if(hasSelfLoop)
			est2-=lvv;		
		a=(double)est/2;
		a2=(double)est2/2;
		LHVari+=2*((1+a)*log(b)-(1+a2)*log(b));
		LHVari+=2*(m_loggammatable[2+(int)(2*a2)]-m_loggammatable[2+(int)(2*a)]);	
		LHVari+=est*(getLog(ks)+getLog(kt))-est2*(getLog(ks2)+getLog(kt2));
		//s<->s
		unsigned ess=typeModel.m_numEdgesOf2Groups[s][s];
		unsigned ess2=ess-nvs;
		a=ess;
		a2=ess2;
		LHVari+=(1+a)*log(b)-(1+a2)*log(b);
		LHVari+=m_loggammatable[2+(int)(2*a2)]-m_loggammatable[2+(int)(2*a)];				
		LHVari+=2*ess*getLog(ks)-2*ess2*getLog(ks2);
		//t<->t
		unsigned ett=typeModel.m_numEdgesOf2Groups[t][t];
		unsigned ett2=ett+nvt;
		if(hasSelfLoop)
			ett2+=lvv;
		a=ett;
		a2=ett2;
		LHVari+=(1+a)*log(b)-(1+a2)*log(b);
		LHVari+=m_loggammatable[2+(int)(2*a2)]-m_loggammatable[2+(int)(2*a)];	
		LHVari+=2*ett*getLog(kt)-2*ett2*getLog(kt2);
		//
		pair<unsigned,double> lhvariPair(t,LHVari);
		m_LHVariPairs.push_back(lhvariPair);
		m_LLHVariTable[t]=LHVari;
	}
}
//void MCMC::calcLHVariUDM4(unsigned v,TypeModel& typeModel){
//	unsigned s,t,o;
//	double a;
//	double a2;
//	double b;
//	double b2;
//	s=typeModel.getVtxType(v);
//	unsigned ns=typeModel.m_groupCardiTable[s];
//	unsigned nvs=typeModel.m_numTargetVtxGroup[v][s];
//	bool hasSelfLoop=typeModel.getGraph().hasSelfloop();
//	unsigned lvv=0;
//	double LHVari;
//	if(typeModel.getGraph().vtxHasSelfloop(v))
//		lvv=1;
//	pair<unsigned,double> lhvariPair(s,0.0);
//	m_LHVariPairs.push_back(lhvariPair);
//	m_LLHVariTable[s]=0.0;
//	for(t=0;t<typeModel.getNumActiveType();t++){
//		//t=m_typeModel.getActiveType(t_index);
//		if(t==s)
//			continue;
//		unsigned nt=typeModel.m_groupCardiTable[t];
//		if(m_groupCorrected)
//			LHVari=(ns-1)*getLog(ns-1)+(nt+1)*getLog(nt+1)-ns*getLog(ns)-nt*getLog(nt);//ns'*log(ns')+nt'*log(nt')-ns*log(ns)-nt*log(nt)
//		else
//			LHVari=0.0;
//		for(o=0;o<m_numType;o++){
//			if(o==s||o==t)
//				continue;
//			//s<->o
//			unsigned eso=typeModel.m_numEdgesOf2Groups[s][o];
//			unsigned nvo=typeModel.m_numTargetVtxGroup[v][o];
//			unsigned no=typeModel.m_groupCardiTable[o];
//			unsigned eso2=eso-nvo;
//			a=(double)eso/2;
//			a2=(double)eso2/2;
//			b=(double)ns*no/2+1/W_BAR;
//			b2=b-(double)no/2;
//			LHVari+=2*((1+a)*log(b)-(1+a2)*log(b2));
//			LHVari+=2*(m_loggammatable[2+(int)(2*a2)]-m_loggammatable[2+(int)(2*a)]);			
//			//t<->o
//			unsigned eto=typeModel.m_numEdgesOf2Groups[t][o];
//			unsigned eto2=eto+nvo;
//			a=(double)eto/2;
//			a2=(double)eto2/2;
//			b=(double)nt*no/2+1/W_BAR;
//			b2=b+(double)no/2;
//			LHVari+=2*((1+a)*log(b)-(1+a2)*log(b2));
//			LHVari+=2*(m_loggammatable[2+(int)(2*a2)]-m_loggammatable[2+(int)(2*a)]);			
//		}
//		//s<->t
//		unsigned est=typeModel.m_numEdgesOf2Groups[s][t];
//		unsigned nvt=typeModel.m_numTargetVtxGroup[v][t];
//		unsigned est2=est-nvt+nvs;
//		if(hasSelfLoop)
//			est2-=lvv;		
//		a=(double)est/2;
//		a2=(double)est2/2;
//		b=(double)ns*nt/2+1/W_BAR;
//		b2=(double)(ns-1)*(nt+1)/2+1/W_BAR;
//		LHVari+=2*((1+a)*log(b)-(1+a2)*log(b2));
//		LHVari+=2*(m_loggammatable[2+(int)(2*a2)]-m_loggammatable[2+(int)(2*a)]);	
//		//s<->s
//		unsigned ess=typeModel.m_numEdgesOf2Groups[s][s];
//		unsigned ess2=ess-nvs;
//		a=ess;
//		a2=ess2;
//		b=(double)ns*ns/2+1/W_BAR;
//		b2=(double)(ns-1)*(ns-1)/2+1/W_BAR;
//		LHVari+=(1+a)*log(b)-(1+a2)*log(b2);
//		LHVari+=m_loggammatable[2+(int)(2*a2)]-m_loggammatable[2+(int)(2*a)];				
//		//t<->t
//		unsigned ett=typeModel.m_numEdgesOf2Groups[t][t];
//		unsigned ett2=ett+nvt;
//		if(hasSelfLoop)
//			ett2+=lvv;
//		a=ett;
//		a2=ett2;
//		b=(double)nt*nt/2+1/W_BAR;
//		b2=(double)(nt+1)*(nt+1)/2+1/W_BAR;
//		LHVari+=(1+a)*log(b)-(1+a2)*log(b2);
//		LHVari+=m_loggammatable[2+(int)(2*a2)]-m_loggammatable[2+(int)(2*a)];		
//		//
//		pair<unsigned,double> lhvariPair(t,LHVari);
//		m_LHVariPairs.push_back(lhvariPair);
//		m_LLHVariTable[t]=LHVari;
//	}
//}
unsigned MCMC::calcTargetType(){
	unsigned i;
	double dsum=0.0;
	double maxLogDif=m_LHVariPairs[0].second;
	double minLogDif=m_LHVariPairs[0].second;
	for(i=1;i<m_LHVariPairs.size();i++){
		if(m_LHVariPairs[i].second>maxLogDif)
			maxLogDif=m_LHVariPairs[i].second;
		if(m_LHVariPairs[i].second<minLogDif)
			minLogDif=m_LHVariPairs[i].second;
	}
	double newMaxLogDif=(maxLogDif-minLogDif)/2;
	double offset=newMaxLogDif-maxLogDif;
	for(i=0;i<m_LHVariPairs.size();i++){
		m_LHVariPairs[i].second+=offset;
	}
	if(newMaxLogDif>MAXLOGDOUBLE){
		double shrinkRatio=newMaxLogDif/MAXLOGDOUBLE;
		for(i=0;i<m_LHVariPairs.size();i++){
			m_LHVariPairs[i].second/=shrinkRatio;
		}
	}
	for(i=0;i<m_LHVariPairs.size();i++){
		m_LHVariPairs[i].second=exp(m_LHVariPairs[i].second);
		dsum+=m_LHVariPairs[i].second;
		m_transProbSelect[i]=dsum;
	}
	for(i=0;i<m_LHVariPairs.size();i++)
		m_LHVariPairs[i].second/=dsum;	
	unsigned index=getIndexProb(m_transProbSelect,m_LHVariPairs.size());
	unsigned targetType = m_LHVariPairs[index].first;
	return targetType;
}
//m_logfactable[i]=ln(i!)
void MCMC::initLogTable(unsigned size){
	m_logfactable=new double[size+1];
	m_logtable=new double[size+1];
	m_logfactable[0]=0;
	m_logtable[0]=0;
	for(unsigned i=1;i<=size;i++){
		m_logfactable[i]=m_logfactable[i-1]+log((double)i);
		m_logtable[i]=log((double)i);
	}
}
//log_gamma(0),log_gamma(0.5),log_gamma(1)...; log_gamma(i)=m_loggammatable[2i];
void MCMC::initLogGammaTable(unsigned size){
	unsigned i;
	m_loggammatable=new double[size+1];
	m_loggammatable[0]=0;//dummy, will never be used;
	m_loggammatable[1]=log(sqrt(PI));//log_gamma(0.5)
	m_loggammatable[2]=log(1.0);//log_gamma(1)
	for(i=3;i<size;i++)
		m_loggammatable[i]=log((0.5*i-1))+m_loggammatable[i-2];//log_gamma(0.5i)
}

// return  ln(a!/b!)
double MCMC::getLogDivFac(unsigned a, unsigned b){
	if(a>m_maxsizeLogtable||b>m_maxsizeLogtable){
		cerr<<"need more memory for logtable--getLogDivFac()"<<endl;
		//this->m_typeModel.showModelInfo();
		//getchar();
		delete [] m_logfactable;
		m_maxsizeLogtable=max(a,b)+1000;
		initLogTable(m_maxsizeLogtable);		
	}
	return m_logfactable[a]-m_logfactable[b];
}
// return  ln(a!)
double MCMC::getLogFac(unsigned a){
	if(a>m_maxsizeLogtable){
		cerr<<"need more memory for logtable--getLogFac()\t"<<a<<endl;
		//this->m_typeModel.showModelInfo();
		//getchar();
		delete [] m_logfactable;
		m_maxsizeLogtable=a+1000;
		initLogTable(m_maxsizeLogtable);		
	}
	return m_logfactable[a];	
}
double MCMC::getLog(unsigned a){
	if(a>m_maxsizeLogtable){
		cerr<<"need more memory for logtable--getLog()\t"<<a<<endl;
		//this->m_typeModel.showModelInfo();
		//getchar();
		delete [] m_logtable;
		m_maxsizeLogtable=a+1000;
		initLogTable(m_maxsizeLogtable);		
	}
	return m_logtable[a];	
}
void MCMC::showLHVari() const {
	unsigned i;
	cout<<"Likelihood Variation Vector:"<<endl;
	for(i=0;i<m_LHVariPairs.size();i++)
		cout<<"<"<<m_LHVariPairs[i].first<<","<<m_LHVariPairs[i].second<<">"<<"\t";
	cout<<endl;
}

void MCMC::initVtxClassifiMatrix(){
	unsigned i,j;
	for(i=0;i<m_numVtx;i++){
		for(j=0;j<m_numType;j++){
			dvtxClassifiMatrix[i][j]=0.0;
		}
	}
}
void MCMC::updateVtxClassifiMatrix(){//should be called after mutateTypeModel()
	unsigned i;
	for(i=0;i<m_LHVariPairs.size();i++)
		dvtxClassifiMatrix[m_mutateVtxNo][m_LHVariPairs[i].first]+=m_LHVariPairs[i].second;
}
double ** MCMC::getVtxClassifiMatrix(){
	unsigned i,j;
	double dSum;
	for(i=0;i<m_numVtx;i++){
		dSum=0.0;
		for(j=0;j<m_numType;j++){
			dSum+=dvtxClassifiMatrix[i][j];
		}
		if(dSum!=0){
			for(j=0;j<m_numType;j++)
				dvtxClassifiMatrix[i][j]/=dSum;
		}
	}
	return dvtxClassifiMatrix;
}
void MCMC::randInitTypeModel(const set<unsigned>& topVtxSet){
	m_typeModel.randInitGroups(topVtxSet);		
	initLLHValue();
}
void MCMC::randInitTypeModel(unsigned * vtxtypetable){
	m_typeModel.randInitGroups(vtxtypetable);		
	initLLHValue();
}
void MCMC::initTypeModelKL(const set<unsigned>& topVtxSet){
	m_typeModel.randInitGroups(topVtxSet);	
	runKLHeuristic(topVtxSet);	
	initLLHValue();
}
void MCMC::runKLHeuristic(const set<unsigned>& topVtxSet){
	//cout<<"K-L heuristic begin..."<<endl;
	unsigned i,j;
	set<unsigned> changedVtxSet;	
	bool hasUnchangedVtx;
	unsigned bestvtxNo=0;
	unsigned besttargettype=0;
	double llhvari=0.0;
	unsigned targettype=0;
	double bestllhvari=0.0;
	unsigned curtype=0;
	//unsigned t_index;
	TypeModel bestinnermodel(m_typeModel);
	TypeModel kltypemodel(m_typeModel);
	double bestllhvalue=calcLikelihood(m_typeModel);
	double bestinnerllh=bestllhvalue;
	double llhvalueklmodel=bestllhvalue;	
	unsigned countouterloop=0;
	//OUTER_1	
	while(true){		
		countouterloop++;
		hasUnchangedVtx=true;	
		changedVtxSet.clear();
		changedVtxSet.insert(topVtxSet.begin(),topVtxSet.end());
		//inner begin
		while(hasUnchangedVtx){
			hasUnchangedVtx = false;
			bestllhvari = -numeric_limits<double>::max();
			for (i = 0; i < m_numVtx; i++) {
				if (changedVtxSet.find(i) != changedVtxSet.end())
					continue;
				hasUnchangedVtx = true;
				calcLHVari(i, kltypemodel);
				llhvari = -numeric_limits<double>::max();
				curtype=kltypemodel.getVtxType(i);
				for(j=0;j<m_LHVariPairs.size();j++){
					if(j==curtype)
						continue;
					if (m_LLHVariTable[j] > llhvari) {
						llhvari = m_LLHVariTable[j];
						targettype = j;
					}
				}
				if (llhvari > bestllhvari) {					
					bestllhvari = llhvari;
					besttargettype = targettype;
					bestvtxNo = i;
				}
			}			
			if (hasUnchangedVtx) {		
				kltypemodel.mutate(bestvtxNo,besttargettype);					
				llhvalueklmodel=llhvalueklmodel+bestllhvari;
				if(rand01()<0.001){
					double llhvklmodeltest=calcLikelihood(kltypemodel);
					if(fabs(llhvklmodeltest-llhvalueklmodel)>=0.00001){					
						cout<<"K-L heuristic: likelihood calculation error! -- MCMC::runKLHeuristic"<<endl;
						getchar();
					}else{
						llhvalueklmodel=llhvklmodeltest;
					}
				}
				if(llhvalueklmodel>bestinnerllh){
					bestinnerllh=llhvalueklmodel;
					bestinnermodel=kltypemodel;
				}
				changedVtxSet.insert(bestvtxNo);
			}
		}
		
		//inner end
		if(bestinnerllh<=bestllhvalue)
			break;
		m_typeModel=bestinnermodel;
		kltypemodel=bestinnermodel;
		llhvalueklmodel=bestinnerllh;
		bestllhvalue=bestinnerllh;
		//cout<<countouterloop<<"\t"<<bestllhvalue<<endl;
	}
	//cout<<"K-L heuristic completed"<<endl;
}
void MCMC::initBestTypeModel(){
	unsigned i,j;
	m_bestLLHvalue=calcLikelihood(m_typeModel);
	//m_bestTypeModel=m_typeModel;	
	for(i=0;i<m_numType;i++){
		for(j=0;j<m_numType;j++){
			m_bestEdgeConnMatrix[i][j]=m_typeModel.m_numEdgesOf2Groups[i][j];
		}
		m_bestGroupCardi[i]=m_typeModel.m_groupCardiTable[i];		
	}
	for(i=0;i<m_numVtx;i++){
		m_bestVtxTypeTable[i]=m_typeModel.getVtxType(i);
	}
}
void MCMC::updateBestTypeModel(){
	unsigned i,j;
	if(m_logLikelihoodValue>m_bestLLHvalue){	
		//m_bestLLHvalue=m_logLikelihoodValue;
		m_bestLLHvalue=calcLikelihood(m_typeModel);
		//m_bestTypeModel=m_typeModel;	
		for(i=0;i<m_numType;i++){
			for(j=0;j<m_numType;j++){
				m_bestEdgeConnMatrix[i][j]=m_typeModel.m_numEdgesOf2Groups[i][j];
			}
			m_bestGroupCardi[i]=m_typeModel.m_groupCardiTable[i];
		}	
		for(i=0;i<m_numVtx;i++){
			m_bestVtxTypeTable[i]=m_typeModel.getVtxType(i);
		}
	}
}
void MCMC::mutateTypeModel(unsigned v, unsigned t) {
	m_mutateVtxNo=v;
	m_targetType=t;
	m_sourceType=m_typeModel.getVtxType(m_mutateVtxNo);
	if(m_targetType!=m_sourceType){
		m_typeModel.mutate(v,t);	
		updateLLHValue();
		if(rand01()<0.001){
			double llhvalue=calcLikelihood(m_typeModel);
			if(fabs(llhvalue-m_logLikelihoodValue)>0.00001){
				cout<<"likelihood calculation error! -- MCMC::mutateTypeModel()"<<endl;
				cout<<llhvalue<<"\t"<<m_logLikelihoodValue<<endl;
			    getchar();
			}else{
				m_logLikelihoodValue=llhvalue;
			}
		}
	}
}
double MCMC::calcLikelihood(const TypeModel & typemodel){
	double llhvalue;
	if(m_blockModelType==1)
		llhvalue=calcLikelihoodM1(typemodel);
	else if(m_blockModelType==2)
		llhvalue=calcLikelihoodM2(typemodel);
	else if(m_blockModelType==3)
		llhvalue=calcLikelihoodM3(typemodel);
	else if(m_blockModelType==4)
		llhvalue=calcLikelihoodM4(typemodel);
	else if(m_blockModelType==5)
		llhvalue=calcLikelihoodM5(typemodel);
	else if(m_blockModelType==6)
		llhvalue=calcLikelihoodM6(typemodel);
	else if(m_blockModelType==7)
		llhvalue=calcLikelihoodM7(typemodel);
	else if(m_blockModelType==8)
		llhvalue=calcLikelihoodM8(typemodel);
	else{
		cerr<<"unrecognized model type!"<<endl;
		return -1;
	}
	//if(m_firstcalcllh){
	//	m_firstcalcllh=false;
	//	m_initllhvalue=llhvalue;
	//	return 0.0;
	//}
	//else
		return llhvalue;//-m_initllhvalue;
}
//This method returns the likelihood of the current Type Model (model type is 1)
double MCMC::calcLikelihoodM1(const TypeModel & typemodel){
	unsigned i,j,a,b;
	unsigned numtype=typemodel.getNumType();
	//double likelihood_value=0.0;
	double log_likelihood_value=0.0;
	if (typemodel.getGraph().isDirected() && typemodel.getGraph().hasSelfloop()){
		for (i=0; i<numtype; i++){
			for (j=0; j<numtype; j++) {
				a = typemodel.m_numEdgesOf2Groups[i][j];
				b = typemodel.m_groupCardiTable[i] * typemodel.m_groupCardiTable[j] - a;
				log_likelihood_value = log_likelihood_value + getLogFac(a) + getLogFac(b) - getLogFac(a+b+1);
			}
		}
	}
	if (typemodel.getGraph().isDirected() && !typemodel.getGraph().hasSelfloop()){		
		for (i=0; i<numtype; i++){
			for (j=0; j<numtype; j++) {
				a = typemodel.m_numEdgesOf2Groups[i][j];
				if(i==j)					
					b = typemodel.m_groupCardiTable[i] * (typemodel.m_groupCardiTable[i]-1) - a;
				else
					b = typemodel.m_groupCardiTable[i] * typemodel.m_groupCardiTable[j] - a;
				log_likelihood_value = log_likelihood_value + getLogFac(a) + getLogFac(b) - getLogFac(a+b+1);				
			}
		}
	}
	if (!typemodel.getGraph().isDirected() && typemodel.getGraph().hasSelfloop()){		
		for (i=0; i<numtype; i++){
			for (j=i; j<numtype; j++) {
				a = typemodel.m_numEdgesOf2Groups[i][j];
				if(i==j)					
					b = typemodel.m_groupCardiTable[i] * (typemodel.m_groupCardiTable[i]-1) / 2 + typemodel.m_groupCardiTable[i] - a;
				else
					b = typemodel.m_groupCardiTable[i] * typemodel.m_groupCardiTable[j] - a;
				log_likelihood_value = log_likelihood_value + getLogFac(a) + getLogFac(b) - getLogFac(a+b+1);				
			}
		}
	}
	if (!typemodel.getGraph().isDirected() && !typemodel.getGraph().hasSelfloop()){		
		for (i=0; i<numtype; i++){
			for (j=i; j<numtype; j++) {
				a = typemodel.m_numEdgesOf2Groups[i][j];
				if(i==j)					
					b = typemodel.m_groupCardiTable[i] * (typemodel.m_groupCardiTable[i]-1) / 2 - a;
				else
					b = typemodel.m_groupCardiTable[i] * typemodel.m_groupCardiTable[j] - a;
				log_likelihood_value = log_likelihood_value + getLogFac(a) + getLogFac(b) - getLogFac(a+b+1);				
			}
		}
	}
	if(m_groupCorrected)
		groupCorrectLLH(typemodel, log_likelihood_value);
	return log_likelihood_value;
}
//This method returns the likelihood of the current Type Model (model type is 2)
double MCMC::calcLikelihoodM2(const TypeModel & typemodel){
	unsigned i,j;
	unsigned eij, ni, nj;
	unsigned numtype=typemodel.getNumType();
	//double likelihood_value=0.0;
	double log_likelihood_value=0.0;
	//actually used presently
	if (typemodel.getGraph().isDirected() && typemodel.getGraph().hasSelfloop()){
		for (i=0; i<numtype; i++){
			for (j=0; j<numtype; j++) {
				eij = typemodel.m_numEdgesOf2Groups[i][j];
				ni=typemodel.m_groupCardiTable[i];
				nj=typemodel.m_groupCardiTable[j];
				//if(i==j){
				//	if(eij!=0)
				//		log_likelihood_value += eij*(log((double)eij)-log((double)ni*ni));
				//	if((ni*ni-eij)!=0)
				//		log_likelihood_value += (ni*ni-eij)*(log((double)ni*ni-eij)-log((double)ni*ni));
				//}
				//else{
					if(eij!=0)
						log_likelihood_value += eij*(log((double)eij)-log((double)ni*nj));
					if((ni*nj-eij)!=0)
						log_likelihood_value += (ni*nj-eij)*(log((double)ni*nj-eij)-log((double)ni*nj));
				//}		
			}
		}
	}
	
	if (typemodel.getGraph().isDirected() && !typemodel.getGraph().hasSelfloop()){		
		for (i=0; i<numtype; i++){
			for (j=0; j<numtype; j++) {
				eij = typemodel.m_numEdgesOf2Groups[i][j];
				ni=typemodel.m_groupCardiTable[i];
				nj=typemodel.m_groupCardiTable[j];
				if(i==j){
					if(eij!=0)
						log_likelihood_value += eij*(log((double)eij)-log((double)ni*(ni-1)));
					if((ni*(ni-1)-eij)!=0)
						log_likelihood_value += (ni*(ni-1)-eij)*(log((double)ni*(ni-1)-eij)-log((double)ni*(ni-1)));
				}
				else{
					if(eij!=0)
						log_likelihood_value += eij*(log((double)eij)-log((double)ni*nj));
					if((ni*nj-eij)!=0)
						log_likelihood_value += (ni*nj-eij)*(log((double)ni*nj-eij)-log((double)ni*nj));
				}		
			}
		}
	}
	if (!typemodel.getGraph().isDirected() && typemodel.getGraph().hasSelfloop()){		
		for (i=0; i<numtype; i++){
			for (j=i; j<numtype; j++) {
				eij = typemodel.m_numEdgesOf2Groups[i][j];
				ni=typemodel.m_groupCardiTable[i];
				nj=typemodel.m_groupCardiTable[j];
				if(i==j){				
					if(eij!=0)
						log_likelihood_value += eij*(log((double)eij)-log((double)ni*(ni+1)/2));
					if((ni*(ni+1)/2-eij)!=0)
						log_likelihood_value += (ni*(ni+1)/2-eij)*(log((double)ni*(ni+1)/2-eij)-log((double)ni*(ni+1)/2));
				}
				else{
					if(eij!=0)
						log_likelihood_value += eij*(log((double)eij)-log((double)ni*nj));
					if((ni*nj-eij)!=0)
						log_likelihood_value += (ni*nj-eij)*(log((double)ni*nj-eij)-log((double)ni*nj));
				}			
			}
		}
	}
	if (!typemodel.getGraph().isDirected() && !typemodel.getGraph().hasSelfloop()){		
		for (i=0; i<numtype; i++){
			for (j=i; j<numtype; j++) {
				eij = typemodel.m_numEdgesOf2Groups[i][j];
				ni=typemodel.m_groupCardiTable[i];
				nj=typemodel.m_groupCardiTable[j];
				if(i==j){
					if(eij!=0)
						log_likelihood_value += eij*(log((double)eij)-log((double)ni*(ni-1)/2));
					if((ni*(ni-1)/2-eij)!=0)
						log_likelihood_value += (ni*(ni-1)/2-eij)*(log((double)ni*(ni-1)/2-eij)-log((double)ni*(ni-1)/2));
				}
				else{
					if(eij!=0)
						log_likelihood_value += eij*(log((double)eij)-log((double)ni*nj));
					if((ni*nj-eij)!=0)
						log_likelihood_value += (ni*nj-eij)*(log((double)ni*nj-eij)-log((double)ni*nj));
				}		
			}
		}
	}
	if(m_groupCorrected)
		groupCorrectLLH(typemodel, log_likelihood_value);
	return log_likelihood_value;
}
//This method returns the likelihood of the current Type Model (model type is 3 <degree corrected block model>)
double MCMC::calcLikelihoodM3(const TypeModel & typemodel){
	unsigned i,j;
	unsigned eij;
	unsigned numtype=typemodel.getNumType();
	//double likelihood_value=0.0;
	double log_likelihood_value=0.0;
	if (typemodel.getGraph().isDirected()){
		unsigned kiout;
		unsigned kjin;
		for (i=0; i<numtype; i++){
			for (j=0; j<numtype; j++) {
				eij=typemodel.m_numEdgesOf2Groups[i][j];
				if(eij!=0){
					kiout=typemodel.m_groupOutDegrees[i];
					kjin=typemodel.m_groupInDegrees[j];
					log_likelihood_value = log_likelihood_value + eij*(getLog(eij)-getLog(kiout)-getLog(kjin));
				}
			}
		}
	}
	else	
		log_likelihood_value=calcLLH_DC_UD(typemodel);
	if(m_groupCorrected)
		groupCorrectLLH(typemodel, log_likelihood_value);
	//if (!typemodel.getGraph().isDirected()){	
	//	unsigned ki;
	//	unsigned kj;
	//	double vari;
	//	for (i=0; i<numtype; i++){
	//		for (j=0; j<numtype; j++) {
	//			if(i==j)
	//				eij=2*typemodel.m_numEdgesOf2Groups[i][j];
	//			else 
	//				eij=typemodel.m_numEdgesOf2Groups[i][j];
	//			vari=0;
	//			if(eij!=0){
	//				ki=typemodel.m_groupDegrees[i];
	//				kj=typemodel.m_groupDegrees[j];
	//				vari = eij*(log((double)eij)-log((double)ki)-log((double)kj));
	//			}	
	//			log_likelihood_value+=vari;
	//		}
	//	}
	//}
	return log_likelihood_value;
}

//This method returns the likelihood of the current Type Model (model type is 4 <degree corrected (with integral of w_ij) block model>)
double MCMC::calcLikelihoodM4(const TypeModel & typemodel){
	unsigned i,j;
	unsigned eij;
	unsigned numtype=typemodel.getNumType();
	double a;
	double b=1/2+1/W_BAR;
	double b_d=1+1/W_BAR;
	double log_bd=log(b_d);
	//double likelihood_value=0.0;
	double log_likelihood_value=0.0;
	if (typemodel.getGraph().isDirected()){
		unsigned kiout;
		unsigned kjin;
		for (i=0; i<numtype; i++){
			for (j=0; j<numtype; j++) {
				eij=typemodel.m_numEdgesOf2Groups[i][j];
				kiout=typemodel.m_groupOutDegrees[i];
				kjin=typemodel.m_groupInDegrees[j];
				log_likelihood_value+=getLogFac(eij)-(1+eij)*log_bd-eij*(getLog(kiout)+getLog(kjin));
			}
		}
		//log_likelihood_value-=(double)numtype*numtype*log(b_d);
	}
	//typemodel.printModelInfo();
	if (!typemodel.getGraph().isDirected()){	
		double vari;
		unsigned ki;
		unsigned kj;
		for (i=0; i<numtype; i++){
			ki=typemodel.m_groupDegrees[i];
			log_likelihood_value-=ki*getLog(ki);
			for (j=i; j<numtype; j++) {
				eij=typemodel.m_numEdgesOf2Groups[i][j];
				if(i==j)
					a=eij;					
				else 
					a=(double)eij/2;				
				kj=typemodel.m_groupDegrees[j];
				vari=m_loggammatable[2+(int)(2*a)]-(1+a)*log(b);//-a*(getLog(ki)+getLog(kj));	
				if(i==j){
					log_likelihood_value+=vari;
				}else{
					log_likelihood_value+=2*vari;
				}
			}
		}
	}
	if(m_groupCorrected)
		groupCorrectLLH(typemodel, log_likelihood_value);
	return log_likelihood_value;
}
//This method returns the likelihood of the current Type Model (model type is 5 <degree corrected block model> weighted orientation)
double MCMC::calcLikelihoodM5(const TypeModel & typemodel){
	unsigned i,j;
	unsigned eij;
	unsigned numtype=typemodel.getNumType();
	//double likelihood_value=0.0;
	double log_likelihood_value=0.0;
	if (typemodel.getGraph().isDirected()){
		unsigned ki;
		unsigned kj;
		double vari;
		unsigned eij_out=0;
		unsigned eij_in=0;
		for (i=0; i<numtype; i++){
			ki=typemodel.m_groupDegrees[i];
			for (j=i; j<numtype; j++) {
				eij_out=typemodel.m_numEdgesOf2Groups[i][j];
				eij_in=typemodel.m_numEdgesOf2Groups[j][i];
				eij=eij_out+eij_in;
				vari=0;
				if(eij!=0){					
					kj=typemodel.m_groupDegrees[j];
					vari = eij*(getLog(eij)-getLog(ki)-getLog(kj));
				}	
				if(i==j){
					log_likelihood_value+=0.5*vari;
					log_likelihood_value-=m_dfac*eij_out*getLog(2);//+e_{rs}*log(1/2)
				}else{
					log_likelihood_value+=vari;
					log_likelihood_value+=m_dfac*eij_out*(getLog(eij_out)-getLog(eij));//+e_{rs}^{out}*log(y_{r->s})
					log_likelihood_value+=m_dfac*eij_in*(getLog(eij_in)-getLog(eij));//+e_{rs}^{in}*log(y_{s->r})
				}
			}
		}
	}
	else	
		log_likelihood_value=calcLLH_DC_UD(typemodel);
	if(m_groupCorrected)
		groupCorrectLLH(typemodel, log_likelihood_value);
	return log_likelihood_value;
}
//This method returns the likelihood of the current Type Model (special case for DC model type 5, orientation weight is 1.)
double MCMC::calcLikelihoodM6(const TypeModel & typemodel){
	unsigned i,j;
	unsigned eij;
	unsigned numtype=typemodel.getNumType();
	//double likelihood_value=0.0;
	double log_likelihood_value=0.0;
	if (typemodel.getGraph().isDirected()){
		unsigned ki;
		unsigned kj;
		double vari;
		for (i=0; i<numtype; i++){
			for (j=0; j<numtype; j++) {
				eij=typemodel.m_numEdgesOf2Groups[i][j];
				vari=0;
				ki=typemodel.m_groupDegrees[i];
				kj=typemodel.m_groupDegrees[j];
				vari = eij*(getLog(eij)-getLog(ki)-getLog(kj));
				log_likelihood_value+=vari;
			}
		}
	}
	else	
		log_likelihood_value=calcLLH_DC_UD(typemodel);
	if(m_groupCorrected)
		groupCorrectLLH(typemodel, log_likelihood_value);
	return log_likelihood_value;
}
double MCMC::calcLikelihoodM7(const TypeModel & typemodel){
	unsigned i,j;
	unsigned eij;
	unsigned numtype=typemodel.getNumType();
	//double likelihood_value=0.0;
	double log_likelihood_value=0.0;
	if (typemodel.getGraph().isDirected()){
		unsigned ki;
		unsigned kj;
		double vari;
		for (i=0; i<numtype; i++){
			for (j=0; j<numtype; j++) {
				eij=typemodel.m_numEdgesOf2Groups[i][j];
				vari=0;
				ki=typemodel.m_groupOutDegrees[i];
				kj=typemodel.m_groupDegrees[j];
				vari = eij*(getLog(eij)-getLog(ki)-getLog(kj));
				log_likelihood_value+=vari;
			}
		}
	}
	else	
		log_likelihood_value=calcLLH_DC_UD(typemodel);
	if(m_groupCorrected)
		groupCorrectLLH(typemodel, log_likelihood_value);
	return log_likelihood_value;
}
double MCMC::calcLikelihoodM8(const TypeModel & typemodel){
	unsigned i,j;
	unsigned eij;
	unsigned numtype=typemodel.getNumType();
	//double likelihood_value=0.0;
	double log_likelihood_value=0.0;
	if (typemodel.getGraph().isDirected()){
		unsigned ki;
		unsigned kj;
		double vari;
		for (i=0; i<numtype; i++){
			for (j=0; j<numtype; j++) {
				eij=typemodel.m_numEdgesOf2Groups[i][j];
				vari=0;
				ki=typemodel.m_groupDegrees[i];
				kj=typemodel.m_groupInDegrees[j];
				vari = eij*(getLog(eij)-getLog(ki)-getLog(kj));
				log_likelihood_value+=vari;
			}
		}
	}
	else	
		log_likelihood_value=calcLLH_DC_UD(typemodel);
	if(m_groupCorrected)
		groupCorrectLLH(typemodel, log_likelihood_value);
	return log_likelihood_value;
}
double MCMC::calcGraphLikelihood(){
	unsigned i;	
	set<unsigned> topvtxset;
	const Graph & graph=m_typeModel.getGraph();
	TypeModel typemodel(graph,graph.getNumType(),m_typeModel.m_frozenTypesInGraph);
	for(i=0;i<this->m_numVtx;i++){
		topvtxset.insert(i);
	}
	typemodel.randInitGroups(topvtxset);
	return calcLikelihood(typemodel);
}
double MCMC::calcGraphLikelihoodM1(){
	unsigned i,j,a,b;
	//double likelihood_value=0.0;
	unsigned graphNumType=m_typeModel.getGraph().getNumType();
	double log_likelihood_value=0.0;
	if (m_typeModel.getGraph().isDirected() && m_typeModel.getGraph().hasSelfloop()){
		for (i=0; i<graphNumType; i++){
			for (j=0; j<graphNumType; j++) {
				a = m_typeModel.getGraph().getGroupConnNumMatrixElem(i,j);
				b = m_typeModel.getGraph().getGroupCardi(i) * m_typeModel.getGraph().getGroupCardi(j) - a;
				log_likelihood_value = log_likelihood_value + getLogFac(a) + getLogFac(b) - getLogFac(a+b+1);
			}
		}
	}
	if (m_typeModel.getGraph().isDirected() && !m_typeModel.getGraph().hasSelfloop()){		
		for (i=0; i<graphNumType; i++){
			for (j=0; j<graphNumType; j++) {
				a = m_typeModel.getGraph().getGroupConnNumMatrixElem(i,j);
				if(i==j)					
					b = m_typeModel.getGraph().getGroupCardi(i) * (m_typeModel.getGraph().getGroupCardi(i)-1) - a;
				else
					b = m_typeModel.getGraph().getGroupCardi(i) * m_typeModel.getGraph().getGroupCardi(j) - a;
				log_likelihood_value = log_likelihood_value + getLogFac(a) + getLogFac(b) - getLogFac(a+b+1);				
			}
		}
	}
	if (!m_typeModel.getGraph().isDirected() && m_typeModel.getGraph().hasSelfloop()){		
		for (i=0; i<graphNumType; i++){
			for (j=i; j<graphNumType; j++) {
				a = m_typeModel.getGraph().getGroupConnNumMatrixElem(i,j);
				if(i==j)					
					b = m_typeModel.getGraph().getGroupCardi(i) * (m_typeModel.getGraph().getGroupCardi(i)-1) / 2 + m_typeModel.getGraph().getGroupCardi(i) - a;
				else
					b = m_typeModel.getGraph().getGroupCardi(i) * m_typeModel.getGraph().getGroupCardi(j) - a;
				log_likelihood_value = log_likelihood_value + getLogFac(a) + getLogFac(b) - getLogFac(a+b+1);				
			}
		}
	}
	if (!m_typeModel.getGraph().isDirected() && !m_typeModel.getGraph().hasSelfloop()){		
		for (i=0; i<graphNumType; i++){
			for (j=i; j<graphNumType; j++) {
				a = m_typeModel.getGraph().getGroupConnNumMatrixElem(i,j);
				if(i==j)					
					b = m_typeModel.getGraph().getGroupCardi(i) * (m_typeModel.getGraph().getGroupCardi(i)-1) / 2 - a;
				else
					b = m_typeModel.getGraph().getGroupCardi(i) * m_typeModel.getGraph().getGroupCardi(j) - a;
				log_likelihood_value = log_likelihood_value + getLogFac(a) + getLogFac(b) - getLogFac(a+b+1);				
			}
		}
	}
	if(m_groupCorrected)
		groupCorrectLLH(m_typeModel, log_likelihood_value);
	return log_likelihood_value;
}
void MCMC::initMargDistri(){
	unsigned i;
	m_accumuMargDistri=new double*[m_numVtx];
	for(i=0;i<m_numVtx;i++){
		m_accumuMargDistri[i]=new double[m_numType];
	}
	m_numAccumuMargDistri=new long[m_numVtx];
	for(i=0;i<m_numVtx;i++)
		m_numAccumuMargDistri[i]=0l;
}
void MCMC::updateMargDistri(){
	unsigned i;
	for(i=0;i<m_LHVariPairs.size();i++){		
		m_accumuMargDistri[m_mutateVtxNo][m_LHVariPairs[i].first]+=m_LHVariPairs[i].second;
	}
	m_numAccumuMargDistri[m_mutateVtxNo]++;
}
double ** MCMC::getMargDistri(){
	unsigned i,j;
	for(i=0;i<m_numVtx;i++){
		for(j=0;j<m_numType;j++){
			m_accumuMargDistri[i][j]/=m_numAccumuMargDistri[i];
		}
	}
	return m_accumuMargDistri;
}

void MCMC::groupCorrectLLH(const TypeModel & typemodel, double & llhvalue){
	unsigned i;
	unsigned mtype;
	unsigned mcardi;
	unsigned gtype;
	unsigned gcardi;
	for(i=0;i<m_numVtx;i++){
		gtype=typemodel.getGraph().getVertex(i).getType();		
		gcardi=typemodel.getGraph().getGroupCardi(gtype);
		mtype=typemodel.getVtxType(i);
		mcardi=typemodel.m_groupCardiTable[mtype];
		//llhvalue+=log((double)gcardi/m_numVtx);
		llhvalue+=log((double)mcardi);
	}
}
//calculate the log-likelihood value for degree-corrected undirected typemodel.
double MCMC::calcLLH_DC_UD(const TypeModel & typemodel){
	unsigned i,j;
	unsigned ki,kj,eij;
	double vari;
	double llhvalue=0.0;
	unsigned numtype=typemodel.getNumType();
	for (i=0; i<numtype; i++){
		for (j=i; j<numtype; j++) {
			if(i==j)
				eij=2*typemodel.m_numEdgesOf2Groups[i][j];
			else 
				eij=typemodel.m_numEdgesOf2Groups[i][j];
			vari=0;
			if(eij!=0){
				ki=typemodel.m_groupDegrees[i];
				kj=typemodel.m_groupDegrees[j];
				vari = eij*(getLog(eij)-getLog(ki)-getLog(kj));
			}	
			if(i==j){
				llhvalue+=0.5*vari;
			}else{
				llhvalue+=vari;
			}
		}
	}
	return llhvalue;
}