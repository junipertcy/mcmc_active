#ifndef GRAPH_H
#define GRAPH_H

#include "Global.h"

class Graph{
public:
	Graph(string sGraphFile);
	Graph();
	Graph(string sGraphFile, const vector<string> & mostLikelyValues);
	~Graph(void);	
private:
	class Vertex;
public:
	vector<unsigned> vtxSelfloopFlag;	
public:
	unsigned getNumVtx() const { return m_numVtx; }
	unsigned getNumEgs() const { return m_numEgs; }
	unsigned getNumType() const { return m_numType; }
	bool checkEdge(unsigned source, unsigned target) const;
	void setDirected(bool b_direc) {m_directed=b_direc;}
	void setSelfloop(bool b_sl) {m_selfloop=b_sl;}
	bool isDirected() const { return m_directed; }
	bool hasSelfloop() const { return m_selfloop; }	
	unsigned getNumSelfloop() const { return m_numSelfloop; }
	ostream & printGraphInfo(ostream & = cout) const;	
	string getValueFromType(unsigned type) const;
	double getGroupConnMatrixElem(unsigned i, unsigned j) const {return m_groupConnMatrix[i][j];}
	unsigned getGroupConnNumMatrixElem(unsigned i, unsigned j) const {return m_groupConnNumMatrix[i][j];}
	unsigned getGroupCardi(unsigned groupNo) const;
	const Vertex& getVertex(unsigned vtxno) const;
	bool vtxHasSelfloop(unsigned vtxno) const {return vtxSelfloopFlag[vtxno];}
	const unsigned getVtxDegree(unsigned vtxno) const;
private:
	ostream & printGraphData(ostream& = cout) const;
	void calcNumEdges();
	void calcGroupConnNumMatrix();
	void calcGroupConnMatrix();	
private:
	unsigned m_numVtx;
	unsigned m_numType;
	unsigned m_numEgs;
	bool m_directed;
	bool m_selfloop;
	unsigned m_numSelfloop;
	vector<Vertex> vtxList;	
private:
	map<unsigned,string> m_mapIndex2Id;
	map<string,unsigned> m_mapId2Index;
	map<string,unsigned> m_mapValue2Type;
	map<unsigned,string> m_mapType2Value;
private:
	unsigned ** m_groupConnNumMatrix;//groupConnNumMatrix[i][j] is the number of edges start from group i and target to group j
	double ** m_groupConnMatrix;//groupConnMatrix[i][j] is the connection probability from group i to group j
	unsigned * m_groupCardi;
private:
	class Vertex{
		friend class Graph;
	public:
		string m_id;
		unsigned m_index;
		string m_value;
		unsigned m_type;
		set<unsigned> m_targets;
		set<unsigned> m_sources;
	public:
		Vertex(){m_id=""; m_value="";}
		void setId(string vtx_id){m_id=vtx_id;}
		string getId() const {return m_id;}
		void setIndex(unsigned vtx_index){m_index=vtx_index;}
		unsigned getIndex() const {return m_index;}
		void setValue(string vtx_value){m_value=vtx_value;}
		string getValue() const {return m_value;}
		void setType(unsigned vtx_type){m_type=vtx_type;}
		unsigned getType() const {return m_type;}
		void addTarget(unsigned target){m_targets.insert(target);}
		void addTargets(vector<unsigned>& targets) {m_targets.insert(targets.begin(),targets.end());}
		void addSource(unsigned source) {m_sources.insert(source);}
		void addSources(vector<unsigned>& sources) {m_sources.insert(sources.begin(),sources.end());}
		const set<unsigned>& getSources() const {return m_sources;}
		const set<unsigned>& getTargets() const {return m_targets;}
		const unsigned getOutDegree() const {return m_targets.size();}
		const unsigned getInDegree() const {return m_sources.size();}		
	};
};

#endif
