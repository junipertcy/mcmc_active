#ifndef MAXDEGREELEARNER_H
#define MAXDEGREELEARNER_H

#include "Learner.h"

class MaxDegree :
	public Learner
{
public:
	MaxDegree(const MCMC & mca,const MCMC & mcb,const set<unsigned> & topVtxSet): Learner(mca, mcb, topVtxSet, "Query Vertex with Max Degree in the Remaining Graph"){}
	~MaxDegree(void){};
public:
	virtual void resetForNextPhase(){}	
	virtual void resetForNextInit(){}
	virtual unsigned getTopVtx(unsigned *arrayTop, unsigned numTop);
	virtual void updateData(){}
	virtual ostream& printPhaseResult(ostream& = cout) const;
	virtual string getMethodName() const {return m_methodName;}
	virtual unsigned getNumVtx() const {return Learner::getNumVtx();}
	virtual unsigned getNumTypeGraph() const {return Learner::getNumTypeGraph();}
	virtual unsigned getNumTypeModel() const {return Learner::getNumTypeModel();}
private:

};

#endif
