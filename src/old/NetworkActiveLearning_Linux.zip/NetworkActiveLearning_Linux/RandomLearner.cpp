#include "RandomLearner.h"
#include "Utility.cpp"

unsigned RandomLearner::getTopVtx(unsigned *arrayTop, unsigned numTop){
	unsigned i;
	vector<unsigned> remainVertices;
	unsigned randindex;
	unsigned numremainvtx=m_numVtx-(unsigned)(m_topVtxSet.size());
	m_numtop=min(numTop,numremainvtx);
	for(i=0;i<m_numVtx;i++){
		if(m_topVtxSet.count(i))
			continue;
		else 
			remainVertices.push_back(i);		
	}
	for(i=0;i<m_numtop;i++){
		randindex=randN(remainVertices.size());
		arrayTop[i]=remainVertices[randindex];
		remainVertices.erase(remainVertices.begin()+randindex);
	}
	////////////////////////////////////
	cout<<"tops:"<<endl;
	for(i=0;i<m_numtop;i++){
		cout<<arrayTop[i]<<'\t';
	}
	cout<<endl;
	//
	return m_numtop;
}
ostream& RandomLearner::printPhaseResult(ostream& os) const{
	//unsigned i,j;
	os<<"Query Vertex Randomly"<<endl;
	/*for(i=0,j=0;i<m_arraysize;i++,j++){
		while(j<m_arrayVtxNo[i]){
			os<<"Node "<<j<<" :\t"<<"Queried"<<"\n";	
			j++;
		}
		os<<"Node "<<m_arrayVtxNo[i]<<" :\t"<<"Not Queried"<<"\n";		
	}
	while(j<m_numVtx){
		os<<"Node "<<j<<" :\t"<<-1.0<<"\n";	
		j++;
	}*/
	return os;
}