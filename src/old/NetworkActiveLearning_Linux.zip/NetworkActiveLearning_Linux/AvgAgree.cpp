#include "AvgAgree.h"
#include "Utility.cpp"

AvgAgree::AvgAgree(MCMC & mca, MCMC & mcb, const set<unsigned> & topVtxSet):Learner(mca,mcb,topVtxSet,"Average Agreement")
{
	m_avgAgreeNume=new long long[m_numVtx];
	m_avgAgreeDeno=new long long[m_numVtx];
	m_needInitUpdate=true;
}

AvgAgree::~AvgAgree(void)
{
	delete [] m_avgAgreeNume;
	delete [] m_avgAgreeDeno;
}
void AvgAgree::resetForNextPhase(){	
	for(unsigned i=0;i<m_numVtx;i++){
		 m_avgAgreeNume[i]=0;
		 m_avgAgreeDeno[i]=0;
	}
}
void AvgAgree::resetForNextInit(){
	m_needInitUpdate=true;
	m_agreeVtxSet.clear();
}
void AvgAgree::updateData(){
	if(m_needInitUpdate){
		initUpdate();
		m_needInitUpdate=false;
        //testAgreeNum();
		return;
	}
	updateData_Local();
   // testAgreeNum();
}
unsigned AvgAgree::getTopVtx(unsigned *arrayTop, unsigned numTop){
	unsigned i;
	double avgagreevalue;

	for(i=0,m_arraysize=0;i<m_numVtx;i++){
		if(m_topVtxSet.count(i))
			continue;
		if(m_avgAgreeDeno[i]==0){
			cerr<<"need more MCMC steps"<<endl;
			avgagreevalue=0;
		}else{
			avgagreevalue=((double)m_avgAgreeNume[i])/((double)m_avgAgreeDeno[i]);
		}
		m_arrayLearnScores[m_arraysize]=avgagreevalue;
		m_arrayLearnScoresSort[m_arraysize]=avgagreevalue;
		m_arrayVtxNo[m_arraysize]=i;
		m_arrayVtxNoSort[m_arraysize++]=i;
	}
	quicksort<double,unsigned>(m_arrayLearnScoresSort, m_arrayVtxNoSort, 0, m_arraysize-1);
	//
	unsigned m_numtop = 0;
	set<unsigned>::const_iterator siiter;
	unsigned firsttopvtxno=0;
	bool isNeighbor = false;
	set<unsigned> neighbors;
	unsigned neighborsize=0;
	switch(QUERYSTRATEGY){
		case 1:
			for (i = m_arraysize - 1; (i >= 0) && (m_numtop < numTop); i--) {
				m_arrayTopVtxNo[m_numtop++] = m_arrayVtxNoSort[i];
			}
			break;
		case 2:
			for (i = m_arraysize - 1; (i >= 0) && (m_numtop < numTop); i--) {
				isNeighbor = false;
				siiter = m_topVtxSet.begin();
				for (; siiter != m_topVtxSet.end(); siiter++) {
					if ((m_MC_A.getTypeModel().getGraph().checkEdge(*siiter, m_arrayVtxNoSort[i]))
							|| (m_MC_A.getTypeModel().getGraph().checkEdge(m_arrayVtxNoSort[i],
									*siiter))) {
						isNeighbor = true;
						m_arrayTopVtxNo[m_numtop++] = m_arrayVtxNoSort[i];
						cout << "AA rank of the vtx queried:  " << m_arraysize - i
								<< endl;
						break;
					}
				}
				if ((!isNeighbor) && (rand01() < 0.0)) {
					m_arrayTopVtxNo[m_numtop++] = m_arrayVtxNoSort[i];
					cout << "AA rank of the vtx queried:  " << m_arraysize - i << endl;
				}
			}
			break;
		case 3:// get the vtx with largest AA value and all its neighbors
			firsttopvtxno=m_arrayVtxNoSort[m_arraysize - 1];
			neighbors.insert(firsttopvtxno);
			neighbors.insert(m_MC_A.getTypeModel().getGraph().getVertex(firsttopvtxno).getSources().begin(),
					m_MC_A.getTypeModel().getGraph().getVertex(firsttopvtxno).getSources().end());
			neighbors.insert(m_MC_A.getTypeModel().getGraph().getVertex(firsttopvtxno).getTargets().begin(),
					m_MC_A.getTypeModel().getGraph().getVertex(firsttopvtxno).getTargets().end());
			siiter=neighbors.begin();
			for(;siiter!=neighbors.end();siiter++){
				if(!(m_topVtxSet.count(*siiter)))
					m_arrayTopVtxNo[m_numtop++] = *siiter;
			}
			break;
		case 4:// get the vtx with largest AA value and its up to "numTop-1" neighbors if it has so many neighbors
			firsttopvtxno=m_arrayVtxNoSort[m_arraysize - 1];
			neighbors.insert(firsttopvtxno);
			neighborsize=1;
			for (i = m_arraysize - 1; (i >= 0) && (neighborsize < numTop); i--) {
				if((m_MC_A.getTypeModel().getGraph().getVertex(firsttopvtxno).getSources().count(m_arrayVtxNoSort[i]))||
						(m_MC_A.getTypeModel().getGraph().getVertex(firsttopvtxno).getTargets().count(m_arrayVtxNoSort[i]))){
					neighbors.insert(m_arrayVtxNoSort[i]);
					neighborsize++;
				}
			}
			for(siiter=neighbors.begin();siiter!=neighbors.end();siiter++){
				m_arrayTopVtxNo[m_numtop++] = *siiter;
			}
			break;
		default:
			for (i = m_arraysize - 1; (i >= 0) && (m_numtop < numTop); i--) {
				m_arrayTopVtxNo[m_numtop++] = m_arrayVtxNoSort[i];
			}
	}
	////////////////////////////////////
	cout<<"tops:"<<endl;
	for(i=0;i<m_numtop;i++){
		arrayTop[i]=m_arrayTopVtxNo[i];
		cout<<arrayTop[i]<<'\t';
	}
	cout<<endl;
	//
	return m_numtop;
}
ostream& AvgAgree::printPhaseResult(ostream& os) const{	
	unsigned i,j;
	os<<"average agreement values:"<<endl;
	for(i=0,j=0;i<m_arraysize;i++,j++){
		while(j<m_arrayVtxNo[i]){
			os<<"Node "<<j<<" :\t"<<-1.0<<"\n";	
			j++;
		}
		os<<"Node "<<m_arrayVtxNo[i]<<" :\t"<<m_arrayLearnScores[i]<<"\n";		
	}
	while(j<m_numVtx){
		os<<"Node "<<j<<" :\t"<<-1.0<<"\n";	
		j++;
	}
	return os;
}
void AvgAgree::initUpdate(){
	unsigned i;
	unsigned agreenum;
	for(i=0;i<m_numVtx;i++){
		if(m_topVtxSet.count(i)==0 && m_MC_A.getTypeModel().getVtxType(i)== m_MC_B.getTypeModel().getVtxType(i))
			m_agreeVtxSet.insert(i);
	}
	set<unsigned>::const_iterator siiter=m_agreeVtxSet.begin();
	agreenum=m_agreeVtxSet.size()+m_topVtxSet.size();
	for(;siiter!=m_agreeVtxSet.end();siiter++){
		m_avgAgreeNume[*siiter]+=agreenum;
		m_avgAgreeDeno[*siiter]++;
	};
}

void AvgAgree::updateData_Local(){
	set<unsigned>::iterator siiter;
	unsigned mutateVtxA=m_MC_A.getMutateVtx();
	unsigned mutateVtxB=m_MC_B.getMutateVtx();
	if(m_MC_A.getTypeModel().getVtxType(mutateVtxA)==m_MC_B.getTypeModel().getVtxType(mutateVtxA)){
		if(!(m_agreeVtxSet.count(mutateVtxA))){
			m_agreeVtxSet.insert(mutateVtxA);
		}
	}else if((siiter=m_agreeVtxSet.find(mutateVtxA))!=m_agreeVtxSet.end()){
		m_agreeVtxSet.erase(siiter);
	}
	if(m_MC_A.getTypeModel().getVtxType(mutateVtxB)==m_MC_B.getTypeModel().getVtxType(mutateVtxB)){
		if(!(m_agreeVtxSet.count(mutateVtxB))){
			m_agreeVtxSet.insert(mutateVtxB);
		}
	}else if((siiter=m_agreeVtxSet.find(mutateVtxB))!=m_agreeVtxSet.end()){
		m_agreeVtxSet.erase(siiter);
	}
	siiter=m_agreeVtxSet.begin();
	for(;siiter!=m_agreeVtxSet.end();siiter++){
		m_avgAgreeNume[*siiter]+=(m_agreeVtxSet.size()+m_topVtxSet.size());
		m_avgAgreeDeno[*siiter]++;
	}
}


void AvgAgree::testAgreeNum(){
	unsigned i;
	unsigned realagreenum=0;
	unsigned ouragreenum=m_agreeVtxSet.size()+m_topVtxSet.size();
	set<unsigned>::const_iterator ciiter;
	for(i=0;i<m_numVtx;i++){
		if(m_MC_A.getTypeModel().getVtxType(i)==m_MC_B.getTypeModel().getVtxType(i))
			realagreenum++;
	}	
	if(realagreenum==ouragreenum)
		cout<<"our agree number is correct!\t"<<realagreenum<<'\t'<<ouragreenum<<'\t'<<m_agreeVtxSet.size()<<"\t"<<m_topVtxSet.size()<<endl;
	else{
		cout<<"our agree number is wrong!\t"<<realagreenum<<'\t'<<ouragreenum<<'\t'<<m_agreeVtxSet.size()<<"\t"<<m_topVtxSet.size()<<endl;
	}
}
