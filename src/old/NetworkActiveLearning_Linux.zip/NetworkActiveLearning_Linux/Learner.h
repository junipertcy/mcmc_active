#ifndef LEARNER_H
#define LEARNER_H

//#include "TypeModel.h"
#include "MCMC.h"

class Learner
{
protected:
	Learner(const MCMC & mca,const MCMC & mcb,const set<unsigned> & topVtxSet, string methodname);
public:	
	virtual ~Learner(void);
public:
	virtual void resetForNextPhase() = 0;	
	virtual void resetForNextInit() = 0;
	virtual unsigned getTopVtx(unsigned *arrayTop, unsigned numTop) = 0;
	virtual void updateData()=0;
	virtual ostream& printPhaseResult(ostream& = cout) const = 0;
	virtual string getMethodName() const = 0;
	virtual unsigned getNumVtx() const {return m_MC_A.getTypeModel().getGraph().getNumVtx();}
	virtual unsigned getNumTypeGraph() const {return m_MC_A.getTypeModel().getGraph().getNumType();}
	virtual unsigned getNumTypeModel() const {return m_MC_A.getTypeModel().getNumType();}
protected:
	const MCMC & m_MC_A;
	const MCMC & m_MC_B;
	const set<unsigned> & m_topVtxSet;
	unsigned m_numVtx;// number of vertices in graph
	unsigned m_numType;// number of types in the model (may be not that in the real graph)
	static const unsigned QUERYSTRATEGY;// query strategy
	string m_methodName;
//phase result data
	unsigned m_arraysize;
	unsigned m_numtop;
	unsigned * m_arrayTopVtxNo;//some query strategies may output more than "numTop" vertices
	unsigned * m_arrayVtxNo;
	unsigned * m_arrayVtxNoSort;
	double * m_arrayLearnScores;
	double * m_arrayLearnScoresSort;
};

#endif