#include "Graph.h"


Graph::Graph(string sGraphFileName){
	unsigned i;
	//bool isblogud=true;
	bool isblogud=false;
	ifstream infile(sGraphFileName.c_str());

	/************************************/
	string vtxdeg0filename("vtxDeg0IDs.txt");
	ifstream vtxdeg0file(vtxdeg0filename.c_str());
	set<string> vtxdeg0ids;
	string words;
	if(isblogud){		
		while(vtxdeg0file>>words){
			vtxdeg0ids.insert(words);
		}
	}
	/************************************/

	if(!infile){
		cerr<<"unable to open the input graph data file:"
			<<sGraphFileName<<endl;	
	}	
	set<unsigned> selfloopVtxSet;
	m_numVtx=0;
	m_numType=0;
	set<string> seenIds;
	set<string> seenValues;
	string word;	
	string id;
	string value;
	unsigned type;
	string sourceid;
	string targetid;
	unsigned sourceindex;
	unsigned targetindex;
	setSelfloop(false);
	setDirected(false);	
	while(infile>>word){
		if (word.compare("directed")==0)
		{
			infile>>word;
			if (word.compare("1")==0)
				this->setDirected(true);
			else
				this->setDirected(false);
			break;
		}
	}
	while(infile>>word){
		if (word.compare("node")==0)
		{

			Vertex vtx=Vertex();
			while(infile>>word){
				if (word.compare("id")==0)
				{
					infile>>id;
					//id=atoi(word.c_str());
					vtx.setId(id);					
				}
				if (word.compare("type")==0||word.compare("value")==0)
				{
					infile>>value;
					vtx.setValue(value);					
				}
				if (word.compare("]")==0)
					break;
			}
			/************************************/
			if(isblogud && (vtxdeg0ids.count(id))){
				;
			}
			else{

			/************************************/
			if(seenIds.count(id)){
				continue;
			}else{
				vtx.setIndex(m_numVtx);
				m_mapId2Index.insert(valType_su(id,m_numVtx));
				seenIds.insert(id);					
			}
			if(seenValues.count(value)){
				type=m_mapValue2Type[value];
				vtx.setType(type);
			}else{
				type=m_numType;
				vtx.setType(m_numType);
				m_mapValue2Type.insert(valType_su(value,m_numType));
				seenValues.insert(value);				
				m_numType++;				
			}
			m_mapIndex2Id.insert(valType_us(m_numVtx,id));
			m_mapType2Value.insert(valType_us(type,value));
			m_numVtx++;				
			this->vtxList.push_back(vtx);
			/*************************/
			}
			/*************************/
		
		}
		if (word.compare("edge")==0)
		{

			while(infile>>word){
				if (word.compare("source")==0)
				{
					infile>>sourceid;					
				}
				if (word.compare("target")==0)
				{
					infile>>targetid;					
				}
				if (word.compare("]")==0)
					break;
			}			
			if(m_mapId2Index.count(sourceid))
				sourceindex=m_mapId2Index[sourceid];
			else{
				sourceindex=0;
				cerr<<"unable to find the id information of the source vertex"<<endl;
				continue;
			}
			if(m_mapId2Index.count(targetid))
				targetindex=m_mapId2Index[targetid];
			else{
				targetindex=0;
				cerr<<"unable to find the id information of the target vertex"<<endl;
				continue;
			}
			if(sourceid.compare(targetid)==0){				
				selfloopVtxSet.insert(sourceindex);				
				setSelfloop(true);
			}
			vtxList[sourceindex].addTarget(targetindex);
			vtxList[targetindex].addSource(sourceindex);
			if(!m_directed){
				vtxList[sourceindex].addSource(targetindex);
				vtxList[targetindex].addTarget(sourceindex);
			}
		}
	}

	infile.close();

	m_numSelfloop=selfloopVtxSet.size();

	vtxSelfloopFlag.assign(m_numVtx,0);
	if(m_selfloop){
		for(i=0;i<m_numVtx;i++){
			if(selfloopVtxSet.count(i))
				vtxSelfloopFlag[i]=1;
		}
	}

	//
	m_groupConnNumMatrix=new unsigned*[m_numType];
	for(i=0;i<m_numType;i++)
		m_groupConnNumMatrix[i]=new unsigned[m_numType];
	m_groupCardi=new unsigned[m_numType];
	m_groupConnMatrix=new double*[m_numType];
	for(i=0;i<m_numType;i++)
		m_groupConnMatrix[i]=new double[m_numType];
	//

	calcNumEdges();

	//
	calcGroupConnNumMatrix();
	calcGroupConnMatrix();
}
Graph::Graph(string sGraphFile, const vector<string> & mostLikelyValues){
	unsigned i;
	ifstream infile(sGraphFile.c_str());
	if(!infile){
		cerr<<"unable to open the input graph data file:"
			<<sGraphFile<<endl;	
	}	
	set<unsigned> selfloopVtxSet;
	m_numVtx=0;
	m_numType=0;
	set<string> seenIds;
	set<string> seenValues;
	string word;	
	string id;
	string value;
	unsigned type;
	string sourceid;
	string targetid;
	unsigned sourceindex;
	unsigned targetindex;
	setSelfloop(false);
	setDirected(false);	
	vector<string>::const_iterator vecuiter=mostLikelyValues.begin();
	while(infile>>word){
		if (word.compare("directed")==0)
		{
			infile>>word;
			if (word.compare("1")==0)
				this->setDirected(true);
			else
				this->setDirected(false);
			break;
		}
	}
	while(infile>>word){
		if (word.compare("node")==0)
		{

			Vertex vtx=Vertex();
			while(infile>>word){
				if (word.compare("id")==0)
				{
					infile>>id;
					//id=atoi(word.c_str());
					vtx.setId(id);					
				}
				if (word.compare("type")==0||word.compare("value")==0)
				{
					infile>>value;
					if(vecuiter!=mostLikelyValues.end()){
						value=*vecuiter;											
						vecuiter++;						
					}										
					vtx.setValue(value);					
				}
				if (word.compare("]")==0)
					break;
			}		
			if(seenIds.count(id)){
				continue;
			}else{
				vtx.setIndex(m_numVtx);
				m_mapId2Index.insert(valType_su(id,m_numVtx));
				seenIds.insert(id);					
			}
			if(seenValues.count(value)){
				type=m_mapValue2Type[value];
				vtx.setType(type);
			}else{
				type=m_numType;
				vtx.setType(m_numType);
				m_mapValue2Type.insert(valType_su(value,m_numType));
				seenValues.insert(value);				
				m_numType++;				
			}
			m_mapIndex2Id.insert(valType_us(m_numVtx,id));
			m_mapType2Value.insert(valType_us(type,value));
			m_numVtx++;				
			this->vtxList.push_back(vtx);
		
		}
		if (word.compare("edge")==0)
		{

			while(infile>>word){
				if (word.compare("source")==0)
				{
					infile>>sourceid;					
				}
				if (word.compare("target")==0)
				{
					infile>>targetid;					
				}
				if (word.compare("]")==0)
					break;
			}			
			if(m_mapId2Index.count(sourceid))
				sourceindex=m_mapId2Index[sourceid];
			else{
				sourceindex=0;
				cerr<<"unable to find the id information of the source vertex"<<endl;
				continue;
			}
			if(m_mapId2Index.count(targetid))
				targetindex=m_mapId2Index[targetid];
			else{
				targetindex=0;
				cerr<<"unable to find the id information of the target vertex"<<endl;
				continue;
			}
			if(sourceid.compare(targetid)==0){				
				selfloopVtxSet.insert(sourceindex);				
				setSelfloop(true);
			}
			vtxList[sourceindex].addTarget(targetindex);
			vtxList[targetindex].addSource(sourceindex);
			if(!m_directed){
				vtxList[sourceindex].addSource(targetindex);
				vtxList[targetindex].addTarget(sourceindex);
			}
		}
	}

	infile.close();

	m_numSelfloop=selfloopVtxSet.size();

	vtxSelfloopFlag.assign(m_numVtx,0);
	if(m_selfloop){
		for(i=0;i<m_numVtx;i++){
			if(selfloopVtxSet.count(i))
				vtxSelfloopFlag[i]=1;
		}
	}

	//
	m_groupConnNumMatrix=new unsigned*[m_numType];
	for(i=0;i<m_numType;i++)
		m_groupConnNumMatrix[i]=new unsigned[m_numType];
	m_groupCardi=new unsigned[m_numType];
	m_groupConnMatrix=new double*[m_numType];
	for(i=0;i<m_numType;i++)
		m_groupConnMatrix[i]=new double[m_numType];
	//

	calcNumEdges();

	//
	calcGroupConnNumMatrix();
	calcGroupConnMatrix();
}
Graph::~Graph(void){
	unsigned i;
	for(i=0;i<m_numType;i++){
		delete [] m_groupConnNumMatrix[i];
	}	
	delete [] m_groupConnNumMatrix;

	for(i=0;i<m_numType;i++){
		delete [] m_groupConnMatrix[i];
	}	
	delete [] m_groupConnMatrix;
	delete [] m_groupCardi;
}
bool Graph::checkEdge(unsigned source, unsigned target) const{
	if(vtxList[source].m_targets.count(target)>0)
		return true;
	else
		return false;
}
void Graph::calcNumEdges(){
	unsigned i;
	int numEgs=0;
	for(i=0;i<vtxList.size();i++){	
		numEgs+=vtxList[i].getOutDegree();
	}
	if(m_directed)
		m_numEgs=numEgs;
	else if(!m_selfloop)
		m_numEgs=numEgs/2;
	else 
		m_numEgs=(numEgs+m_numSelfloop)/2;
}
string Graph::getValueFromType(unsigned type) const{
	map<unsigned,string>::const_iterator iter=m_mapType2Value.find(type);
	if(iter!=m_mapType2Value.end())
		return (*iter).second;
	else return ""; 
}
ostream & Graph::printGraphInfo(ostream & os) const{
	unsigned i,j;
	os<<"Group Cardinality:"<<endl;	
	for(i=0;i<m_numType;i++)
		os<<m_groupCardi[i]<<'\t';
	os<<endl;
	os<<"Group connection number matrix:"<<endl;	
	for(i=0;i<m_numType;i++){
		for(j=0;j<m_numType;j++){
			os<<getGroupConnNumMatrixElem(i,j)<<'\t';
		}
		os<<endl;
	}
	os<<"Group connection matrix:"<<endl;		
	for(i=0;i<m_numType;i++){
		for(j=0;j<m_numType;j++){
			os<<getGroupConnMatrixElem(i,j)<<'\t';
		}
		os<<endl;
	}
	os<<"Graph data:"<<endl;
	return printGraphData(os);
}
ostream & Graph::printGraphData(ostream & os) const{
	unsigned i, j;
	os<<"directed:  ";
	if (isDirected())
		os<<"yes"<<endl;
	else
		os<<"no"<<endl;
	os<<"has self-loop:  ";
	if (this->hasSelfloop()){
		os<<"yes"<<endl;
		os<<"number of self loops:\t"<<this->getNumSelfloop()<<endl;
	}
	else
		os<<"no"<<endl;
	os<<"node number:"<<getNumVtx()<<endl;
	os<<"edge number:"<<getNumEgs()<<endl;
	os<<"nodes:"<<endl;
	for(i=0;i<vtxList.size();i++)
	{
		os<<"ID: "<<vtxList[i].getId()<<"\tIndex: "<<vtxList[i].getIndex()<<"\tvalue: "<<vtxList[i].getValue()<<"\ttype: "<<vtxList[i].getType()<<endl;
	}
	os<<"edges:"<<endl;
	for(i=0;i<vtxList.size();i++)
	{		
		const set<unsigned> & edges=vtxList[i].getTargets();
		set<unsigned>::const_iterator siter=edges.begin();
		map<unsigned,string>::const_iterator mapiter_s;
		map<unsigned,string>::const_iterator mapiter_t;
		for(;siter!=edges.end();siter++)
		{
			mapiter_s=m_mapIndex2Id.find(i);
			mapiter_t=m_mapIndex2Id.find(*siter);
			if((mapiter_s!=m_mapIndex2Id.end())&&(mapiter_t!=m_mapIndex2Id.end()))
				os<<"source id: "<<(*mapiter_s).second<<"\ttarget id: "<<(*mapiter_t).second<<endl;
			os<<"source index: "<<i<<"\ttarget index: "<<*siter<<endl;
		}
	}
	os<<"has self loop?  ";
	if(hasSelfloop()){
		os<<"Yes"<<endl;
		os<<"Vertex selfloop flag:"<<endl;
		for(j=0;j<getNumVtx();j++){
			os<<"Vertex Index "<<j<<": "<<vtxSelfloopFlag[j]<<endl;
		}
	}
	else
		os<<"No"<<endl;
	return os;
}

void Graph::calcGroupConnNumMatrix(){	
	unsigned i,j;
	unsigned stype, ttype;

	for(i=0;i<m_numType;i++){
		for(j=0;j<m_numType;j++){
			m_groupConnNumMatrix[i][j]=0;
		}
	}
	for(i=0;i<m_numType;i++)
		m_groupCardi[i]=0;
	//unsigned numNodesD0=0;
	for(i=0;i<vtxList.size();i++){
		const set<unsigned> & edges=vtxList[i].getTargets();
		//const set<unsigned> & edges2=vtxList[i].getSources();
		//if(edges.size()==0&&edges2.size()==0)
			//numNodesD0++;
		set<unsigned>::const_iterator siter=edges.begin();
		stype=vtxList[i].getType();	
		m_groupCardi[stype]++;
		for(;siter!=edges.end();siter++)
		{
			ttype=vtxList[*siter].getType();
			if((!isDirected())&&(ttype==stype)&&((*siter)>i))
				continue;			
			m_groupConnNumMatrix[stype][ttype]++;
		}
	}	
	//cout<<"Number of Nodes with Degree 0: "<<numNodesD0<<endl;
}
void Graph::calcGroupConnMatrix(){
	unsigned i,j;
	if(m_directed&&(!m_selfloop)){//directed without selfloop
		for(i=0;i<m_numType;i++){
			for(j=0;j<m_numType;j++){
				if(m_groupConnNumMatrix[i][j]==0){
					m_groupConnMatrix[i][j]=0.0;
					continue;
				}
				if(i==j)
					m_groupConnMatrix[i][i]=(double)m_groupConnNumMatrix[i][i]/(double)m_groupCardi[i]/(double)(m_groupCardi[i]-1);
				else
					m_groupConnMatrix[i][j]=(double)m_groupConnNumMatrix[i][j]/(double)m_groupCardi[i]/(double)m_groupCardi[j];
			}
		}
	}else if(m_directed&&m_selfloop){//directed with selfloops
		for(i=0;i<m_numType;i++){
			for(j=0;j<m_numType;j++){
				if(m_groupConnNumMatrix[i][j]==0){
					m_groupConnMatrix[i][j]=0.0;
					continue;
				}
				m_groupConnMatrix[i][j]=(double)m_groupConnNumMatrix[i][j]/(double)m_groupCardi[i]/(double)m_groupCardi[j];
			}
		}
	}else if((!m_directed)&&(!m_selfloop)){//undirected without selfloop
		for(i=0;i<m_numType;i++){
			for(j=i;j<m_numType;j++){
				if(m_groupConnNumMatrix[i][j]==0){
					m_groupConnMatrix[i][j]=0.0;
					continue;
				}
				if(i==j)
					m_groupConnMatrix[i][i]=((double)(2*m_groupConnNumMatrix[i][i]))/(((double)m_groupCardi[i])*((double)(m_groupCardi[i]-1))); //  2eii/(ni*(ni-1))
				else
					m_groupConnMatrix[i][j]=((double)m_groupConnNumMatrix[i][j])/(((double)m_groupCardi[i])*((double)(m_groupCardi[j]))); //  eij/(ni*nj)
			}
		}
		for(i=1;i<m_numType;i++){
			for(j=0;j<i;j++){
				m_groupConnMatrix[i][j]=m_groupConnMatrix[j][i];
			}
		}
	}else if((!m_directed)&&m_selfloop){//undirected with selfloops
		for(i=0;i<m_numType;i++){
			for(j=i;j<m_numType;j++){
				if(m_groupConnNumMatrix[i][j]==0){
					m_groupConnMatrix[i][j]=0.0;
					continue;
				}
				if(i==j)
					m_groupConnMatrix[i][i]=((double)(2*m_groupConnNumMatrix[i][i]))/(((double)m_groupCardi[i])*((double)(m_groupCardi[i]+1))); //  2eii/(ni*(ni+1))
				else
					m_groupConnMatrix[i][j]=((double)m_groupConnNumMatrix[i][j])/(((double)m_groupCardi[i])*((double)(m_groupCardi[j]))); //  eij/(ni*nj)
			}
		}
		for(i=1;i<m_numType;i++){
			for(j=0;j<i;j++){
				m_groupConnMatrix[i][j]=m_groupConnMatrix[j][i];
			}
		}
	}
}

unsigned Graph::getGroupCardi(unsigned groupNo) const
{
	if(groupNo<m_numType)
		return m_groupCardi[groupNo];
	else 
		return 0;
}
const Graph::Vertex& Graph::getVertex(unsigned vtxno) const
{
	if(vtxno<m_numVtx)
		return vtxList[vtxno];
	else{
		cerr<<"Cannot get the vertex, the vertex no is too large."<<endl
			<<"-- getVertex()::Graph"<<endl;
		return vtxList[m_numVtx-1];
	}
}
const unsigned Graph::getVtxDegree(unsigned vtxno) const{
	if(vtxno>vtxList.size()){
		cerr<<"the vtx no provided is illegal.-- Graph::getVtxDegree()"<<endl;
		return 0;
	}
	if(m_directed)
		return (vtxList[vtxno].getInDegree()+vtxList[vtxno].getOutDegree());
	else{
		if(vtxSelfloopFlag[vtxno]==0)
			return vtxList[vtxno].getInDegree();
		else
			return vtxList[vtxno].getInDegree()+1;
	}
}