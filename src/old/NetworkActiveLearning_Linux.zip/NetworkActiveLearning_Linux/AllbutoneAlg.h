#ifndef ALLBUTONEALG_H
#define ALLBUTONEALG_H

#include "NetWorkAlgTimer.h"
#include "MCMC.h"
#include "Report.h"


class AllbutoneAlg{
public:
	AllbutoneAlg(string graphfile, set<unsigned> & frozentypes, unsigned modelType, bool groupCorrected);
	~AllbutoneAlg();
	void runAllbutoneAlg();	
	void runAllbutoneLearningAlg();
private:
	bool runAllbutoneVtx(unsigned vtxno, unsigned * mostLikelyTypes, MCMC & mcmc);	
private:	
	unsigned m_numVtx;
	unsigned m_numType;	
	//double * m_probs;
	string m_graphfile;
	unsigned m_modelType;
	bool m_groupCorrected;
	set<unsigned> & m_frozentypes;	
	//unsigned m_numVtxWrongWPGE9;//number of wrong labelled vertices w/p >= 0.9
};
#endif
