#include "Learner.h"

const unsigned Learner::QUERYSTRATEGY=1;
Learner::Learner(const MCMC & mca,const MCMC & mcb,const set<unsigned> & topVtxSet, string methodname):m_MC_A(mca),m_MC_B(mcb),m_topVtxSet(topVtxSet),m_methodName(methodname)
{
	m_numVtx=mca.getTypeModel().getGraph().getNumVtx();
	//cout<<m_numVtx<<endl;
	m_numType=mca.getTypeModel().getNumType();
	//
	m_arrayTopVtxNo=new unsigned[m_numVtx];
	m_arrayVtxNo=new unsigned[m_numVtx];
	m_arrayVtxNoSort=new unsigned[m_numVtx];
	m_arrayLearnScores=new double[m_numVtx];
	m_arrayLearnScoresSort=new double[m_numVtx];
}

Learner::~Learner(void)
{
	delete [] m_arrayTopVtxNo;
	delete [] m_arrayVtxNo;
	delete [] m_arrayVtxNoSort;
	delete [] m_arrayLearnScores;
	delete [] m_arrayLearnScoresSort;
}
