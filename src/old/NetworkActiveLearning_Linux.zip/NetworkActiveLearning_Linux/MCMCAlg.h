#ifndef MCMCALG_H
#define MCMCALG_H

#include "NetWorkAlgTimer.h"
#include "AvgAgree.h"
#include "MutualInfo.h"
#include "TopSeqLearner.h"
#include "MaxDegree.h"
#include "MaxBtwn.h"
#include "RandomLearner.h"
#include "MCMC.h"
#include "Report.h"

class MCMCAlg{
public:
	MCMCAlg(const Graph& graph, unsigned numTypeInModel, set<unsigned> & frozentypes, unsigned numOptInit, long numOptStep, unsigned numLearnerInit, long numLearnerStep, unsigned numPhase, unsigned numTop, unsigned learningMethod, bool klheuristic, unsigned modelType, bool groupcorrected);
	~MCMCAlg();
	void runMCMCAlg();	
	void runOnePhase();	
	void runOneInit();
	void runOneStep();
private:
	int getRandRemainVtx();
	void getTopVtx();
	//void initAccuracyNum();
	void initAccumuMargDistri();
	void initAccuracyMatrix();
	//void updateAccuracyNum(TypeModel&);
	void updateAccuracyMatrix();
	void updateAccumuMargDistri(unsigned mutatevtxno, MCMC & mcmc);
	void writeTopVtxSeq();
	void writeAccuracyMatrix();
	void checkTypeFixed();
	void updateBestTypeModelInPhase();
	double calcNormMIWithTrueClassification(unsigned * c2);

private:
	static double stabRatio;
	static unsigned numAccuracyBlock;
	static string topVtxSeqFileName;

	unsigned m_numVtx;
	unsigned m_numTypeModel;
	unsigned m_numTypeGraph;

	unsigned m_numOptInit;
	long m_numOptStep;
	unsigned m_numLearnerInit;
	long m_numLearnerStep;
	unsigned m_numPhase;
	unsigned m_numTop;
	unsigned m_method;

	set<unsigned> m_topVtxSet;
	set<unsigned> m_remainVtxSet;
	vector<unsigned> m_topVtxSeq;

	const Graph& m_graph;

	TypeModel m_typeModelA;
	TypeModel m_typeModelB;

	MCMC m_MC_A;
	MCMC m_MC_B;

	Learner * m_learner;
	//static ofstream outfile("./output.txt",iso::app);

	long m_curStep;
	unsigned m_curPhase;
	unsigned m_curInit;

	unsigned m_resumePhase;

	double ** m_accuracyMatrix;
	//long * m_accuracyNum;

	double ** m_accumuMargDistri;

	bool m_alltypefixed;

	double m_dSumLHvalueInPhase;

	long m_lNumLHvalueInPhase;
	
	//
	double m_bestLLHvalueInPhase;
	unsigned * m_bestClfcInPhase;//best classification in phase

	bool m_klheuristic;

};
#endif
