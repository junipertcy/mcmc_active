#pragma once
#include "MCMC.h"

class ModelSelectionAlg
{
public:
	ModelSelectionAlg(Graph & graph, set<unsigned> & frozentypes, unsigned numactivetype, unsigned numinits, unsigned numsteps, bool KL_Heuristic, int typemodel);
	~ModelSelectionAlg(void);
	void runAlg(void);
	//void runAlg2(void);
	void query(double ratio);
	//static double calcCondEntropy(unsigned NUM_TYPE_C1, unsigned NUM_TYPE_C2,unsigned NUM_VTX, unsigned * C1, unsigned * C2);
	unsigned * getBestAssignment(){return m_bestVtxTypeTable;}
private:
	unsigned getRandRemainVtx(TypeModel & typemodel);
	unsigned calcNumWrongLabelingVtx();
	double calcNormMIWithTrueClassification();
	void calcBestMerge();
	void printTrueRhos();
	void printBestRhos();
private:
	Graph & m_graph;
private:
	long ** m_bestEdgeConnMatrix;
	long * m_bestGroupCardi;
	unsigned * m_bestVtxTypeTable;
	double m_bestLLHvalue;
	unsigned m_numType;
	unsigned m_numVtx;
	set<unsigned> m_frozenVtxSet;
	vector<unsigned> m_activeVtxArray;
	//
	//string m_graphfile;
	set<unsigned> & m_frozentypes;	
	unsigned m_numActiveType;
	unsigned m_numInits;
	unsigned m_numSteps;
	bool m_KL_Heuristic;
	int m_typemodel;
	int * queryVtxTable;//1 if queried, -1 frozen nodes, 0 otherwise
};
