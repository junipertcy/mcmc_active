#include "TypeModel.h"
#include "Utility.cpp"

TypeModel::TypeModel(const Graph & graph, unsigned numtype/*number of total types*/, set<unsigned> & frozentypes/*frozen types defined in graph*/) : m_graph(graph), m_numType(numtype)
{
	unsigned i;
	m_numActiveType=numtype-frozentypes.size();
	m_numVtx=m_graph.getNumVtx();
	m_vtxTypeTable=new unsigned[m_numVtx];
	m_groupCardiTable=new unsigned[m_numType];	
	m_groupDegrees=new unsigned[m_numType];
	m_groupInDegrees=0;
	m_groupOutDegrees=0;
	if(m_graph.isDirected()){
		m_groupInDegrees=new unsigned[m_numType];
		m_groupOutDegrees=new unsigned[m_numType];
	}
	m_numTargetVtxGroup=new unsigned*[m_numVtx];
	for(i=0;i<m_numVtx;i++){
		m_numTargetVtxGroup[i]=new unsigned[m_numType];
	}
	if(m_graph.isDirected()){
		m_numTargetGroupVtx=new unsigned*[m_numType];
		for(i=0;i<m_numType;i++){
			m_numTargetGroupVtx[i]=new unsigned[m_numVtx];
		}
	}else{
		m_numTargetGroupVtx=0;
	}	
	m_numEdgesOf2Groups=new unsigned*[m_numType];
	for(i=0;i<m_numType;i++){
		m_numEdgesOf2Groups[i]=new unsigned[m_numType];
	}
	groupConnMatrix=new double*[m_numType];
	for(i=0;i<m_numType;i++){
		groupConnMatrix[i]=new double[m_numType];
	}
	lvtxClassifiMatrix=new long long*[m_numVtx];
	dvtxClassifiMatrix=new double*[m_numVtx];
	for(i=0;i<m_numVtx;i++){
		lvtxClassifiMatrix[i]=new long long[m_numType];
		dvtxClassifiMatrix[i]=new double[m_numType];		
	}
	set<unsigned>::const_iterator suiciter = frozentypes.begin();
	for(i=m_numActiveType;suiciter!=frozentypes.end();suiciter++,i++){
		m_mapFzntyMty2Gty.insert(valType_uu(i,*suiciter));
		m_mapFzntyGty2Mty.insert(valType_uu(*suiciter,i));
		m_frozenTypesInGraph.insert(*suiciter);
	}
}

TypeModel::TypeModel(const TypeModel & tm):m_graph(tm.m_graph), m_numActiveType(tm.m_numActiveType), m_numType(tm.m_numType),m_frozenTypesInGraph(tm.m_frozenTypesInGraph), m_mapFzntyMty2Gty(tm.m_mapFzntyMty2Gty),m_mapFzntyGty2Mty(tm.m_mapFzntyGty2Mty),m_groupSets(tm.m_groupSets)
{
	unsigned i,j;
	m_numVtx=tm.m_graph.getNumVtx();
	m_vtxTypeTable=new unsigned[m_numVtx];
	for(i=0;i<m_numVtx;i++)
		m_vtxTypeTable[i]=tm.m_vtxTypeTable[i];
	m_groupCardiTable=new unsigned[m_numType];
	for(i=0;i<m_numType;i++)
		m_groupCardiTable[i]=tm.m_groupCardiTable[i];
	//
	m_groupDegrees=new unsigned[m_numType];
	for(i=0;i<m_numType;i++)
		m_groupDegrees[i]=tm.m_groupDegrees[i];
	if(m_graph.isDirected()){
		m_groupInDegrees=new unsigned[m_numType];
		for(i=0;i<m_numType;i++)
			m_groupInDegrees[i]=tm.m_groupInDegrees[i];
		m_groupOutDegrees=new unsigned[m_numType];
		for(i=0;i<m_numType;i++)
			m_groupOutDegrees[i]=tm.m_groupOutDegrees[i];
	}else{
		m_groupInDegrees=0;
		m_groupOutDegrees=0;
	}
	//
	m_numTargetVtxGroup=new unsigned*[m_numVtx];
	for(i=0;i<m_numVtx;i++){
		m_numTargetVtxGroup[i]=new unsigned[m_numType];
	}
	for(i=0;i<m_numVtx;i++){
		for(j=0;j<m_numType;j++)
			m_numTargetVtxGroup[i][j]=tm.m_numTargetVtxGroup[i][j];
	}
	if(m_graph.isDirected()){
		m_numTargetGroupVtx=new unsigned*[m_numType];
		for(i=0;i<m_numType;i++){
			m_numTargetGroupVtx[i]=new unsigned[m_numVtx];
		}
		for(i=0;i<m_numType;i++){
			for(j=0;j<m_numVtx;j++)
				m_numTargetGroupVtx[i][j]=tm.m_numTargetGroupVtx[i][j];
		}
	}else{
		m_numTargetGroupVtx=0;
	}	
	m_numEdgesOf2Groups=new unsigned*[m_numType];
	for(i=0;i<m_numType;i++){
		m_numEdgesOf2Groups[i]=new unsigned[m_numType];
	}
	for(i=0;i<m_numType;i++){
		for(j=0;j<m_numType;j++)
			m_numEdgesOf2Groups[i][j]=tm.m_numEdgesOf2Groups[i][j];
	}
	groupConnMatrix=new double*[m_numType];
	for(i=0;i<m_numType;i++){
		groupConnMatrix[i]=new double[m_numType];
	}
	for(i=0;i<m_numType;i++){
		for(j=0;j<m_numType;j++)
			groupConnMatrix[i][j]=tm.groupConnMatrix[i][j];
	}
	lvtxClassifiMatrix=new long long*[m_numVtx];
	dvtxClassifiMatrix=new double*[m_numVtx];
	for(i=0;i<m_numVtx;i++){
		lvtxClassifiMatrix[i]=new long long[m_numType];
		dvtxClassifiMatrix[i]=new double[m_numType];		
	}
	for(i=0;i<m_numVtx;i++){
		for(j=0;j<m_numType;j++){
			lvtxClassifiMatrix[i][j]=tm.lvtxClassifiMatrix[i][j];
			dvtxClassifiMatrix[i][j]=tm.dvtxClassifiMatrix[i][j];
		}
	}
}
TypeModel & TypeModel::operator=(const TypeModel & tm)
{
	if(this!=&tm)
	{
		unsigned i,j;
		for(i=0;i<m_numVtx;i++)
			m_vtxTypeTable[i]=tm.m_vtxTypeTable[i];		
		for(i=0;i<m_numType;i++)
			m_groupCardiTable[i]=tm.m_groupCardiTable[i];
		for(i=0;i<m_numVtx;i++){
			for(j=0;j<m_numType;j++)
				m_numTargetVtxGroup[i][j]=tm.m_numTargetVtxGroup[i][j];
		}
		//
		for(i=0;i<m_numType;i++)
			m_groupDegrees[i]=tm.m_groupDegrees[i];
		if(m_graph.isDirected()){
			for(i=0;i<m_numType;i++){
				m_groupInDegrees[i]=tm.m_groupInDegrees[i];
				m_groupOutDegrees[i]=tm.m_groupOutDegrees[i];
			}
		}
		//
		if(m_graph.isDirected()){			
			for(i=0;i<m_numType;i++){
				for(j=0;j<m_numVtx;j++)
					m_numTargetGroupVtx[i][j]=tm.m_numTargetGroupVtx[i][j];
			}
		}
		for(i=0;i<m_numType;i++){
			for(j=0;j<m_numType;j++)
				m_numEdgesOf2Groups[i][j]=tm.m_numEdgesOf2Groups[i][j];
		}
		for(i=0;i<m_numType;i++){
			for(j=0;j<m_numType;j++)
				groupConnMatrix[i][j]=tm.groupConnMatrix[i][j];
		}
		for(i=0;i<m_numVtx;i++){
			for(j=0;j<m_numType;j++){
				lvtxClassifiMatrix[i][j]=tm.lvtxClassifiMatrix[i][j];
				dvtxClassifiMatrix[i][j]=tm.dvtxClassifiMatrix[i][j];
			}
		}
		this->m_groupSets.clear();
		for(i=0;i<tm.m_groupSets.size();i++){
			set<unsigned> groupSet;
			groupSet.insert(tm.m_groupSets[i].begin(),tm.m_groupSets[i].end());
			this->m_groupSets.push_back(groupSet);
		}
	}
	return *this;
}

TypeModel::~TypeModel(){
	unsigned i;
	for(i=0;i<m_numVtx;i++){
		delete [] m_numTargetVtxGroup[i];
	}
	delete [] m_numTargetVtxGroup;
	//
	if(m_numTargetGroupVtx){		
		for(i=0;i<m_numType;i++){
			delete [] m_numTargetGroupVtx[i];
		}
		delete [] m_numTargetGroupVtx;
	}
	//
	for(i=0;i<m_numType;i++){
		delete [] m_numEdgesOf2Groups[i];
	}
	delete [] m_numEdgesOf2Groups;
	//
	for(i=0;i<m_numType;i++){
		delete [] groupConnMatrix[i];
	}
	delete [] groupConnMatrix;
	//
	delete [] m_groupCardiTable;
	delete [] m_vtxTypeTable;
	//
	for(i=0;i<m_numVtx;i++){
		delete [] lvtxClassifiMatrix[i];
		delete [] dvtxClassifiMatrix[i];	
	}
	delete [] lvtxClassifiMatrix;
	delete [] dvtxClassifiMatrix;
	//	
	delete [] m_groupDegrees;
	if(m_graph.isDirected()){
		delete [] m_groupInDegrees;
		delete [] m_groupOutDegrees;
	}
}
void TypeModel::randInitGroups(){
	unsigned i,j;	
	//unsigned randActiveType=0;
	unsigned type=0;

	bool hasEmptyGroup;
	do{
		m_groupSets.clear();
		////////////////////////////////////
		for(i=0;i<m_numType;i++)
			m_groupCardiTable[i]=0;
		////////////////////////////////////
		for(i=0;i<m_numVtx;i++)
			m_vtxTypeTable[i]=0;
		////////////////////////////////////
		for(i=0;i<m_numType;i++){
			set<unsigned> groupSet;
			this->m_groupSets.push_back(groupSet);
		}
		for(i=0;i<m_numVtx;i++){	
			unsigned gtype=m_graph.getVertex(i).getType();
			if(this->isGTypeFrozen(gtype))
				type=m_mapFzntyGty2Mty[gtype];
			else 
				type=randN(m_numActiveType);			
			m_groupSets[type].insert(i);
			m_vtxTypeTable[i]=type;
			m_groupCardiTable[type]++;
		}
		hasEmptyGroup=false;
		for(type=0;type<m_numActiveType;type++)
		{
			if(this->m_groupCardiTable[type]==0){
				hasEmptyGroup=true;
				break;
			}
		}
	}while(hasEmptyGroup);

	////////////////////////////////////////////
	for(i=0;i<m_numVtx;i++){
		for(j=0;j<m_numType;j++){
			m_numTargetVtxGroup[i][j]=0;
		}
	}	
	set<unsigned>::const_iterator setiter;
	for(i=0;i<m_numVtx;i++){
		const set<unsigned>& targets=m_graph.getVertex(i).getTargets();
		for(setiter=targets.begin();setiter!=targets.end();setiter++)			
			m_numTargetVtxGroup[i][m_vtxTypeTable[*setiter]]++;	
	}
	////////////////////////////////////////////
	set<unsigned>::const_iterator siiter;
	if(m_numTargetGroupVtx){
		for(i=0;i<m_numType;i++){
			for(j=0;j<m_numVtx;j++){
				m_numTargetGroupVtx[i][j]=0;
			}
		}
		for(i=0;i<m_numType;i++){
			const set<unsigned> & groupSet=m_groupSets[i];
			for(j=0;j<m_numVtx;j++){
				for(siiter=groupSet.begin();siiter!=groupSet.end();siiter++){
					unsigned sourceVtx=*siiter;
					if(m_graph.getVertex(sourceVtx).getTargets().count(j))
						m_numTargetGroupVtx[i][j]++;
				}
			}
		}
	}
	////////////////////////////////////////////
	for(i=0;i<m_numType;i++){
		for(j=0;j<m_numType;j++){
			m_numEdgesOf2Groups[i][j]=0;
		}
	}	
	for(i=0;i<m_numType;i++){
		for(j=0;j<m_numType;j++){
			const set<unsigned> & groupSet=m_groupSets[i];
			for(siiter=groupSet.begin();siiter!=groupSet.end();siiter++){
				unsigned sourceVtx=*siiter;
				m_numEdgesOf2Groups[i][j]+=m_numTargetVtxGroup[sourceVtx][j];
			}			
		}
	}
	if(!(m_graph.isDirected())){
		for(i=0;i<m_numType;i++){
			unsigned numSelfloop=0;
			const set<unsigned> & groupSet=m_groupSets[i];
			for(siiter=groupSet.begin();siiter!=groupSet.end();siiter++){
				unsigned sourceVtx=*siiter;
				if(m_graph.vtxHasSelfloop(sourceVtx))
					numSelfloop++;					
			}
			m_numEdgesOf2Groups[i][i]=(m_numEdgesOf2Groups[i][i]+numSelfloop)/2;
		}
	}
	///////////////////////////////////////////
	//group degrees data 
	set<unsigned>::const_iterator setuuiter;
	for(i=0;i<m_numType;i++){
		setuuiter=m_groupSets[i].begin();
		if(m_graph.isDirected()){
			m_groupDegrees[i]=0;
			m_groupInDegrees[i]=0;
			m_groupOutDegrees[i]=0;
			for(;setuuiter!=m_groupSets[i].end();setuuiter++){
				m_groupInDegrees[i]+=m_graph.getVertex(*setuuiter).getInDegree();
				m_groupOutDegrees[i]+=m_graph.getVertex(*setuuiter).getOutDegree();
				m_groupDegrees[i]+=m_graph.getVtxDegree(*setuuiter);
			}
		}else{
			m_groupDegrees[i]=0;		
			for(;setuuiter!=m_groupSets[i].end();setuuiter++){
				m_groupDegrees[i]+=m_graph.getVtxDegree(*setuuiter);
			}
		}
	}
}
void TypeModel::randInitGroups(unsigned * vettypetable){
	unsigned i,j;
	unsigned type;
	m_groupSets.clear();
	////////////////////////////////////
	for(i=0;i<m_numType;i++)
		m_groupCardiTable[i]=0;
	////////////////////////////////////
	for(i=0;i<m_numVtx;i++)
		m_vtxTypeTable[i]=0;
	////////////////////////////////////
	for(i=0;i<m_numType;i++){
		set<unsigned> groupSet;
		this->m_groupSets.push_back(groupSet);
	}
	for(i=0;i<m_numVtx;i++){							
		type=vettypetable[i];			
		m_groupSets[type].insert(i);
		m_vtxTypeTable[i]=type;
		m_groupCardiTable[type]++;
	}
	////////////////////////////////////////////
	for(i=0;i<m_numVtx;i++){
		for(j=0;j<m_numType;j++){
			m_numTargetVtxGroup[i][j]=0;
		}
	}	
	set<unsigned>::const_iterator setiter;
	for(i=0;i<m_numVtx;i++){
		const set<unsigned>& targets=m_graph.getVertex(i).getTargets();
		for(setiter=targets.begin();setiter!=targets.end();setiter++)			
			m_numTargetVtxGroup[i][m_vtxTypeTable[*setiter]]++;	
	}
	////////////////////////////////////////////
	set<unsigned>::const_iterator siiter;
	if(m_numTargetGroupVtx){
		for(i=0;i<m_numType;i++){
			for(j=0;j<m_numVtx;j++){
				m_numTargetGroupVtx[i][j]=0;
			}
		}
		for(i=0;i<m_numType;i++){
			const set<unsigned> & groupSet=m_groupSets[i];
			for(j=0;j<m_numVtx;j++){
				for(siiter=groupSet.begin();siiter!=groupSet.end();siiter++){
					unsigned sourceVtx=*siiter;
					if(m_graph.getVertex(sourceVtx).getTargets().count(j))
						m_numTargetGroupVtx[i][j]++;
				}
			}
		}
	}
	////////////////////////////////////////////
	for(i=0;i<m_numType;i++){
		for(j=0;j<m_numType;j++){
			m_numEdgesOf2Groups[i][j]=0;
		}
	}	
	for(i=0;i<m_numType;i++){
		for(j=0;j<m_numType;j++){
			const set<unsigned> & groupSet=m_groupSets[i];
			for(siiter=groupSet.begin();siiter!=groupSet.end();siiter++){
				unsigned sourceVtx=*siiter;
				m_numEdgesOf2Groups[i][j]+=m_numTargetVtxGroup[sourceVtx][j];
			}			
		}
	}
	if(!(m_graph.isDirected())){
		for(i=0;i<m_numType;i++){
			unsigned numSelfloop=0;
			const set<unsigned> & groupSet=m_groupSets[i];
			for(siiter=groupSet.begin();siiter!=groupSet.end();siiter++){
				unsigned sourceVtx=*siiter;
				if(m_graph.vtxHasSelfloop(sourceVtx))
					numSelfloop++;					
			}
			m_numEdgesOf2Groups[i][i]=(m_numEdgesOf2Groups[i][i]+numSelfloop)/2;
		}
	}
	///////////////////////////////////////////
	//group degrees data 
	set<unsigned>::const_iterator setuuiter;
	for(i=0;i<m_numType;i++){
		setuuiter=m_groupSets[i].begin();
		if(m_graph.isDirected()){
			m_groupDegrees[i]=0;	
			m_groupInDegrees[i]=0;
			m_groupOutDegrees[i]=0;
			for(;setuuiter!=m_groupSets[i].end();setuuiter++){
				m_groupInDegrees[i]+=m_graph.getVertex(*setuuiter).getInDegree();
				m_groupOutDegrees[i]+=m_graph.getVertex(*setuuiter).getOutDegree();
				m_groupDegrees[i]+=m_graph.getVtxDegree(*setuuiter);
			}
		}else{
			m_groupDegrees[i]=0;		
			for(;setuuiter!=m_groupSets[i].end();setuuiter++){
				m_groupDegrees[i]+=m_graph.getVtxDegree(*setuuiter);
			}
		
		}
	}
}
void TypeModel::randInitGroups(const set<unsigned>& topVtxSet){
	unsigned i,j;
	//unsigned randActiveTypeIndex=0;
	unsigned type=0;

	bool hasEmptyGroup;
	do{
		m_groupSets.clear();
		////////////////////////////////////
		for(i=0;i<m_numType;i++)
			m_groupCardiTable[i]=0;
		////////////////////////////////////
		for(i=0;i<m_numVtx;i++)
			m_vtxTypeTable[i]=0;
		////////////////////////////////////
		for(i=0;i<m_numType;i++){
			set<unsigned> groupSet;
			this->m_groupSets.push_back(groupSet);
		}
		for(i=0;i<m_numVtx;i++){
			if(topVtxSet.count(i)){
				unsigned gtype=m_graph.getVertex(i).getType();
				if(this->isGTypeFrozen(gtype))
					type=m_mapFzntyGty2Mty[gtype];
				else 
					type = gtype;
			}
			else{
				type=randN(m_numActiveType);
				//randActiveTypeIndex=randN(m_activeTypeArray.size());
				//type=m_activeTypeArray[randActiveTypeIndex];			
			}
			//cout<<i<<endl;
			//if(i==488){
			//	cout<<endl;
			//}
			m_groupSets[type].insert(i);
			m_vtxTypeTable[i]=type;
			m_groupCardiTable[type]++;
		}
		hasEmptyGroup=false;
		for(type=0;type<m_numActiveType;type++)
		{
			if(this->m_groupCardiTable[type]==0){
				hasEmptyGroup=true;
				break;
			}
		}
	}while(hasEmptyGroup);

	////////////////////////////////////////////
	for(i=0;i<m_numVtx;i++){
		for(j=0;j<m_numType;j++){
			m_numTargetVtxGroup[i][j]=0;
		}
	}	
	set<unsigned>::const_iterator setiter;
	for(i=0;i<m_numVtx;i++){
		const set<unsigned>& targets=m_graph.getVertex(i).getTargets();
		for(setiter=targets.begin();setiter!=targets.end();setiter++)			
			m_numTargetVtxGroup[i][m_vtxTypeTable[*setiter]]++;	
	}
	////////////////////////////////////////////
	set<unsigned>::const_iterator siiter;
	if(m_numTargetGroupVtx){
		for(i=0;i<m_numType;i++){
			for(j=0;j<m_numVtx;j++){
				m_numTargetGroupVtx[i][j]=0;
			}
		}
		for(i=0;i<m_numType;i++){
			const set<unsigned> & groupSet=m_groupSets[i];
			for(j=0;j<m_numVtx;j++){
				for(siiter=groupSet.begin();siiter!=groupSet.end();siiter++){
					unsigned sourceVtx=*siiter;
					if(m_graph.getVertex(sourceVtx).getTargets().count(j))
						m_numTargetGroupVtx[i][j]++;
				}
			}
		}
	}
	////////////////////////////////////////////
	for(i=0;i<m_numType;i++){
		for(j=0;j<m_numType;j++){
			m_numEdgesOf2Groups[i][j]=0;
		}
	}	
	for(i=0;i<m_numType;i++){
		for(j=0;j<m_numType;j++){
			const set<unsigned> & groupSet=m_groupSets[i];
			for(siiter=groupSet.begin();siiter!=groupSet.end();siiter++){
				unsigned sourceVtx=*siiter;
				m_numEdgesOf2Groups[i][j]+=m_numTargetVtxGroup[sourceVtx][j];
			}			
		}
	}
	if(!(m_graph.isDirected())){
		for(i=0;i<m_numType;i++){
			unsigned numSelfloop=0;
			const set<unsigned> & groupSet=m_groupSets[i];
			for(siiter=groupSet.begin();siiter!=groupSet.end();siiter++){
				unsigned sourceVtx=*siiter;
				if(m_graph.vtxHasSelfloop(sourceVtx))
					numSelfloop++;					
			}
			m_numEdgesOf2Groups[i][i]=(m_numEdgesOf2Groups[i][i]+numSelfloop)/2;
		}
	}
	///////////////////////////////////////////
	//group degrees data 
	set<unsigned>::const_iterator setuuiter;
	for(i=0;i<m_numType;i++){
		setuuiter=m_groupSets[i].begin();
		if(m_graph.isDirected()){
			m_groupDegrees[i]=0;
			m_groupInDegrees[i]=0;
			m_groupOutDegrees[i]=0;
			for(;setuuiter!=m_groupSets[i].end();setuuiter++){
				m_groupInDegrees[i]+=m_graph.getVertex(*setuuiter).getInDegree();
				m_groupOutDegrees[i]+=m_graph.getVertex(*setuuiter).getOutDegree();
				m_groupDegrees[i]+=m_graph.getVtxDegree(*setuuiter);
			}
		}else{
			m_groupDegrees[i]=0;		
			for(;setuuiter!=m_groupSets[i].end();setuuiter++){
				m_groupDegrees[i]+=m_graph.getVtxDegree(*setuuiter);
			}
		}
	}
}
void TypeModel::mutate(unsigned v,unsigned t){
	unsigned o;
	unsigned s=m_vtxTypeTable[v];
	bool isDirected=m_graph.isDirected();
	//bool hasSelfLoop=m_graph.hasSelfloop();
	unsigned lvv=0;
	if(m_graph.vtxHasSelfloop(v))
		lvv=1;
	//update eij
	if(isDirected){
		for(o=0;o<m_numType;o++){
			if(o==s||o==t)
				continue;
			//eso'=eso-nvo, eos'=eos-nov
			m_numEdgesOf2Groups[s][o]-=m_numTargetVtxGroup[v][o];
			m_numEdgesOf2Groups[o][s]-=m_numTargetGroupVtx[o][v];
			//eto'=eto+nvo, eot'=eot+nov
			m_numEdgesOf2Groups[t][o]+=m_numTargetVtxGroup[v][o];
			m_numEdgesOf2Groups[o][t]+=m_numTargetGroupVtx[o][v];
		}
		//est'=est-(nvt-nsv+lvv), ets'=ets-(ntv-nvs+lvv)
		m_numEdgesOf2Groups[s][t]-=(m_numTargetVtxGroup[v][t]-m_numTargetGroupVtx[s][v]+lvv);
		m_numEdgesOf2Groups[t][s]-=(m_numTargetGroupVtx[t][v]-m_numTargetVtxGroup[v][s]+lvv);
		//ess'=ess-(nsv+nvs-lvv), ett'=ett+(nvt+ntv+lvv);
		m_numEdgesOf2Groups[s][s]-=(m_numTargetVtxGroup[v][s]+m_numTargetGroupVtx[s][v]-lvv);
		m_numEdgesOf2Groups[t][t]+=(m_numTargetGroupVtx[t][v]+m_numTargetVtxGroup[v][t]+lvv);
	}else{
		for(o=0;o<m_numType;o++){
			if(o==s||o==t)
				continue;
			//eso'=eso-nvo, eos'=eso'
			m_numEdgesOf2Groups[s][o]-=m_numTargetVtxGroup[v][o];
			m_numEdgesOf2Groups[o][s]=m_numEdgesOf2Groups[s][o];
			//eto'=eto+nvo, eot'=eto'
			m_numEdgesOf2Groups[t][o]+=m_numTargetVtxGroup[v][o];
			m_numEdgesOf2Groups[o][t]=m_numEdgesOf2Groups[t][o];
		}
		//est'=est-(nvt-nvs+lvv), ets'=est'
		m_numEdgesOf2Groups[s][t]-=(m_numTargetVtxGroup[v][t]-m_numTargetVtxGroup[v][s]+lvv);
		m_numEdgesOf2Groups[t][s]=m_numEdgesOf2Groups[s][t];
		//ess'=ess-nvs, ett'=ett+nvt+lvv;
		m_numEdgesOf2Groups[s][s]-=m_numTargetVtxGroup[v][s];
		m_numEdgesOf2Groups[t][t]+=(m_numTargetVtxGroup[v][t]+lvv);
	}
	//update nvi and niv
	const set<unsigned> & vSources = m_graph.getVertex(v).getSources();
	set<unsigned>::const_iterator setiter=vSources.begin();
	for(;setiter!=vSources.end();setiter++){
		//nvs'=nvs-1, nvt'=nvt+1, here v is i;
		m_numTargetVtxGroup[*setiter][s]--;
		m_numTargetVtxGroup[*setiter][t]++;
	}

	if(isDirected){
		const set<unsigned>& vTargets=m_graph.getVertex(v).getTargets();
		setiter=vTargets.begin();
		for(;setiter!=vTargets.end();setiter++){
			//nsv'=nsv-1, ntv'=ntv+1, here v is targetVtx;
			m_numTargetGroupVtx[s][*setiter]--;
			m_numTargetGroupVtx[t][*setiter]++;
		}
	}
	//update ni
	m_groupCardiTable[s]--;
	m_groupCardiTable[t]++;
	//update groupSets: s and t
	m_groupSets[s].erase(v);
	m_groupSets[t].insert(v);
	//update vtxTypeTable: vertex v has new type of t.
	m_vtxTypeTable[v]=t;
	//update group degrees
	m_groupDegrees[s]-=m_graph.getVtxDegree(v);
	m_groupDegrees[t]+=m_graph.getVtxDegree(v);
	if(isDirected){
		m_groupInDegrees[s]-=m_graph.getVertex(v).getInDegree();
		m_groupInDegrees[t]+=m_graph.getVertex(v).getInDegree();
		m_groupOutDegrees[s]-=m_graph.getVertex(v).getOutDegree();
		m_groupOutDegrees[t]+=m_graph.getVertex(v).getOutDegree();
	}
}
ostream& TypeModel::printModelInfo(ostream& os) const {
	unsigned i,j;
	//os<<"show graph:++++++++++++++++++++++++++++++++++++++++++++++"<<endl;
	//m_graph.printGraph();
	os<<"show groups:+++++++++++++++++++++++++++++++++++++++++++++"<<endl;
	for(i=0;i<m_numType;i++){
		const set<unsigned> & group=this->m_groupSets[i];
		os<<"Set No. "<<i<<":"<<endl;
		print_ui_set(group, os);
	}
	os<<"show Vtx Type Table:+++++++++++++++++++++++++++++++++++++"<<endl;
	for(i=0;i<m_numVtx;i++){
		os<<m_vtxTypeTable[i]+1<<"\t";
	}
	os<<endl;
	os<<"show Group Cardinality Table:++++++++++++++++++++++++++++"<<endl;
	for(i=0;i<m_numType;i++){
		os<<m_groupCardiTable[i]<<"\t";
	}
	os<<endl;	
	os<<"show number of Targets from vtx i to Group j:++++++++++++"<<endl;
	for(i=0;i<m_numVtx;i++){
		os<<"Vertex "<<i<<endl;
		for(j=0;j<m_numType;j++){
			os<<"Group "<<j<<": "<<m_numTargetVtxGroup[i][j];
			os<<"\t";
		}
		os<<endl;	
	}
	if(m_graph.isDirected()){
		os<<"show number of Targets from Group i to Vertex j:++++++++++++"<<endl;
		for(i=0;i<m_numType;i++){
			os<<"Group "<<i<<endl;
			for(j=0;j<m_numVtx;j++){
				os<<"Vertex "<<j<<": "<<m_numTargetGroupVtx[i][j];
				os<<"\t";
			}
			os<<endl;	
		}		
	}
	os<<"show number of Edges from Group i to Group j:++++++++++++"<<endl;
	for(i=0;i<m_numType;i++){
		os<<"Group "<<i<<endl;
		for(j=0;j<m_numType;j++){
			os<<"Group "<<j<<": "<<m_numEdgesOf2Groups[i][j];
			os<<"\t";
		}
		os<<endl;	
	}	
	if(m_graph.isDirected()){
		os<<"show group in-degrees:++++++++++++"<<endl;
		for(i=0;i<m_numType;i++){
			os<<"Group "<<i<<":\t"<<m_groupInDegrees[i]<<endl;	
		}		
		os<<"show group out-degrees:++++++++++++"<<endl;
		for(i=0;i<m_numType;i++){
			os<<"Group "<<i<<":\t"<<m_groupOutDegrees[i]<<endl;	
		}		
	}
	else{
		os<<"show group degrees:++++++++++++"<<endl;
		for(i=0;i<m_numType;i++){
			os<<"Group "<<i<<":\t"<<m_groupDegrees[i]<<endl;	
		}		
	}
	return os;
}
void TypeModel::initGroupConnMatrix(){
	unsigned i,j;
	for(i=0;i<m_numType;i++){
		for(j=0;j<m_numType;j++){
			groupConnMatrix[i][j]=0.0;
		}
	}
	numAccuGCM=0l;
}
void TypeModel::updateGroupConnMatrix(){
	unsigned i,j;
	bool isDirected=m_graph.isDirected();
	bool hasSelfLoop=m_graph.hasSelfloop();
	if(isDirected&&(!hasSelfLoop)){//directed without selfloop
		for(i=0;i<m_numType;i++){
			for(j=0;j<m_numType;j++){
				if(m_numEdgesOf2Groups[i][j]==0){
					//groupConnMatrix[i][j]=0.0;
					continue;
				}
				if(i==j)
					groupConnMatrix[i][i]+=((double)m_numEdgesOf2Groups[i][i])/((double)m_groupCardiTable[i])/((double)(m_groupCardiTable[i]-1)); //  eii/(ni*(ni-1))
				else
					groupConnMatrix[i][j]+=((double)m_numEdgesOf2Groups[i][j])/((double)m_groupCardiTable[i])/((double)(m_groupCardiTable[j])); //  eij/(ni*nj)
			}
		}
	}else if(isDirected&&hasSelfLoop){//directed with selfloops
		for(i=0;i<m_numType;i++){
			for(j=0;j<m_numType;j++){
				if(m_numEdgesOf2Groups[i][j]==0){
					//m_groupConnMatrix[i][j]=0.0;
					continue;
				}
				groupConnMatrix[i][j]+=((double)m_numEdgesOf2Groups[i][j])/((double)m_groupCardiTable[i])/((double)(m_groupCardiTable[j])); //  eij/(ni*nj)
			}
		}
	}else if((!isDirected)&&(!hasSelfLoop)){//undirected without selfloop
		for(i=0;i<m_numType;i++){
			for(j=i;j<m_numType;j++){
				if(m_numEdgesOf2Groups[i][j]==0){
					//m_groupConnMatrix[i][j]=0.0;
					continue;
				}
				if(i==j)
					groupConnMatrix[i][i]+=((double)(2*m_numEdgesOf2Groups[i][i]))/(((double)m_groupCardiTable[i])*((double)(m_groupCardiTable[i]-1))); //  2eii/(ni*(ni-1))
				else
					groupConnMatrix[i][j]+=((double)m_numEdgesOf2Groups[i][j])/(((double)m_groupCardiTable[i])*((double)(m_groupCardiTable[j]))); //  eij/(ni*nj)
			}
		}
		for(i=1;i<m_numType;i++){
			for(j=0;j<i;j++){
				groupConnMatrix[i][j]=groupConnMatrix[j][i];
			}
		}
	}else if((!isDirected)&&hasSelfLoop){//undirected with selfloops
		for(i=0;i<m_numType;i++){
			for(j=i;j<m_numType;j++){
				if(m_numEdgesOf2Groups[i][j]==0){
					//m_groupConnMatrix[i][j]=0.0;
					continue;
				}
				if(i==j)
					groupConnMatrix[i][i]+=((double)(2*m_numEdgesOf2Groups[i][i]))/(((double)m_groupCardiTable[i])*((double)(m_groupCardiTable[i]+1))); //  2eii/(ni*(ni+1))
				else
					groupConnMatrix[i][j]+=((double)m_numEdgesOf2Groups[i][j])/(((double)m_groupCardiTable[i])*((double)(m_groupCardiTable[j]))); //  eij/(ni*nj)
			}
		}
		for(i=1;i<m_numType;i++){
			for(j=0;j<i;j++){
				groupConnMatrix[i][j]=groupConnMatrix[j][i];
			}
		}
	}
	numAccuGCM++;
}
double ** TypeModel::getGroupConnMatrix(){
	unsigned i,j;
	for(i=0;i<m_numType;i++){
		for(j=0;j<m_numType;j++){
			groupConnMatrix[i][j]/=(double)numAccuGCM;
		}
	}
	return groupConnMatrix;
}
void TypeModel::initVtxClassifiMatrix(){
	unsigned i,j;
	for(i=0;i<m_numVtx;i++){
		for(j=0;j<m_numType;j++){
			lvtxClassifiMatrix[i][j]=0l;
			dvtxClassifiMatrix[i][j]=0.0;
		}
	}
}
void TypeModel::updateVtxClassifiMatrix(){
	unsigned i;
	unsigned type;
	for(i=0;i<m_numVtx;i++){
		type=this->m_vtxTypeTable[i];
		lvtxClassifiMatrix[i][type]++;
	}
}
double ** TypeModel::getVtxClassifiMatrix(){
	unsigned i,j;
	long long lSum;
	for(i=0;i<m_numVtx;i++){
		lSum=0;
		for(j=0;j<m_numType;j++){
			lSum+=lvtxClassifiMatrix[i][j];
		}
		for(j=0;j<m_numType;j++){
			dvtxClassifiMatrix[i][j]=(double)lvtxClassifiMatrix[i][j]/(double)lSum;
		}
	}
	return dvtxClassifiMatrix;
}

bool TypeModel::isVtxMutable(unsigned vtxno) const{
	if(m_groupCardiTable[m_vtxTypeTable[vtxno]]==1)
		return false;
	else 
		return true;
}
