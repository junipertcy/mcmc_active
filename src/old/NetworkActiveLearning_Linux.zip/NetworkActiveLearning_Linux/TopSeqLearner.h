#ifndef TOPSEQLEARNER_H
#define TOPSEQLEARNER_H

#include "Learner.h"

class TopSeqLearner :
	public Learner
{
public:
	TopSeqLearner(const MCMC & mca,const MCMC & mcb,const set<unsigned> & topVtxSet, string topseqfilename);
	~TopSeqLearner(void){};
public:
	virtual void resetForNextPhase(){}	
	virtual void resetForNextInit(){}
	virtual unsigned getTopVtx(unsigned *arrayTop, unsigned numTop);
	virtual void updateData(){}
	virtual ostream& printPhaseResult(ostream& = cout) const;
	virtual string getMethodName() const {return m_methodName;}
	virtual unsigned getNumVtx() const {return Learner::getNumVtx();}
	virtual unsigned getNumTypeGraph() const {return Learner::getNumTypeGraph();}
	virtual unsigned getNumTypeModel() const {return Learner::getNumTypeModel();}
private:
	string m_topSeqFileName;
	vector<unsigned> m_topSeq;
	unsigned m_nextTopIndex;
};

#endif
