#include "TypeModel.h"
#include "MCMCAlg.h"
#include "Report.h"
#include "ScalingTestAlg.h"
#include "AllbutoneAlg.h"
#include "Utility.cpp"
#include "ModelSelectionAlg.h"


int main() 

{
	unsigned i;
	string mainfun("-al");
	//const string GRAPH_FILE="./data/seafoodweb/seafoodweb-6types.gml";
	const string GRAPH_FILE="./data/karate/karate.gml";
	//const string GRAPH_FILE="./data/seafoodweb/seafoodweb-Feedingtype.gml";
	//const string GRAPH_FILE="./data/degreetest/test1.gml";
	//const string GRAPH_FILE="./data/seafoodweb/SFWmass.gml";
	//const string GRAPH_FILE="./data/artifical_datasets/5_blocks__5000_nodes__directed.gml";	
	//const string GRAPH_FILE="./data/words.gml";	
	//const string GRAPH_FILE="./data/brown_all.gml";
	//const string GRAPH_FILE="./data/polblogs_d.gml";
	//const string GRAPH_FILE="./data/polblogs_ud.gml";
	//const string GRAPH_FILE="./data/ecoweb/chesapeake.gml";	
	//const string GRAPH_FILE="./data/ecoweb/grass.gml";
	//const string GRAPH_FILE="./data/ecoweb/bridgebrook.gml";
	//const string GRAPH_FILE="./data/ecoweb/skipwith.gml";
	//const string GRAPH_FILE="./data/ecoweb/benguela.gml";
	//const string GRAPH_FILE="./data/ecoweb/stmartin.gml";
	//const string GRAPH_FILE="./data/ecoweb/stmarks.gml";
	//const string GRAPH_FILE="./data/ecoweb/broom.gml";
	//const string GRAPH_FILE="./data/ecoweb/coachella.gml";	
	//const string GRAPH_FILE="./data/ecoweb/reef.gml";	
	//const string GRAPH_FILE="./data/test.gml";
	//const string GRAPH_FILE="./data/test2.gml";

	srand((unsigned) time(NULL));
	// "modelType" indicates the type of the underlying block model. We have quite a lot block models available in this package.
	unsigned modelType=1;
	// "groupCorrected" indicates whether use group size correction or not.
	bool groupCorrected=false;
	// "frozentypes" indicates the types/groups that are fixed. For example, in the "sea food web" network, the "resource" type is fixed (not for learn).
	set<unsigned> frozentypes;
	//frozentypes.insert(5);
	//
	//* all but one algorithm *//
	if(mainfun.compare("-abo")==0){
		AllbutoneAlg allbutone(GRAPH_FILE,frozentypes,modelType,groupCorrected);
		allbutone.runAllbutoneAlg();
	}
	else if(mainfun.compare("-abol")==0){
		AllbutoneAlg allbutone(GRAPH_FILE,frozentypes,modelType,groupCorrected);
		allbutone.runAllbutoneLearningAlg();
	}
	//
	//* model selection algorithm *//
	else if(mainfun.compare("-ms")==0){
		cout<<"Model Selection Algorithm is Running ..."<<endl;
		unsigned k=2;
		Graph graph(GRAPH_FILE);
		for(;k<3;k++){
			ModelSelectionAlg msalg(graph, frozentypes, k, 100, 0, true, modelType);
			msalg.runAlg();
			getchar();
			//msalg.runAlg_orig_weight();
		}
	}
	//* model selection comparison algorithm *//
	else if(mainfun.compare("-msc")==0){
		cout<<"Model Selection Comparing (conditional entropy) Algorithm is Running ..."<<endl;
		ofstream outfile("./report/msc.txt",std::ios_base::app);
		unsigned i,j;
		Graph graph(GRAPH_FILE);
		//////////////////////////////////////////
		bool selfcompare=true;
		unsigned k1_l=2;
		unsigned k1_u=31;
		unsigned k2_l=2;
		unsigned k2_u=31;
		//////////////////////////////////////////
		unsigned NumVtx=graph.getNumVtx();		
		unsigned * bestassignment;
		unsigned ** bestassignments_m1=new unsigned * [k1_u-k1_l+1];
		for(i=0;i<k1_u-k1_l+1;i++){
			bestassignments_m1[i]=new unsigned[NumVtx];
		}
		unsigned ** bestassignments_m2=new unsigned * [k2_u-k2_l+1];
		for(i=0;i<k2_u-k2_l+1;i++){
			bestassignments_m2[i]=new unsigned[NumVtx];
		}
		for(i=0;i<k1_u-k1_l+1;i++){
			ModelSelectionAlg msalg(graph, frozentypes, k1_l+i, 1, 100000, true, 4);
			msalg.runAlg();
			bestassignment=msalg.getBestAssignment();
			for(j=0;j<NumVtx;j++)
				bestassignments_m1[i][j]=bestassignment[j];
		}
		for(i=0;i<k2_u-k2_l+1;i++){
			if(selfcompare){
				for(j=0;j<NumVtx;j++)
					bestassignments_m2[i][j]=bestassignments_m1[i][j];
			}
			else{
				ModelSelectionAlg msalg(graph, frozentypes, k2_l+i, 1, 1000000, false, 4);
				msalg.runAlg();
				bestassignment=msalg.getBestAssignment();
				for(j=0;j<NumVtx;j++)
					bestassignments_m2[i][j]=bestassignment[j];
			}
		}
		for(i=0;i<k1_u-k1_l+1;i++){
			for(j=0;j<k2_u-k2_l+1;j++){
				outfile<<calcCondEntropy(k1_l+i,k2_l+j,NumVtx,bestassignments_m1[i],bestassignments_m2[j])<<"\t";
				//cout<<"<"<<i+k1_l<<","<<k2_l+j<<">\t:"<<calcCondEntropy(k1_l+i,k2_l+j,NumVtx,bestassignments_m1[i],bestassignments_m2[j])<<endl;
			}
			outfile<<endl;
		}
		for(i=0;i<k1_u-k1_l+1;i++){
			delete [] bestassignments_m1[i];
		}
		for(i=0;i<k2_u-k2_l+1;i++){
			delete [] bestassignments_m2[i];
		}
		delete [] bestassignments_m1;
		delete [] bestassignments_m2;
		outfile.close();
	}
	//
	//* Active learning algorithm *//
	else if(mainfun.compare("-al")==0){
		static Report * report; // reports for outputing results
		bool KL_heuristic=false; //	whether use KL heuristic or not. KL heuristic is a deterministic algorithm which is slow but can guarantee a good convergence.	
		unsigned runs=3; // number of independent runs.  	
		unsigned numTypeInModel = 2; // number of types/groups in the model, which can be different from the number of types in the data.
		unsigned numOptInit = 50; // number of initials for optimization
		unsigned numLearnerInit = 50; // number of initials for active learning
		unsigned numOptStep = 1000;// number of iterations in each initial for optimization
		unsigned numLearnerStep = 1000; // number of iterations in each initial for active learning
		unsigned numPhase = 32; // number of phases for active learning, each phase returns a fixed number of vertices for query. The number of vertices to query is indicated by the "numTop" variable.
		unsigned numTop = 1; // number of vertices to query in each phase.
		unsigned learningMethod = 1; // indicades which active learner is used: 1-MutualInfo, 2-AvgAgree, 3-RandomLearner, 4-TopSeqLearner, 5-MaxDegree, 6-MaxBtwn.
		//
		for(i=0;i<runs;i++){
			cout<<"Run # "<<i+1<<" is running..."<<endl;
			report=Report::getReport(i);
			Graph graph(GRAPH_FILE);
			if(mainfun.compare("-al")==0){
				cout<<"active learning starts..."<<endl;
				MCMCAlg mcmcalg(graph, numTypeInModel, frozentypes, numOptInit, numOptStep, numLearnerInit, numLearnerStep, numPhase, numTop, learningMethod, KL_heuristic, modelType, groupCorrected);
				mcmcalg.runMCMCAlg();
			}else if(mainfun.compare("-st")==0){
				cout<<"scaling test starts..."<<endl;
				ScalingTestAlg stalg(graph, numTypeInModel, frozentypes, 50, 50, 500, 100, 1, KL_heuristic, modelType);
				stalg.runAlg();
			}else{
				cout<<"active learning starts..."<<endl;
				MCMCAlg mcmcalg(graph, numTypeInModel, frozentypes, 25, 50000, 25, 50000, 500, 10, 1, KL_heuristic, modelType, groupCorrected);
				mcmcalg.runMCMCAlg();			
			}
			cout<<"Total Time: "<<fTotalTime<<endl;
			report->closeAllReports();
		}
	}
	//
	//getchar();
	return 0;
};


