#ifndef SCALINGTESTALG_H
#define SCALINGTESTALG_H

#include "NetWorkAlgTimer.h"
#include "AvgAgree.h"
#include "MutualInfo.h"
#include "TopSeqLearner.h"
#include "MaxDegree.h"
#include "RandomLearner.h"
#include "MCMC.h"
#include "Report.h"

class ScalingTestAlg{
public:
	ScalingTestAlg(const Graph& graph, unsigned numTypeInModel, set<unsigned> & frozentypes, unsigned numOptInit, unsigned numLearnerInit, unsigned numPhase, unsigned numTop, unsigned method, bool klheuristic, unsigned modelType);
	~ScalingTestAlg();
	void runAlg();	
	void runOnePhase();	
	void runOneInit();
	void runOneStep(bool);
private:
	int getRandRemainVtx();
	void getTopVtx();
	void initAccumuMargDistri();
	void updateAccumuMargDistri(unsigned mutatevtxno, MCMC & mcmc);
	void writeTopVtxSeq();
	void checkTypeFixed();
	void initAccuracyMatrix();
	void updateAccuracyMatrix();
	void writeAccuracyMatrix();

private:

	unsigned m_numVtx;
	unsigned m_numTypeModel;
	unsigned m_numTypeGraph;
	unsigned m_numOptInit;	
	unsigned m_numLearnerInit;	
	unsigned m_numPhase;
	unsigned m_numTop;
	unsigned m_method;

	set<unsigned> m_topVtxSet;
	set<unsigned> m_remainVtxSet;
	vector<unsigned> m_topVtxSeq;

	static unsigned numAccuracyBlock;

	const Graph& m_graph;

	TypeModel m_typeModelA;
	TypeModel m_typeModelB;

	MCMC m_MC_A;
	MCMC m_MC_B;

	Learner * m_learner;

	long long m_llCurStep;
	unsigned m_curPhase;
	unsigned m_curInit;

	double ** m_accumuMargDistri;

	bool m_alltypefixed;

	double ** m_accuracyMatrix;
	//double m_dSumLHvalueInPhase;

	//long m_lNumLHvalueInPhase;

	long long m_llMaxIter;
	vector<long long> vecllMaxIter;
	bool m_recordBroken;

	bool m_klheuristic;
};
#endif
