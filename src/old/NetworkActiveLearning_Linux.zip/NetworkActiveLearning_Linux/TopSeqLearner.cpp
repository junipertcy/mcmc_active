#include "TopSeqLearner.h"

TopSeqLearner::	TopSeqLearner(const MCMC & mca,const MCMC & mcb,const set<unsigned> & topVtxSet, string topseqfilename): Learner(mca, mcb, topVtxSet, "Top Vertex Sequence"), m_topSeqFileName(topseqfilename)
{
	m_nextTopIndex=0;
	ifstream infile(m_topSeqFileName.c_str());
	if(!infile){
		cerr<<"unable to open the top vtx seq file:"
			<<m_topSeqFileName<<endl;	
		return;
	}	
	string word;	
	while(infile>>word){
		m_topSeq.push_back(atoi(word.c_str()));
	}
	infile.close();
}
unsigned TopSeqLearner::getTopVtx(unsigned *arrayTop, unsigned numTop){
	unsigned i,j;
	vector<unsigned>::const_iterator viiter;
	if(m_nextTopIndex>=m_topSeq.size())
		cerr<<"no more vertex in seq to pop out."<<endl;
	else{
		viiter=m_topSeq.begin()+m_nextTopIndex;
	    for(i=0;i<numTop&&viiter!=m_topSeq.end();i++,viiter++)
				arrayTop[i]=*viiter;
	}
	m_numtop=i;
	m_nextTopIndex+=i;
	////////////////////////////////////
	cout<<"tops:"<<endl;
	for(j=0;j<m_numtop;j++){
		cout<<arrayTop[j]<<'\t';
	}
	cout<<endl;
	//
	return m_numtop;
}
ostream& TopSeqLearner::printPhaseResult(ostream& os) const{
	//unsigned i,j;
	os<<"Query Vertex from the Given Top Vertex Sequence"<<endl;
	/*for(i=0,j=0;i<m_arraysize;i++,j++){
		while(j<m_arrayVtxNo[i]){
			os<<"Node "<<j<<" :\t"<<"Queried"<<"\n";	
			j++;
		}
		os<<"Node "<<m_arrayVtxNo[i]<<" :\t"<<"Not Queried"<<"\n";		
	}
	while(j<m_numVtx){
		os<<"Node "<<j<<" :\t"<<-1.0<<"\n";	
		j++;
	}*/
	return os;
}