#pragma once
#include "Global.h"

class Report
{
public:
	static Report * getReport(int runno);
	static Report * getReport(void);
	ofstream & getOutputStream(){return m_outfile_output;}
	ofstream & getTopvtxseqStream(){return m_outfile_topvtxseq;}
	ofstream & getGraphStream(){return m_outfile_graph;}
	ofstream & getTypematrixStream(){return m_outfile_typematrix;}
	ofstream & getAccuracymatrixStream(){return m_outfile_accuracymatrix;}
	ofstream & getGroupConnmatrixStream(){return m_outfile_groupconnmatrix;}
	ofstream & getParamsStream(){return m_outfile_params;}
	ofstream & getConfusionmatrixStream(){return m_outfile_confusionmatrix;}
	ofstream & getMaxLLHsStream(){return m_outfile_maxllhs;}
	ofstream & getBestConnMatrixStream(){return m_outfile_bestconnmatrix;}
	ofstream & getEquiIterNumStream(){return m_outfile_equiiternum;}
	ofstream & getUpdatePointsStream(){return m_outfile_updatepoints;}
	ofstream & getAllbutoneStream(){return m_outfile_allbutone;}
	ofstream & getNormMIperPhaseStream(){return m_outfile_normmiperphase;}
	void closeAllReports(void);
private:
	Report(const int runno);	
	static Report * m_report;
	string m_filename_output;
	string m_filename_topvtxseq;
	string m_filename_graph;
	string m_filename_typematrix;
	string m_filename_accuracymatrix;
	string m_filename_groupconnmatrix;
	string m_filename_params;
	string m_filename_confusionmatrix;
	string m_filename_maxllhs;
	string m_filename_bestconnmatrix;
	string m_filename_equiiternum;
	string m_filename_updatepoints; //record the update points for best type model found so far
	string m_filename_allbutone;
	string m_filename_normmiperphase;//record the best normalized MI value for each phase in active learning procedure
	//
	ofstream m_outfile_output;
	ofstream m_outfile_topvtxseq;
	ofstream m_outfile_graph;
	ofstream m_outfile_typematrix;
	ofstream m_outfile_accuracymatrix;
	ofstream m_outfile_groupconnmatrix;
	ofstream m_outfile_params;
	ofstream m_outfile_confusionmatrix;
	ofstream m_outfile_maxllhs;
	ofstream m_outfile_bestconnmatrix;
	ofstream m_outfile_equiiternum;
	ofstream m_outfile_updatepoints;  //record the update points for best type model found so far
	ofstream m_outfile_allbutone;
	ofstream m_outfile_normmiperphase;
public:
	~Report(void);
};
