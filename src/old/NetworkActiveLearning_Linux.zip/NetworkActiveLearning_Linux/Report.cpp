#include "Report.h"
#include "Utility.cpp"

Report * Report::m_report=0;

Report::Report(const int runno):
m_filename_output("./report/output"+to_string(runno)+".txt"),
m_filename_topvtxseq("./report/topvtxseq"+to_string(runno)+".txt"),
m_filename_graph("./report/graph"+to_string(runno)+".txt"),
m_filename_typematrix("./report/typematrix"+to_string(runno)+".txt"),
m_filename_accuracymatrix("./report/accuracymatrix"+to_string(runno)+".txt"),
m_filename_groupconnmatrix("./report/groupconnmatrix"+to_string(runno)+".txt"),
m_filename_params("./report/params"+to_string(runno)+".txt"),
m_filename_confusionmatrix("./report/confusionmatrix"+to_string(runno)+".txt"),
m_filename_maxllhs("./report/maxllhs"+to_string(runno)+".txt"),
m_filename_bestconnmatrix("./report/bestconnmatrix"+to_string(runno)+".txt"),
m_filename_equiiternum("./report/equiiternum"+to_string(runno)+".txt"),
m_filename_updatepoints("./report/updatepoints"+to_string(runno)+".txt"),
m_filename_allbutone("./report/allbutone"+to_string(runno)+".txt"),
m_filename_normmiperphase("./report/normmiinphase"+to_string(runno)+".txt"),
m_outfile_output(m_filename_output.c_str(),ios_base::app),
m_outfile_topvtxseq(m_filename_topvtxseq.c_str(),ios_base::app),
m_outfile_graph(m_filename_graph.c_str(),ios_base::app),
m_outfile_typematrix(m_filename_typematrix.c_str(),ios_base::app),
m_outfile_accuracymatrix(m_filename_accuracymatrix.c_str(),ios_base::app),
m_outfile_groupconnmatrix(m_filename_groupconnmatrix.c_str(),ios_base::app),
m_outfile_params(m_filename_params.c_str(),ios_base::app),
m_outfile_maxllhs(m_filename_maxllhs.c_str(),ios_base::app),
m_outfile_bestconnmatrix(m_filename_bestconnmatrix.c_str(),ios_base::app),
m_outfile_equiiternum(m_filename_equiiternum.c_str(),ios_base::app),
m_outfile_updatepoints(m_filename_updatepoints.c_str(),ios_base::app),
m_outfile_confusionmatrix(m_filename_confusionmatrix.c_str(),ios_base::app),
m_outfile_allbutone(m_filename_allbutone.c_str(),ios_base::app),
m_outfile_normmiperphase(m_filename_normmiperphase.c_str(),ios_base::app)
{
	if((!m_outfile_output)||(!m_outfile_topvtxseq)||(!m_outfile_graph)||(!m_outfile_typematrix)||(!m_outfile_accuracymatrix)||(!m_outfile_groupconnmatrix)||(!m_outfile_params)||(!m_outfile_confusionmatrix)||(!m_outfile_maxllhs)||(!m_outfile_bestconnmatrix)||(!m_outfile_equiiternum)||(!m_outfile_updatepoints)||(!m_outfile_allbutone)||(!m_outfile_normmiperphase)){
		cerr<<"Warnning! Can not open report file for writing!\n";
		exit(-1);
	}	
}

Report::~Report(void)
{
}
void Report::closeAllReports(void)
{
	m_outfile_output.close();
	m_outfile_topvtxseq.close();
	m_outfile_graph.close();
	m_outfile_typematrix.close();
	m_outfile_accuracymatrix.close();
	m_outfile_groupconnmatrix.close();
	m_outfile_params.close();
	m_outfile_confusionmatrix.close();
	m_outfile_maxllhs.close();
	m_outfile_bestconnmatrix.close();
	m_outfile_equiiternum.close();
	m_outfile_updatepoints.close();
	m_outfile_allbutone.close();
	m_outfile_normmiperphase.close();
	delete m_report;
	m_report=0;
}
Report * Report::getReport(int runno){
	if(m_report==0)
		m_report=new Report(runno);
	return m_report;
}
Report * Report::getReport(void){
	return m_report;
}
