#ifndef RANDOMLEARNER_H
#define RANDOMLEARNER_H

#include "Learner.h"

class RandomLearner :
	public Learner
{
public:
	RandomLearner(const MCMC & mca,const MCMC & mcb,const set<unsigned> & topVtxSet): Learner(mca, mcb, topVtxSet, "Query Vertex Randomly"){}
	~RandomLearner(void){}
public:
	virtual void resetForNextPhase(){}	
	virtual void resetForNextInit(){}
	virtual unsigned getTopVtx(unsigned *arrayTop, unsigned numTop);
	virtual void updateData(){}
	virtual ostream& printPhaseResult(ostream& = cout) const;
	virtual string getMethodName() const {return m_methodName;}
	virtual unsigned getNumVtx() const {return Learner::getNumVtx();}
	virtual unsigned getNumTypeGraph() const {return Learner::getNumTypeGraph();}
	virtual unsigned getNumTypeModel() const {return Learner::getNumTypeModel();}
};

#endif
