#include "AllbutoneAlg.h"
#include "Utility.cpp"
#include "TypeModel.h"
#include "MCMC.h"
#include "Report.h"
#include "MCMCAlg.h"

AllbutoneAlg::AllbutoneAlg(string graphfile, set<unsigned>& frozentypes, unsigned modelType, bool groupCorrected):m_frozentypes(frozentypes),m_graphfile(graphfile), m_modelType(modelType), m_groupCorrected(groupCorrected){}

AllbutoneAlg::~AllbutoneAlg(){}

void AllbutoneAlg::runAllbutoneAlg(){	
	unsigned i;
	unsigned numIter=0;	
	bool hasWrongLabeled;
	unsigned numWrong;
	static Report * report;
	vector<string> mostLikelyValues;
	do{	
		//m_numVtxWrongWPGE9=0;
		report=Report::getReport(numIter);
		Graph graph(m_graphfile,mostLikelyValues);
		//Graph graph(GRAPH_FILE,assignedMostLikelyValues);
		//cout<<graph.getNumVtx()<<endl;	
		TypeModel tm(graph, graph.getNumType(), m_frozentypes);
		MCMC mcmc(tm,m_modelType);			
		m_numVtx=tm.m_graph.getNumVtx();
		m_numType=tm.getNumType();		
		unsigned * mostLikelyTypes=new unsigned[m_numVtx];
		
		//
		//mostLikelyTypes.clear();
		hasWrongLabeled=false;
		numWrong=0;
		for(i=0;i<m_numVtx;i++){
			unsigned gtype=graph.getVertex(i).getType();
			
			if(tm.isGTypeFrozen(gtype)){
				mostLikelyTypes[i]=tm.getVtxType(i);
				continue;
			}
			
			bool iswronglabeled=runAllbutoneVtx(i, mostLikelyTypes, mcmc);	
			//cout<<"haha"<<endl;
			if(iswronglabeled){
				hasWrongLabeled=true;
				numWrong++;
				
			}		
			cout<<i<<endl;
		}
		//cout<<"Number of wrong labeled vertices w/p >= 0.9:"<<m_numVtxWrongWPGE9<<endl;
		numIter++;
		mostLikelyValues.clear();
		for(i=0;i<m_numVtx;i++){
			string value;
			switch(mostLikelyTypes[i]){
				case 0:
					value="pelagic";
					break;
				case 1:
					value="benthic";
					break;
				case 2:
					value="benthopelagic";
					break;
				case 3:
					value="demersal";
					break;
				case 4:
					value="land-based";
					break;
				default:
					value="";
					break;
			}
			//switch(mostLikelyTypes[i]){
			//	case 0:
			//		value="0";
			//		break;
			//	case 1:
			//		value="1";
			//		break;				
			//	default:
			//		value="";
			//		break;
			//}
			mostLikelyValues.push_back(value);
		}
		cout<<"number wrong:\t"<<numWrong<<endl;
		cout<<"mostLikelyValues.size():\t"<<mostLikelyValues.size()<<endl;
		//getchar();
		/*for(i=0;i<mostLikelyValues.size();i++)
		{
			cout<<mostLikelyValues[i]<<"\t";
		}*/
		getchar();
		string m_filename_mostlikelivalues("./report/mostlikelivalues"+to_string(numIter-1)+"-"+to_string(numWrong)+".txt");
		ofstream m_outfile_mostlikelivalues(m_filename_mostlikelivalues.c_str(),ios_base::app);
		for(i=0;i<mostLikelyValues.size();i++){
			m_outfile_mostlikelivalues<<mostLikelyValues[i]<<endl;
		}
		report->closeAllReports();
		delete [] mostLikelyTypes;
		
	}while(hasWrongLabeled);
	cout<<"Iteration number: "<<numIter<<endl;	
	getchar();	
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
	//for(i=0;i<1;i++){
	//	report=Report::getReport(i+100);
	//	Graph graph(GRAPH_FILE,mostLikelyValues);
	//	TypeModel tmA(graph.getNumType(),graph,frozentypes);
	//	TypeModel tmB(graph.getNumType(),graph,frozentypes);
	//	MCMCAlg mcmcalg(tmA,tmB,50,20000,50,20000,500,1,1,toplist,mostLikelyTypes,&hasWrongLabeled,&numWrong,false);
	//	mcmcalg.runMCMCAlg();		
	//	report->closeAllReports();
	//}
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	//cout<<"Total Time: "<<fTotalTime<<endl;
	//cout<<"mostLikelyTypes.size():\t"<<mostLikelyTypes.size()<<endl;
	//getchar();
	//for(i=0;i<mostLikelyTypes.size();i++)
	//{
	//	cout<<mostLikelyTypes[i]<<"\t";
	//}
	//getchar();
	//return 0;	
}

void AllbutoneAlg::runAllbutoneLearningAlg(){	
	unsigned i;
	unsigned numIter=0;
	bool hasWrongLabeled;
	unsigned numWrong;
	static Report * report;
	vector<string> mostLikelyValues;
	do{	
		report=Report::getReport(numIter);
		Graph graph(m_graphfile,mostLikelyValues);
		//Graph graph(GRAPH_FILE,assignedMostLikelyValues);
		//cout<<graph.getNumVtx()<<endl;	
		TypeModel tm(graph, graph.getNumType(), m_frozentypes);
		MCMC mcmc(tm,m_modelType);			
		m_numVtx=tm.m_graph.getNumVtx();
		m_numType=tm.getNumType();		
		unsigned * mostLikelyTypes=new unsigned[m_numVtx];
		//
		//mostLikelyTypes.clear();
		hasWrongLabeled=false;
		numWrong=0;
		for(i=0;i<m_numVtx;i++){
			unsigned gtype=graph.getVertex(i).getType();
			if(tm.isGTypeFrozen(gtype)){
				mostLikelyTypes[i]=tm.getVtxType(i);
				continue;
			}
			bool iswronglabeled=runAllbutoneVtx(i, mostLikelyTypes, mcmc);		
			if(iswronglabeled){
				hasWrongLabeled=true;
				numWrong++;
				cout<<i<<endl;
			}			
		}		
		numIter++;
		mostLikelyValues.clear();
		for(i=0;i<m_numVtx;i++){
			string value;
			switch(mostLikelyTypes[i]){
				case 0:
					value="pelagic";
					break;
				case 1:
					value="benthic";
					break;
				case 2:
					value="benthopelagic";
					break;
				case 3:
					value="demersal";
					break;
				case 4:
					value="land-based";
					break;
				default:
					value="";
					break;
			}
			//switch(mostLikelyTypes[i]){
			//	case 0:
			//		value="0";
			//		break;
			//	case 1:
			//		value="1";
			//		break;				
			//	default:
			//		value="";
			//		break;
			//}
			mostLikelyValues.push_back(value);
		}
		cout<<"number wrong:\t"<<numWrong<<endl;
		cout<<"mostLikelyValues.size():\t"<<mostLikelyValues.size()<<endl;
		//getchar();
		/*for(i=0;i<mostLikelyValues.size();i++)
		{
			cout<<mostLikelyValues[i]<<"\t";
		}*/
		getchar();
		string m_filename_mostlikelivalues("./report/mostlikelivalues"+to_string(numIter-1)+"-"+to_string(numWrong)+".txt");
		ofstream m_outfile_mostlikelivalues(m_filename_mostlikelivalues.c_str(),ios_base::app);
		for(i=0;i<mostLikelyValues.size();i++){
			m_outfile_mostlikelivalues<<mostLikelyValues[i]<<endl;
		}
		report->closeAllReports();
		delete [] mostLikelyTypes;
		
	}while(hasWrongLabeled);
	cout<<"Iteration number: "<<numIter<<endl;	
	getchar();	
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
	for(i=0;i<25;i++){
		report=Report::getReport(i);
		Graph graph(m_graphfile,mostLikelyValues);
		MCMCAlg mcmcalg(graph, 6, m_frozentypes, 50, 50000, 50, 50000, 500, 1, 1, false, m_modelType, m_groupCorrected);
		mcmcalg.runMCMCAlg();		
		report->closeAllReports();
	}
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	//cout<<"Total Time: "<<fTotalTime<<endl;
	//cout<<"mostLikelyTypes.size():\t"<<mostLikelyTypes.size()<<endl;
	//getchar();
	//for(i=0;i<mostLikelyTypes.size();i++)
	//{
	//	cout<<mostLikelyTypes[i]<<"\t";
	//}
	//getchar();
	//return 0;	
}

bool AllbutoneAlg::runAllbutoneVtx(unsigned vtxno, unsigned * mostLikelyTypes, MCMC & mcmc){	
	unsigned i,j;
	unsigned mutateVtxNo;
	//unsigned sourceType;
	unsigned targetType;
	mutateVtxNo=vtxno;	
	unsigned mostlikelytype=0;
	double mostlikelyprob=0.0;
	bool isWrongLabeled=false;

	//init top vtx seq
	set<unsigned> topVtxSet;	
	for(i=0;i<m_numVtx;i++)
		topVtxSet.insert(i);				
	topVtxSet.erase(vtxno);

	double * m_probs=new double[m_numType];	
	
	for(i=0;i<m_numType;i++)
		m_probs[i]=0.0;

	mcmc.randInitTypeModel(topVtxSet);	
	//sourceType=mcmc.getTypeModel().m_vtxTypeTable[mutateVtxNo];
	targetType=mcmc.getTargetType(mutateVtxNo);
	for(i=0;i<mcmc.m_LHVariPairs.size();i++){
		m_probs[mcmc.m_LHVariPairs[i].first]=mcmc.m_LHVariPairs[i].second;
	}
	ofstream & allbutone_ofs=Report::getReport()->getAllbutoneStream();

	for(j=0;j<m_numType;j++){	
		if(j==0)
			allbutone_ofs<<m_probs[j];
		else
			allbutone_ofs<<'\t'<<m_probs[j];
		if(m_probs[j]>mostlikelyprob){
			mostlikelyprob=m_probs[j];
			mostlikelytype=j;
		}
	}
	allbutone_ofs<<endl;	
	mostLikelyTypes[vtxno]=mostlikelytype;		
	if(mostlikelytype!=mcmc.getTypeModel().getGraph().getVertex(vtxno).getType())	
		isWrongLabeled=true;
	delete [] m_probs;
	//if(isWrongLabeled&&mostlikelyprob>=0.9)
		//m_numVtxWrongWPGE9++;
	return isWrongLabeled;
}
