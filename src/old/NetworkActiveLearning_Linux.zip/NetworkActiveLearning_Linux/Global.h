#ifndef GLOBAL_H
#define GLOBAL_H

#include <string>
#include <vector>
#include <set>
#include <map>
#include <list>
#include <iterator>
#include <fstream>
#include <sstream>
#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <utility>
#include <algorithm>
#include <functional>
#include <limits>


using namespace std;

typedef map<unsigned,unsigned>::value_type valType_uu;
typedef map<unsigned,string>::value_type valType_us;
typedef map<string,unsigned>::value_type valType_su;

#endif
