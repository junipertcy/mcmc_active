#ifndef MCMC_H
#define MCMC_H

#include "TypeModel.h"

class MCMC
{
public:
	MCMC(TypeModel& tm, int blockmodeltype=1, bool groupcorrected=false);
	~MCMC();
	unsigned getTargetType(unsigned mutateVtxNo);
	unsigned getMutateVtx() const {return m_mutateVtxNo;}
	void showLHVari() const;
	void initVtxClassifiMatrix();
	void initGroupConnMatrix(){m_typeModel.initGroupConnMatrix();}
	void updateVtxClassifiMatrix();
	void updateGroupConnMatrix(){m_typeModel.updateGroupConnMatrix();}
	double ** getVtxClassifiMatrix();
	double ** getGroupConnMatrix(){return m_typeModel.getGroupConnMatrix();}
	void randInitTypeModel(const set<unsigned>& topVtxSet);
	void randInitTypeModel(unsigned * vtxtypetable);
	void initTypeModelKL(const set<unsigned>& topVtxSet);
	void mutateTypeModel(unsigned v, unsigned t);
	void initBestTypeModel();
	void updateBestTypeModel();
	double getBestLHvalue() const {return m_bestLLHvalue;}
	const TypeModel& getTypeModel() const {return m_typeModel;}
	//const TypeModel& getBestTypeModel() const {return m_bestTypeModel;}
	//ostream& printBestTypeModel(ostream& os = cout) const {return m_bestTypeModel.printModelInfo(os);}
	const vector<pair<unsigned,double> >& getLHVariPairs() const {return m_LHVariPairs;}
	double getLHvalue() {return m_logLikelihoodValue;}
	double getGraphLLH() {return calcGraphLikelihood();}
	//double getAvgLHvalue(double stabratio);
public:
	void initMargDistri();
	void updateMargDistri();
	double ** getMargDistri();
	
private:
	void calcLHVari(unsigned vtxNo,TypeModel& typeModel);
	//case 1.1: directed for model type 1
	void calcLHVariDM1(unsigned vtxNo,TypeModel& typeModel);
	//case 1.2: directed for model type 2
	void calcLHVariDM2(unsigned vtxNo,TypeModel& typeModel);
	//case 1.3: directed with degree-corrected block model
	void calcLHVariDM3(unsigned v,TypeModel& typeModel);//both out-degree and in-degree will be used
	//case 1.4: directed with degree-corrected block model (integrate w_ij)
	void calcLHVariDM4(unsigned v,TypeModel& typeModel);
	//case 1.5: directed with degree-corrected block model (test 01, w_ij)//weighted orientation
	void calcLHVariDM5(unsigned v,TypeModel& typeModel);
	//case 1.6: directed with degree-corrected block model (test 02, w_ij)//weight=1
	void calcLHVariDM6(unsigned v,TypeModel& typeModel);
	//case 1.7: directed with degree-corrected block model (test 03, w_ij)//out-degree will be used
	void calcLHVariDM7(unsigned v,TypeModel& typeModel);
	//case 1.8: directed with degree-corrected block model (test 04, w_ij)//in-degree will be used
	void calcLHVariDM8(unsigned v,TypeModel& typeModel);
	//case 2.1: undirected for model type 1
	void calcLHVariUDM1(unsigned vtxNo,TypeModel& typeModel);
	//case 2.2: undirected for model type 2
	void calcLHVariUDM2(unsigned vtxNo,TypeModel& typeModel);
	//case 2.3: undirected for model type 3
	void calcLHVariUDM3(unsigned v,TypeModel& typeModel);
	//case 2.4: undirected for model type 4 (integrate w_ij)
	void calcLHVariUDM4(unsigned v,TypeModel& typeModel);
	///////////////////////////
	void initLogTable(unsigned tablesize);
	void initLogGammaTable(unsigned tablesize);
	unsigned calcTargetType();
	double getLogFac(unsigned a);
	double getLog(unsigned a);
	double getLogDivFac(unsigned a, unsigned b);
	double calcLikelihood(const TypeModel & typemodel);
	double calcLikelihoodM1(const TypeModel & typemodel);
	double calcLikelihoodM2(const TypeModel & typemodel);
	double calcLikelihoodM3(const TypeModel & typemodel);
	double calcLikelihoodM4(const TypeModel & typemodel);
	double calcLikelihoodM5(const TypeModel & typemodel);
	double calcLikelihoodM6(const TypeModel & typemodel);
	double calcLikelihoodM7(const TypeModel & typemodel);
	double calcLikelihoodM8(const TypeModel & typemodel);
	double calcGraphLikelihood();
	double calcGraphLikelihoodM1();
	//double calcGraphLikelihoodM2();
	void initLLHValue(){m_firstcalcllh=true; m_logLikelihoodValue=calcLikelihood(m_typeModel);}
	void runKLHeuristic(const set<unsigned>& topVtxSet);
	void updateLLHValue(){m_logLikelihoodValue+=m_LLHVariTable[m_targetType];}
	void groupCorrectLLH(const TypeModel & typemodel, double & llhvalue);
	//void addLikelihoodValue(double LH_ratio){m_likelihoodValues.push_back((*(m_likelihoodValues.end()-1))*LH_ratio);}
	//calculate the log-likelihood value for degree-corrected undirected typemodel.
	double calcLLH_DC_UD(const TypeModel & typemodel);
private:
	static double PI;
	static double W_BAR;
	double * m_transProbSelect;
	double * m_logfactable;	
	double * m_logtable;	
	double * m_loggammatable;	//log_gamma(0),log_gamma(0.5),log_gamma(1)...; log_gamma(i)=m_loggammatable[2i];
	unsigned m_maxsizeLogtable;
	TypeModel & m_typeModel;
	unsigned m_numVtx;
	unsigned m_numType;
	unsigned m_mutateVtxNo;
	//unsigned m_sourceType;
	unsigned m_targetType;
	unsigned m_sourceType;
	double MAXLOGDOUBLE;
	double MINLOGDOUBLE;
	static const unsigned OPTIMIZOR;
	double ** dvtxClassifiMatrix;
	double m_bestLLHvalue;
	//TypeModel m_bestTypeModel;
	//
	vector<double> m_likelihoodValues;
	double m_logLikelihoodValue;
private:
	double ** m_accumuMargDistri;
	long * m_numAccumuMargDistri;
public:
	vector<pair<unsigned,double> > m_LHVariPairs;
	double * m_LLHVariTable;//index means type no.
	long ** m_bestEdgeConnMatrix;
	long * m_bestGroupCardi;
	unsigned * m_bestVtxTypeTable;
	double m_dfac;//direction factor, value between 0 to 1
private:
	int m_blockModelType;
	//
	bool m_firstcalcllh;
	double m_initllhvalue;
	bool m_groupCorrected;
};

#endif


