#include "MutualInfo.h"
#include "Utility.cpp"

MutualInfo::MutualInfo(const MCMC & mca, const MCMC & mcb, const set<unsigned> & topVtxSet): Learner(mca, mcb, topVtxSet, "Mutual Information")
{
	unsigned i;
	m_accumuCondEntropy=new double[m_numVtx];
	m_numAccumuCondEntropy=new long long[m_numVtx];
	m_accumuMargDistri=new double*[m_numVtx];
	for(i=0;i<m_numVtx;i++){
		m_accumuMargDistri[i]=new double[m_numType];
	}	
}

MutualInfo::~MutualInfo(void)
{
	unsigned i;
	for(i=0;i<m_numVtx;i++){
		delete [] m_accumuMargDistri[i];
	}	
	delete [] m_accumuMargDistri;	
	delete [] m_accumuCondEntropy;
	delete [] m_numAccumuCondEntropy;
}
void MutualInfo::resetForNextPhase(){
	unsigned i,j;
	for(i=0;i<m_numVtx;i++){
		for(j=0;j<m_numType;j++){
			m_accumuMargDistri[i][j]=0.0;
		}
	}
	for(i=0;i<m_numVtx;i++){
		m_accumuCondEntropy[i]=0.0;
		m_numAccumuCondEntropy[i]=0;
	}
}
unsigned MutualInfo::getTopVtx(unsigned *arrayTop, unsigned numTop){
	unsigned i,j;
	double margEntropy, condEntropy, mutualEntropy;
	for(i=0,m_arraysize=0;i<m_numVtx;i++){
		if(m_topVtxSet.count(i))
			continue;
		if(m_numAccumuCondEntropy[i]==0){
			cerr<<"need more MCMC steps"<<endl;
			continue;
		}
		condEntropy=m_accumuCondEntropy[i]/(double)m_numAccumuCondEntropy[i];
		double dSum=0.0;
		for(j=0;j<m_numType;j++){
			dSum+=m_accumuMargDistri[i][j];
		}
		if(dSum==0.0){
			cerr<<"need more MCMC steps"<<endl;
			continue;
		}
		for(j=0;j<m_numType;j++){
				m_accumuMargDistri[i][j]/=dSum;
		}
		margEntropy=entropy(m_accumuMargDistri[i],m_numType);
		mutualEntropy=margEntropy-condEntropy;
		m_arrayLearnScores[m_arraysize]=mutualEntropy;
		m_arrayLearnScoresSort[m_arraysize]=mutualEntropy;
		m_arrayVtxNo[m_arraysize]=i;
		m_arrayVtxNoSort[m_arraysize++]=i;
	}
        //for(i=0;i<m_arraysize;i++){
                //cout<<m_arrayLearnScores[i]<<'\t'<<m_arrayVtxNoSort[i]<<endl;
        //}
        //cout<<"======================================================="<<endl;
	quicksort<double,unsigned>(m_arrayLearnScoresSort, m_arrayVtxNoSort, 0, m_arraysize-1);
        //for(i=0;i<m_arraysize;i++){
                //cout<<m_arrayLearnScores[i]<<'\t'<<m_arrayVtxNoSort[i]<<endl;
        //}
	//getTopN(m_arrayLearnScores, arrayTopIndex, m_arraysize, numTop);
	m_numtop = 0;
	set<unsigned>::const_iterator siiter;
	unsigned firsttopvtxno=0;
	bool isNeighbor = false;
	set<unsigned> neighbors;
	unsigned neighborsize=0;
	switch(QUERYSTRATEGY){
		case 1:
			for (i = m_arraysize - 1; (i >= 0) && (m_numtop < numTop); i--) {
				m_arrayTopVtxNo[m_numtop++] = m_arrayVtxNoSort[i];
			}
			break;
		case 2:
			for (i = m_arraysize - 1; (i >= 0) && (m_numtop < numTop); i--) {
				isNeighbor = false;
				siiter = m_topVtxSet.begin();
				for (; siiter != m_topVtxSet.end(); siiter++) {
					if ((m_MC_A.getTypeModel().getGraph().checkEdge(*siiter, m_arrayVtxNoSort[i]))
							|| (m_MC_A.getTypeModel().getGraph().checkEdge(m_arrayVtxNoSort[i],
									*siiter))) {
						isNeighbor = true;
						m_arrayTopVtxNo[m_numtop++] = m_arrayVtxNoSort[i];
						cout << "MI rank of the vtx queried:  " << m_arraysize - i
								<< endl;
						break;
					}
				}
				if ((!isNeighbor) && (rand01() < 0.0)) {
					m_arrayTopVtxNo[m_numtop++] = m_arrayVtxNoSort[i];
					cout << "MI rank of the vtx queried:  " << m_arraysize - i << endl;
				}
			}
			break;
		case 3:// get the vtx with largest MI value and all its neighbors
			firsttopvtxno=m_arrayVtxNoSort[m_arraysize - 1];
			//m_arrayTopVtxNo[m_numtop++] = firsttopvtxno;
			neighbors.insert(firsttopvtxno);
			neighbors.insert(m_MC_A.getTypeModel().getGraph().getVertex(firsttopvtxno).getSources().begin(),
					m_MC_A.getTypeModel().getGraph().getVertex(firsttopvtxno).getSources().end());
			neighbors.insert(m_MC_A.getTypeModel().getGraph().getVertex(firsttopvtxno).getTargets().begin(),
					m_MC_A.getTypeModel().getGraph().getVertex(firsttopvtxno).getTargets().end());
			siiter=neighbors.begin();
			for(;siiter!=neighbors.end();siiter++){
				if(!(m_topVtxSet.count(*siiter)))
					m_arrayTopVtxNo[m_numtop++] = *siiter;
			}
			break;
		case 4:// get the vtx with largest MI value and its up to "numTop-1" neighbors if it has so many neighbors
			firsttopvtxno=m_arrayVtxNoSort[m_arraysize - 1];
			neighbors.insert(firsttopvtxno);
			//m_arrayTopVtxNo[m_numtop++] = firsttopvtxno;
			neighborsize=1;
			for (i = m_arraysize - 1; (i >= 0) && (neighborsize < numTop); i--) {
				if((m_MC_A.getTypeModel().getGraph().getVertex(firsttopvtxno).getSources().count(m_arrayVtxNoSort[i]))||
						(m_MC_A.getTypeModel().getGraph().getVertex(firsttopvtxno).getTargets().count(m_arrayVtxNoSort[i]))){
					neighbors.insert(m_arrayVtxNoSort[i]);
					neighborsize++;
				}
			}
			for(siiter=neighbors.begin();siiter!=neighbors.end();siiter++){
				m_arrayTopVtxNo[m_numtop++] = *siiter;
			}
			break;
		default:
			for (i = m_arraysize - 1; (i >= 0) && (m_numtop < numTop); i--) {
				m_arrayTopVtxNo[m_numtop++] = m_arrayVtxNoSort[i];
			}
	}
    //cout<<"======================================================="<<endl;
	cout<<"tops:"<<endl;
	for(i=0;i<m_numtop;i++){
		arrayTop[i]=m_arrayTopVtxNo[i];
		cout<<arrayTop[i]<<'\t';
	}
	cout<<endl;
	return m_numtop;
}
ostream& MutualInfo::printPhaseResult(ostream& os) const{
	unsigned i,j;
	os<<"Mutual Information:"<<endl;
	for(i=0,j=0;i<m_arraysize;i++,j++){
		while(j<m_arrayVtxNo[i]){
			os<<"Node "<<j<<" :\t"<<-1.0<<"\n";	
			j++;
		}
		os<<"Node "<<m_arrayVtxNo[i]<<" :\t"<<m_arrayLearnScores[i]<<"\n";		
	}
	while(j<m_numVtx){
		os<<"Node "<<j<<" :\t"<<-1.0<<"\n";	
		j++;
	}
	return os;
}
void MutualInfo::updateData(){
	unsigned i;
	unsigned mutatevtxno_a=m_MC_A.getMutateVtx();
	unsigned mutatevtxno_b=m_MC_B.getMutateVtx();
	const vector<pair<unsigned,double> >& lhvpairs_a=m_MC_A.getLHVariPairs();
	const vector<pair<unsigned,double> >& lhvpairs_b=m_MC_B.getLHVariPairs();
	double * probarray=new double[lhvpairs_a.size()];
	for(i=0;i<lhvpairs_a.size();i++){		
		m_accumuMargDistri[mutatevtxno_a][lhvpairs_a[i].first]+=lhvpairs_a[i].second;		
	}
	for(i=0;i<lhvpairs_b.size();i++){		
		m_accumuMargDistri[mutatevtxno_b][lhvpairs_b[i].first]+=lhvpairs_b[i].second;
	}
	for(i=0;i<lhvpairs_a.size();i++)
		probarray[i]=lhvpairs_a[i].second;
	m_accumuCondEntropy[mutatevtxno_a]+=entropy(probarray,(unsigned)(lhvpairs_a.size()));
	m_numAccumuCondEntropy[mutatevtxno_a]++;
	for(i=0;i<lhvpairs_b.size();i++)
		probarray[i]=lhvpairs_b[i].second;
	m_accumuCondEntropy[mutatevtxno_b]+=entropy(probarray,(unsigned)(lhvpairs_b.size()));
	m_numAccumuCondEntropy[mutatevtxno_b]++;
	delete [] probarray;
}
