#include "ModelSelectionAlg.h"
#include "Utility.cpp"

ModelSelectionAlg::ModelSelectionAlg(Graph & graph, set<unsigned> & frozentypes, unsigned numtype, unsigned numinits, unsigned numsteps, bool KL_Heuristic, int typemodel): m_graph(graph), m_frozentypes(frozentypes), m_numInits(numinits), m_numSteps(numsteps), m_KL_Heuristic(KL_Heuristic), m_typemodel(typemodel)
{
	unsigned i;
	m_numType=numtype;
	m_numActiveType=numtype-frozentypes.size();
	m_numVtx=m_graph.getNumVtx();
	m_bestEdgeConnMatrix=new long * [m_numType];
	for(i=0;i<m_numType;i++){
		m_bestEdgeConnMatrix[i]=new long[m_numType];
	}
	m_bestGroupCardi=new long [m_numType];
	m_bestVtxTypeTable=new unsigned [m_numVtx];

	queryVtxTable=new int [m_numVtx];
	for(i=0;i<m_numVtx;i++){
		if(m_frozentypes.count(m_graph.getVertex(i).getType()))
			queryVtxTable[i]=-1;
		else
			queryVtxTable[i]=0;
	}

	for(i=0;i<m_numVtx;i++){
		if(m_frozentypes.count(m_graph.getVertex(i).getType()))
			m_frozenVtxSet.insert(i);
		else
			m_activeVtxArray.push_back(i);
	}
	//cout<<m_activeVtxArray.size();

	m_bestLLHvalue=-(numeric_limits<double>::max());
}
ModelSelectionAlg::~ModelSelectionAlg(void)
{
	unsigned i;
	for(i=0;i<m_numType;i++){
		delete m_bestEdgeConnMatrix[i];
	}
	delete m_bestEdgeConnMatrix;
	delete m_bestGroupCardi;
	delete m_bestVtxTypeTable;
	delete [] queryVtxTable;
}
//void ModelSelectionAlg::runAlg(void)
//{
//	unsigned i, j, k;
//	unsigned mutatevtx;
//	unsigned targettype;
//	//Graph graph(m_graphfile);
//	TypeModel typemodel(m_graph, m_numType, m_frozentypes);
//	MCMC mcmc(typemodel,m_typemodel);
//
//	for(i=0;i<m_numInits;i++){
//		//if(i%(m_numInits/100)==0)
//			//cout<<i/(m_numInits/100)<<"% completed"<<endl;
//		mcmc.m_dfac=1;
//		if(m_KL_Heuristic)
//			mcmc.initTypeModelKL(m_frozenVtxSet);
//		else
//			mcmc.randInitTypeModel(m_frozenVtxSet);
//		mcmc.initBestTypeModel();
//		mcmc.initMargDistri();
//		for(j=0;j<m_numSteps;j++){
//			mutatevtx=getRandRemainVtx(typemodel);
//			targettype=mcmc.getTargetType(mutatevtx);
//			mcmc.mutateTypeModel(mutatevtx,targettype);
//			mcmc.updateBestTypeModel();
//			if(j>m_numSteps/2)
//				mcmc.updateMargDistri();
//		}
//		if(mcmc.getBestLHvalue()>m_bestLLHvalue){
//			m_bestLLHvalue=mcmc.getBestLHvalue();
//			for(j=0;j<m_numType;j++){
//				for(k=0;k<m_numType;k++){
//					m_bestEdgeConnMatrix[j][k]=mcmc.m_bestEdgeConnMatrix[j][k];
//				}
//				m_bestGroupCardi[j]=mcmc.m_bestGroupCardi[j];
//			}	
//			for(j=0;j<m_numVtx;j++){
//				m_bestVtxTypeTable[j]=mcmc.m_bestVtxTypeTable[j];
//			}
//		}		
//		cout<<"Best LLH value: "<<mcmc.getBestLHvalue()<<endl;
//		cout<<"Wrong Number: "<<calcNumWrongLabelingVtx()<<endl;
//	}
//	//query(0.1);
//	double ** margdistr=mcmc.getMargDistri();
//
//	ofstream outfile("./report/modelselection.txt",std::ios_base::app);
//	ofstream outfile2("./report/bestllhvalues.txt",std::ios_base::app);
//	outfile2<<m_bestLLHvalue<<endl;
//	outfile2.close();
//	outfile<<"number of groups: "<<m_numType<<"\tlikelihood value: "<<m_bestLLHvalue<<"\tnum wrong: "<<calcNumWrongLabelingVtx()<<endl<<endl;
//	cout<<"number of groups: "<<m_numType<<"\tlikelihood value: "<<m_bestLLHvalue<<endl;
//	
//	ofstream outfile4("./report/bestassignment.txt",std::ios_base::app);
//	outfile4<<"***************************************************************"<<endl;
//	outfile4<<"            k="<<m_numType<<"               "<<endl;
//	outfile4<<"***************************************************************"<<endl;
//	for(j=0;j<m_numVtx;j++)
//		outfile4<<j+1<<"\t"<<m_bestVtxTypeTable[j]<<endl;
//
//	//outfile<<"Best Group Assignment:"<<endl;
//	//for(j=0;j<m_numVtx;j++){
//	//	outfile<<"node "<<j+1<<"\ttype: "<<m_bestVtxTypeTable[j]<<endl;
//	//}
//	//outfile<<"Best Group Members:"<<endl;
//	ofstream outfile3("./report/bestgroups.txt",std::ios_base::app);
//	outfile3<<"***************************************************************"<<endl;
//	outfile3<<"            k="<<m_numType<<"               "<<endl;
//	outfile3<<"***************************************************************"<<endl;
//	for(j=0;j<m_numType;j++){
//		for(i=0;i<m_numVtx;i++){
//			if(m_bestVtxTypeTable[i]==j){
//				//outfile<<"node "<<i+1<<"\tmodel type: "<<m_bestVtxTypeTable[i]<<"\treal type: "<<m_graph.getVertex(i).getType()<<endl;
//				outfile3<<i+1<<"\t"<<m_bestVtxTypeTable[i]<<endl;
//				//for(k=0;k<m_numType;k++){
//				//	outfile<<margdistr[i][k]<<"\t";
//				//}
//				//outfile<<endl;
//			}
//		}
//	}
//
//	outfile3.close();
//	outfile4.close();
//
//	outfile.close();
//
//	//vector<unsigned> degrees0;
//	//vector<unsigned> degrees1;
//	//vector<unsigned> degreesIn0;
//	//vector<unsigned> degreesIn1;
//	//vector<unsigned> degreesOut0;
//	//vector<unsigned> degreesOut1;
//	//for(i=0;i<m_numVtx;i++){
//	//	if(m_bestVtxTypeTable[i]==0){
//	//		degrees0.push_back(m_graph.getVtxDegree(i));
//	//		degreesIn0.push_back(m_graph.getVertex(i).getInDegree());
//	//		degreesOut0.push_back(m_graph.getVertex(i).getOutDegree());
//	//	}else{
//	//		degrees1.push_back(m_graph.getVtxDegree(i));
//	//		degreesIn1.push_back(m_graph.getVertex(i).getInDegree());
//	//		degreesOut1.push_back(m_graph.getVertex(i).getOutDegree());
//	//	}
//	//}
//	//sort(degrees0.begin(),degrees0.end());
//	//sort(degrees1.begin(),degrees1.end());
//	//sort(degreesIn0.begin(),degreesIn0.end());
//	//sort(degreesIn1.begin(),degreesIn1.end());
//	//sort(degreesOut0.begin(),degreesOut0.end());
//	//sort(degreesOut1.begin(),degreesOut1.end());	
//	//cout<<"Degree of Group 0:"<<endl;
//	//print_ui_vec(degrees0);
//	//cout<<"Degree of Group 1:"<<endl;
//	//print_ui_vec(degrees1);
//	//cout<<"In-degree of Group 0:"<<endl;
//	//print_ui_vec(degreesIn0);
//	//cout<<"Out-degree of Group 0:"<<endl;
//	//print_ui_vec(degreesOut0);
//	//cout<<"In-degree of Group 1:"<<endl;
//	//print_ui_vec(degreesIn1);
//	//cout<<"Out-degree of Group 1:"<<endl;
//	//print_ui_vec(degreesOut1);
//	//getchar();
//
//}
void ModelSelectionAlg::runAlg(void)
{
	unsigned i, j, k, l;
	unsigned mutatevtx;
	unsigned targettype;
	//Graph graph(m_graphfile);
	TypeModel typemodel(m_graph, m_numType, m_frozentypes);
	MCMC mcmc(typemodel,m_typemodel);
	//printTrueRhos();

	ofstream outfile_dfacnormmi("./report/dfac_normmi.txt",std::ios_base::app);
	for(l=0;l<1;l++){		
		double dfac=1.0*l/100;
		dfac=1;
		//double dfac=1;
		mcmc.m_dfac=dfac;
		cout<<dfac<<"\t";
		outfile_dfacnormmi<<dfac<<"\t";
		m_bestLLHvalue=LARGE_NEGATIVE_VALUE;
		for(i=0;i<m_numInits;i++){
			//if(i%(m_numInits/100)==0)
			//cout<<i/(m_numInits/100)<<"% completed"<<endl;
			if(m_KL_Heuristic)
				mcmc.initTypeModelKL(m_frozenVtxSet);
			else
				mcmc.randInitTypeModel(m_frozenVtxSet);
			mcmc.initBestTypeModel();
			mcmc.initMargDistri();
			for(j=0;j<m_numSteps;j++){
				mutatevtx=getRandRemainVtx(typemodel);
				targettype=mcmc.getTargetType(mutatevtx);
				mcmc.mutateTypeModel(mutatevtx,targettype);
				mcmc.updateBestTypeModel();
				//if(j==m_numSteps/2)
				//mcmc.changeModelType(5);
				if(j>m_numSteps/2)
					mcmc.updateMargDistri();
			}
			if(mcmc.getBestLHvalue()>m_bestLLHvalue){
				m_bestLLHvalue=mcmc.getBestLHvalue();
				for(j=0;j<m_numType;j++){
					for(k=0;k<m_numType;k++){
						m_bestEdgeConnMatrix[j][k]=mcmc.m_bestEdgeConnMatrix[j][k];
					}
					m_bestGroupCardi[j]=mcmc.m_bestGroupCardi[j];
				}	
				for(j=0;j<m_numVtx;j++){
					m_bestVtxTypeTable[j]=mcmc.m_bestVtxTypeTable[j];
				}
			}		
			//cout<<"Best LLH value: "<<m_bestLLHvalue<<endl;
			unsigned numwrong=calcNumWrongLabelingVtx();
			cout<<"Wrong Number: "<<numwrong<<endl;
			//cout<<"Wrong %: "<<double(int((double)numwrong/m_numVtx*100*100))/100<<endl;
		}
		double normmi=calcNormMIWithTrueClassification();
		cout<<"Norm MI: "<<normmi<<"\t";
		cout<<"LLH Value: "<<m_bestLLHvalue<<endl;
		outfile_dfacnormmi<<normmi<<"\t";
		outfile_dfacnormmi<<m_bestLLHvalue<<endl;
	}
	outfile_dfacnormmi.close();
	//printTrueRhos();
	printBestRhos();
	//query(0.1);
	double ** margdistr=mcmc.getMargDistri();

	ofstream outfile("./report/modelselection.txt",std::ios_base::app);
	ofstream outfile2("./report/bestllhvalues.txt",std::ios_base::app);
	outfile2<<m_bestLLHvalue<<endl;
	outfile2.close();
	outfile<<"number of groups: "<<m_numType<<"\tlikelihood value: "<<m_bestLLHvalue<<"\tnum wrong: "<<calcNumWrongLabelingVtx()<<endl<<endl;
	cout<<"number of groups: "<<m_numType<<"\tlikelihood value: "<<m_bestLLHvalue<<endl;
	
	ofstream outfile4("./report/bestassignment.txt",std::ios_base::app);
	outfile4<<"***************************************************************"<<endl;
	outfile4<<"            k="<<m_numType<<"               "<<endl;
	outfile4<<"***************************************************************"<<endl;
	for(j=0;j<m_numVtx;j++)
		outfile4<<j+1<<"\t"<<m_bestVtxTypeTable[j]<<endl;

	//outfile<<"Best Group Assignment:"<<endl;
	//for(j=0;j<m_numVtx;j++){
	//	outfile<<"node "<<j+1<<"\ttype: "<<m_bestVtxTypeTable[j]<<endl;
	//}
	//outfile<<"Best Group Members:"<<endl;
	ofstream outfile3("./report/bestgroups.txt",std::ios_base::app);
	outfile3<<"***************************************************************"<<endl;
	outfile3<<"            k="<<m_numType<<"               "<<endl;
	outfile3<<"***************************************************************"<<endl;
	for(j=0;j<m_numType;j++){
		for(i=0;i<m_numVtx;i++){
			if(m_bestVtxTypeTable[i]==j){
				//outfile<<"node "<<i+1<<"\tmodel type: "<<m_bestVtxTypeTable[i]<<"\treal type: "<<m_graph.getVertex(i).getType()<<endl;
				outfile3<<i+1<<"\t"<<m_bestVtxTypeTable[i]<<endl;
				//for(k=0;k<m_numType;k++){
				//	outfile<<margdistr[i][k]<<"\t";
				//}
				//outfile<<endl;
			}
		}
	}

	outfile3.close();
	outfile4.close();

	outfile.close();

	//vector<unsigned> degrees0;
	//vector<unsigned> degrees1;
	//vector<unsigned> degreesIn0;
	//vector<unsigned> degreesIn1;
	//vector<unsigned> degreesOut0;
	//vector<unsigned> degreesOut1;
	//for(i=0;i<m_numVtx;i++){
	//	if(m_bestVtxTypeTable[i]==0){
	//		degrees0.push_back(m_graph.getVtxDegree(i));
	//		degreesIn0.push_back(m_graph.getVertex(i).getInDegree());
	//		degreesOut0.push_back(m_graph.getVertex(i).getOutDegree());
	//	}else{
	//		degrees1.push_back(m_graph.getVtxDegree(i));
	//		degreesIn1.push_back(m_graph.getVertex(i).getInDegree());
	//		degreesOut1.push_back(m_graph.getVertex(i).getOutDegree());
	//	}
	//}
	//sort(degrees0.begin(),degrees0.end());
	//sort(degrees1.begin(),degrees1.end());
	//sort(degreesIn0.begin(),degreesIn0.end());
	//sort(degreesIn1.begin(),degreesIn1.end());
	//sort(degreesOut0.begin(),degreesOut0.end());
	//sort(degreesOut1.begin(),degreesOut1.end());	
	//cout<<"Degree of Group 0:"<<endl;
	//print_ui_vec(degrees0);
	//cout<<"Degree of Group 1:"<<endl;
	//print_ui_vec(degrees1);
	//cout<<"In-degree of Group 0:"<<endl;
	//print_ui_vec(degreesIn0);
	//cout<<"Out-degree of Group 0:"<<endl;
	//print_ui_vec(degreesOut0);
	//cout<<"In-degree of Group 1:"<<endl;
	//print_ui_vec(degreesIn1);
	//cout<<"Out-degree of Group 1:"<<endl;
	//print_ui_vec(degreesOut1);
	//getchar();

}

unsigned ModelSelectionAlg::getRandRemainVtx(TypeModel & typemodel){
	unsigned randindex;
	unsigned vtxno;
	do{
		randindex=randN(m_activeVtxArray.size());
		vtxno=m_activeVtxArray[randindex];
	}while(!(typemodel.isVtxMutable(vtxno)));
	return vtxno;
}

void ModelSelectionAlg::query(double ratio){//query type of vertices for each group with the given ratio
	unsigned i,j;
	unsigned numQuery=unsigned(m_activeVtxArray.size()*ratio);
	vector<vector<unsigned> > mtypebins;//each bin collects the vertices for a certain type (in model)
	unsigned numTypeInGraph=m_graph.getNumType();
	unsigned randindex=0;
	unsigned * gtypecardi=new unsigned[numTypeInGraph];//for a certain type in model, each entry i in this array is the number of vertices of type i (in the graph)
	//vector<vector<unsigned> >::const_iterator tybiniter=typebins.begin();
	for(i=0;i<m_numType;i++){
		vector<unsigned> bin;
		for(j=0;j<m_numVtx;j++){			
			if(m_bestVtxTypeTable[j]==i)
				bin.push_back(j);
		}
		mtypebins.push_back(bin);
	}	
	vector<unsigned> numQueryInBins;
	for(i=0;i<m_numType;i++){
		numQueryInBins.push_back(mtypebins[i].size()*ratio);
	}
	for(i=0;i<m_numType;i++){
		for(j=0;j<numQueryInBins[i];){
			randindex=randN(mtypebins[i].size());
			if(queryVtxTable[mtypebins[i][j]]==1)
				continue;
			queryVtxTable[mtypebins[i][j]]=1;
			gtypecardi[m_graph.getVertex(mtypebins[i][j]).getType()]++;
			j++;
		}
	}
	for(j=0;j<m_numVtx;j++){	
		cout<<queryVtxTable[j]<<"";
	}
}
unsigned ModelSelectionAlg::calcNumWrongLabelingVtx(){
	unsigned i,j;
	unsigned numWrong=0;
	unsigned numTotal=0;//total number of vertices in bins
	unsigned numMajority=0;//number of vertices in the largest bin
	unsigned typeMajority=0;//type (in graph) of the majority (largest bin)
	unsigned numTypeInGraph=m_graph.getNumType();
	unsigned * typebins=new unsigned[numTypeInGraph];
	ofstream outfile("./report/modelselection.txt",std::ios_base::app);
	for(i=0;i<m_numType;i++){
		for(j=0;j<numTypeInGraph;j++)
			typebins[j]=0;
		numTotal=0;
		numMajority=0;
		typeMajority=0;
		for(j=0;j<m_numVtx;j++){
			if(m_bestVtxTypeTable[j]!=i)
				continue;
			typebins[m_graph.getVertex(j).getType()]++;
		}
		for(j=0;j<numTypeInGraph;j++){
			if(typebins[j]>numMajority){
				numMajority=typebins[j];
				typeMajority=j;
			}
			numTotal+=typebins[j];
		}
		numWrong+=(numTotal-numMajority);
		//outfile<<double(numMajority)/double(numTotal)<<"\tnumWrong: "<<numTotal-numMajority<<"\tnumTotal: "<<numTotal<<"\ttypeInGraph: "<<typeMajority<<endl;
	}
	//calcBestMerge();
	outfile.close();
	delete [] typebins;
	return numWrong;
}

//unsigned ModelSelectionAlg::calcNumWrongLabelingVtx(){
//	unsigned i,j;
//	unsigned numWrong=0;
//	unsigned numTotal=0;//total number of vertices in bins
//	unsigned numMajority=0;//number of vertices in the largest bin
//	unsigned typeMajority=0;//type (in graph) of the majority (largest bin)
//	unsigned numTypeInGraph=m_graph.getNumType();
//	unsigned * typebins=new unsigned[numTypeInGraph];
//	for(i=0;i<m_numType;i++){
//		for(j=0;j<numTypeInGraph;j++)
//			typebins[j]=0;
//		numTotal=0;
//		numMajority=0;
//		typeMajority=0;
//		for(j=0;j<m_numVtx;j++){
//			if(m_bestVtxTypeTable[j]!=i)
//				continue;
//			typebins[m_graph.getVertex(j).getType()]++;
//		}
//		for(j=0;j<numTypeInGraph;j++){
//			if(typebins[j]>numMajority){
//				numMajority=typebins[j];
//				typeMajority=j;
//			}
//			numTotal+=typebins[j];
//		}
//		numWrong+=(numTotal-numMajority);
//		cout<<double(numMajority)/double(numTotal)<<"\tnumWrong: "<<numTotal-numMajority<<"\tnumTotal: "<<numTotal<<"\ttypeInGraph: "<<typeMajority<<endl;
//	}
//	cout<<endl;
//	calcBestMerge();
//	delete [] typebins;
//	return numWrong;
//}
void ModelSelectionAlg::calcBestMerge(){
	unsigned i,j,k;
	double ** deltaLLHvalues=new double*[m_numType-1];
	unsigned * newVtxTypeTable=new unsigned[m_numVtx];
	TypeModel typemodel(m_graph,m_numType-1,m_frozentypes);
	MCMC mcmc(typemodel);
	ofstream outfile("./report/modelselection.txt",std::ios_base::app);
	for(i=0;i<m_numType-1;i++)
		deltaLLHvalues[i]=new double[m_numType];
	for(i=0;i<m_numType-1;i++){//merge two groups i and j
		for(j=i+1;j<m_numType;j++){			
			for(k=0;k<m_numVtx;k++){
				if(m_bestVtxTypeTable[k]==j)
					newVtxTypeTable[k]=i;
				else if(m_bestVtxTypeTable[k]>j)
					newVtxTypeTable[k]=m_bestVtxTypeTable[k]-1;
				else
					newVtxTypeTable[k]=m_bestVtxTypeTable[k];
			}
			mcmc.randInitTypeModel(newVtxTypeTable);
			deltaLLHvalues[i][j]=mcmc.getLHvalue()-m_bestLLHvalue;
			//cout<<"merge "<<i<<" and "<<j<<"\tDelta LLH: "<<deltaLLHvalues[i][j]<<endl;
			
		}

	}	
	getchar();
	outfile.close();
	
	//cout<<double(numMajority)/double(numTotal)<<"\tnumWrong: "<<numTotal-numMajority<<"\tnumTotal: "<<numTotal<<"\ttypeInGraph: "<<typeMajority<<endl;

	for(i=0;i<m_numType-1;i++)
		delete [] deltaLLHvalues[i];
	delete [] deltaLLHvalues;
	delete [] newVtxTypeTable;
}
double ModelSelectionAlg::calcNormMIWithTrueClassification(){
	unsigned i;
	double normMIvalue;
	unsigned * c1=new unsigned[m_numVtx];
	for(i=0;i<m_numVtx;i++){
		c1[i]=m_graph.getVertex(i).getType();
	}
	normMIvalue=calcNormMI(m_graph.getNumType(),m_numType,m_numVtx,c1,m_bestVtxTypeTable);
	delete [] c1;
	return normMIvalue;
}
void ModelSelectionAlg::printTrueRhos(){
	unsigned i,j;
	unsigned eij_out,eij_in,eij;
	unsigned * c1=new unsigned[m_numVtx];
	ofstream outfile("./report/true_rhos.txt",std::ios_base::app);
	TypeModel typemodel(m_graph, m_numType, m_frozentypes);
	for(i=0;i<m_numVtx;i++){
		c1[i]=m_graph.getVertex(i).getType();
	}
	MCMC mcmc(typemodel,m_typemodel);	
	mcmc.randInitTypeModel(c1);
	for(i=0;i<m_numType;i++){
		outfile<<m_graph.getValueFromType(i)<<"\t";
	}
	outfile<<endl<<endl;
	for(i=0;i<m_numType;i++){
		for(j=0;j<m_numType;j++){
			eij_out=typemodel.m_numEdgesOf2Groups[i][j];
			eij_in=typemodel.m_numEdgesOf2Groups[j][i];
			eij=eij_out+eij_in;
			if(eij==0)
				outfile<<"null"<<"\t";
			else
				outfile<<(double)eij_out/eij<<"\t";
			//outfile<<"Rho("<<i<<","<<j<<")="<<(double)eij_out/eij<<"\t";
			//outfile<<"Rho("<<j<<","<<i<<")="<<(double)eij_in/eij<<endl;
		}
		outfile<<endl;
	}
	outfile<<endl;
	for(i=0;i<m_numType;i++){
		outfile<<m_graph.getValueFromType(i)<<endl;
	}
	delete [] c1;
	outfile.close();
}
void ModelSelectionAlg::printBestRhos(){
	unsigned i,j;
	unsigned eij_out,eij_in,eij;
	unsigned * c1=new unsigned[m_numVtx];
	ofstream outfile("./report/best_rhos.txt",std::ios_base::app);
	TypeModel typemodel(m_graph, m_numType, m_frozentypes);
	MCMC mcmc(typemodel,m_typemodel);	
	mcmc.randInitTypeModel(m_bestVtxTypeTable);
	for(i=0;i<m_numType;i++){
		outfile<<m_graph.getValueFromType(i)<<"\t";
	}
	outfile<<endl<<endl;
	for(i=0;i<m_numType;i++){
		for(j=0;j<m_numType;j++){
			eij_out=typemodel.m_numEdgesOf2Groups[i][j];
			eij_in=typemodel.m_numEdgesOf2Groups[j][i];
			eij=eij_out+eij_in;
			if(eij==0)
				outfile<<"null"<<"\t";
			else
				outfile<<(double)eij_out/eij<<"\t";
			//outfile<<"Rho("<<i<<","<<j<<")="<<(double)eij_out/eij<<"\t";
			//outfile<<"Rho("<<j<<","<<i<<")="<<(double)eij_in/eij<<endl;
		}
		outfile<<endl;
	}
	outfile<<endl;
	for(i=0;i<m_numType;i++){
		outfile<<m_graph.getValueFromType(i)<<endl;
	}
	delete [] c1;
	outfile.close();
}