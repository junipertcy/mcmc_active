#include "NetWorkAlgTimer.h"

/*  
    This file contains the code for timestamping.
    Hopefully you won't have any problems compiling in your environment
*/

double fTotalTime;
double fStartTimeStamp;
double fCurrentTimeStamp;

#ifdef WIN32

  struct _timeb tstruct;

#else

  struct timeval tv;
  struct timezone tzp;
  struct tms prog_tms;

#endif

#ifdef WIN32

  void CurrentTime() {
    _ftime64_s( &tstruct );
    fCurrentTimeStamp = ((double) tstruct.time + ((double)tstruct.millitm)/1000.0);
  }

  double TimeElapsed()
  {
    double answer;

    CurrentTime();
    answer = fCurrentTimeStamp - fStartTimeStamp;
    return answer;
  }

#else

  void CurrentTime() {
    times(&prog_tms);
    fCurrentTimeStamp = (double)prog_tms.tms_utime;
  }

  double TimeElapsed() {

    double answer;

    times(&prog_tms);
    answer = (((double)prog_tms.tms_utime-fStartTimeStamp)/((double)sysconf(_SC_CLK_TCK)));
    return answer;
  }

#endif

void StartClock() {
  CurrentTime();
  fStartTimeStamp = fCurrentTimeStamp;
}

void StopClock() {
  fTotalTime = TimeElapsed();
}

