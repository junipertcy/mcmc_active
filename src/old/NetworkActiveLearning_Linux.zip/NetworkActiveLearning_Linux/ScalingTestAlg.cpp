#include "ScalingTestAlg.h"
#include "Utility.cpp"

unsigned ScalingTestAlg::numAccuracyBlock=10;
//#define Debug

ScalingTestAlg::ScalingTestAlg(const Graph& graph, unsigned numTypeInModel, set<unsigned> & frozentypes, unsigned numOptInit, unsigned numLearnerInit, unsigned numPhase, unsigned numTop, unsigned method,  bool klheuristic, unsigned modelType) : m_graph(graph), m_typeModelA(graph,numTypeInModel,frozentypes),m_typeModelB(graph,numTypeInModel,frozentypes),m_MC_A(m_typeModelA,modelType), m_MC_B(m_typeModelB,modelType){
	unsigned i;
	m_numOptInit=numOptInit;
	m_numLearnerInit=numLearnerInit;
	m_numPhase=numPhase;
	m_numTop=numTop;
	m_method=method;
	m_klheuristic=klheuristic;

	switch(m_method){
		case 1: m_learner = new MutualInfo(m_MC_A,m_MC_B,m_topVtxSet);
			break;
		case 2: m_learner = new AvgAgree(m_MC_A,m_MC_B,m_topVtxSet);
			break;
		case 3: m_learner = new RandomLearner(m_MC_A,m_MC_B,m_topVtxSet);
			break;
		//case 4: m_learner = new TopSeqLearner(m_MC_A,m_MC_B,m_topVtxSet,topVtxSeqFileName);
			//break;
		case 5: m_learner = new MaxDegree(m_MC_A,m_MC_B,m_topVtxSet);
			break;
		default: m_learner = new MutualInfo(m_MC_A,m_MC_B,m_topVtxSet);
	}	

	m_alltypefixed=false;

	m_numVtx=m_typeModelA.getGraph().getNumVtx();
	m_numTypeGraph=m_typeModelA.getGraph().getNumType();
	m_numTypeModel=m_typeModelA.getNumType();	

	for(i=0;i<m_numVtx;i++){
		m_remainVtxSet.insert(i);
	}
	//init top vtx seq
	for(i=0;i<m_numVtx;i++){
		unsigned gtype=m_graph.getVertex(i).getType();
		if(m_typeModelA.isGTypeFrozen(gtype)){
			m_topVtxSet.insert(i);
			m_remainVtxSet.erase(i);
			m_topVtxSeq.push_back(i);
		}
	}
	//showiset(m_topVtxSet);

	m_accumuMargDistri=new double*[m_numVtx];
	for(i=0;i<m_numVtx;i++){
		m_accumuMargDistri[i]=new double[m_numTypeModel];
	}

	if(m_method==3||m_method==4||m_method==5){
		m_numLearnerInit=0;		
	}

	//report begin--------------------------------------------
	ofstream & graphinfo=Report::getReport()->getGraphStream();
	graph.printGraphInfo(graphinfo);
	//report end----------------------------------------------

	//report begin--------------------------------------------
	ofstream & outfile=Report::getReport()->getOutputStream();
	outfile<<"selfloops "<<m_graph.hasSelfloop()<<endl;
	outfile<<"initials "<<m_numOptInit<<endl;
	//outfile<<"iterations "<<m_numOptStep<<endl;
	outfile<<"phases "<<m_numPhase<<endl;
	outfile<<"number of groups (graph)"<<m_numTypeGraph<<endl;
	outfile<<"number of groups (model)"<<m_numTypeModel<<endl;
	outfile<<"tops "<<m_numTop<<endl;
	outfile<<"vertex-query-method "<<m_learner->getMethodName()<<endl;
	//report end----------------------------------------------

	//report begin--------------------------------------------
	ofstream & paramsfile=Report::getReport()->getParamsStream();
	paramsfile<<"directed "<<m_typeModelA.getGraph().isDirected()<<endl;
	paramsfile<<"selfloops "<<m_typeModelA.getGraph().hasSelfloop()<<endl;
	paramsfile<<"optimizer initials "<<m_numOptInit<<endl;
	paramsfile<<"learner initials "<<m_numLearnerInit<<endl;
	paramsfile<<"phases "<<m_numPhase<<endl;
	paramsfile<<"number of groups (graph)"<<m_numTypeGraph<<endl;
	paramsfile<<"number of groups (model)"<<m_numTypeModel<<endl;
	paramsfile<<"tops "<<m_numTop<<endl;
	paramsfile<<"vertex-query-method "<<m_learner->getMethodName()<<endl;
	//report end----------------------------------------------



	/*m_MC_A.randInitTypeModel(m_topVtxSet);
	cout<<m_MC_A.getLHvalue()<<endl;
	getchar();*/

}
ScalingTestAlg::~ScalingTestAlg(){
	unsigned i;

	for(i=0;i<numAccuracyBlock-1;i++){
		delete [] m_accuracyMatrix[i];
	}
	delete [] m_accuracyMatrix;

	for(i=0;i<m_numVtx;i++){
		delete [] m_accumuMargDistri[i];
	}	
	delete [] m_accumuMargDistri;
	//delete [] m_accuracyNum;
	if(m_learner)
		delete m_learner;
}

void ScalingTestAlg::runAlg(){		
	//initPhaseAccuracyMatrix();
	StartClock();
	m_curPhase=1;
#ifdef RESUME
	m_curPhase=m_resumePhase;
#endif
	for(;(m_curPhase<=m_numPhase)&&(m_remainVtxSet.size()>0);m_curPhase++){
		runOnePhase();		
	}
	StopClock();	
	writeTopVtxSeq();
	//writePhaseAccuracyMatrix();
}

void ScalingTestAlg::runOnePhase(){

	unsigned i,j;

	checkTypeFixed();

	//m_dSumLHvalueInPhase=0.0;

	//m_lNumLHvalueInPhase=0;

	vecllMaxIter.clear();
	
	m_learner->resetForNextPhase();	
	
	//cout<<"Phase "<<m_curPhase<<":"<<endl;

	//report begin----------------------------------------------------------------------------
	ofstream & outfile=Report::getReport()->getOutputStream();
	ofstream & maxllhsfile=Report::getReport()->getMaxLLHsStream();
	ofstream & bestconnmtxfile=Report::getReport()->getBestConnMatrixStream();
	outfile<<"-------------Phase "<<m_curPhase<<" ("<<m_learner->getMethodName()<<")-------------"<<endl;	
	outfile<<"Known nodes:";
	for(i=0;i<m_topVtxSeq.size();i++){
		outfile<<'\t'<<m_topVtxSeq[i];
	}
	outfile<<endl;
	//report end------------------------------------------------------------------------------

	//initAccuracyNum();	

	initAccumuMargDistri();

	this->m_MC_A.initGroupConnMatrix();
	this->m_MC_B.initGroupConnMatrix();
	this->m_MC_A.initVtxClassifiMatrix();
	this->m_MC_B.initVtxClassifiMatrix();

	
	for(m_curInit=1;m_curInit<=max(m_numOptInit,m_numLearnerInit);m_curInit++){	

		cout<<"phase #: "<<m_curPhase<<"\tinit #: "<<m_curInit<<endl;
		runOneInit();
		vecllMaxIter.push_back(m_llMaxIter);
		
	}

	ofstream & maxiterfile=Report::getReport()->getEquiIterNumStream();
	long long sumMaxIter=0;
	for(i=0;i<vecllMaxIter.size();i++){
		sumMaxIter+=vecllMaxIter[i];
		maxiterfile<<vecllMaxIter[i]<<" ";
	}
	maxiterfile<<(double)sumMaxIter/(double)(vecllMaxIter.size())<<endl;

	//report begin----------------------------------------------------------------------------
	outfile<<"Sampler level result:"<<endl;
	outfile<<"Groups:";
	for(i=0;i<m_numTypeGraph;i++){ //m_numType-1
		outfile<<'\t'<<m_MC_A.getTypeModel().getGraph().getValueFromType(i);
	}
	outfile<<endl;
	for(i=0;i<m_numVtx;i++){
		if(m_topVtxSet.count(i))
			continue;
		outfile<<"Node "<<i<<" :";
		double dSum=0.0;
		for(j=0;j<m_numTypeModel;j++){ //m_numType-1
			dSum+=m_accumuMargDistri[i][j];
		}
		if(dSum==0.0){
			cerr<<"need more MCMC steps"<<endl;
			continue;
		}
		for(j=0;j<m_numTypeModel;j++){			//m_numType-1
				m_accumuMargDistri[i][j]/=dSum;
				outfile<<'\t'<<m_accumuMargDistri[i][j];
		}
		outfile<<endl;
	}
	if(m_method==3||m_method==4||m_method==5)
		outfile<<"no learning method"<<endl;
	//report end------------------------------------------------------------------------------

	//updatePhaseAccuracyMatrix();
	/*
	cout<<m_numTypeModel<<"\t"<<m_dSumLHvalueInPhase/m_lNumLHvalueInPhase<<endl;
	cout<<"Best model for MCMC_A:"<<endl;
	this->m_MC_A.printBestTypeModel();
	cout<<"Best model for MCMC_B:"<<endl;
	this->m_MC_B.printBestTypeModel();*/
	//

	getTopVtx();

	maxllhsfile<<m_MC_A.getBestLHvalue()/*<<"\t"<<m_MC_B.getBestLHvalue()*/<<endl;

	//const TypeModel & bestTypeModelA=m_MC_A.getBestTypeModel();
	//const TypeModel & bestTypeModelB=m_MC_B.getBestTypeModel();
	bestconnmtxfile<<"phase # "<<this->m_curPhase<<endl;
	bestconnmtxfile<<"group cardinality (# of nodes): "<<endl;
	for(i=0;i<m_numTypeModel;i++)
		bestconnmtxfile<<m_MC_A.m_bestGroupCardi[i]<<"\t";
	bestconnmtxfile<<endl;
	bestconnmtxfile<<"group connection matrix (# of edges): "<<endl;
	for(i=0;i<m_numTypeModel;i++){
		for(j=0;j<m_numTypeModel;j++){
			bestconnmtxfile<<m_MC_A.m_bestEdgeConnMatrix[i][j]<<"\t";
		}
		bestconnmtxfile<<endl;
	}
	bestconnmtxfile<<endl;

	m_learner->printPhaseResult(outfile);

	//report begin----------------------------------------------------------------------------
	outfile<<"average group matrix:"<<endl;	
	double ** groupMatrixA=this->m_MC_A.getGroupConnMatrix();
	double ** groupMatrixB=this->m_MC_B.getGroupConnMatrix();
	for(i=0;i<m_numTypeModel;i++){
		for(j=0;j<m_numTypeModel;j++){
			outfile<<(groupMatrixA[i][j]+groupMatrixB[i][j])/2<<'\t';
		}
		outfile<<endl;
	}
	//report end------------------------------------------------------------------------------

	//report begin----------------------------------------------------------------------------
	ofstream & outfileGroupConnMatrix=Report::getReport()->getGroupConnmatrixStream();
	outfileGroupConnMatrix<<"-------------Phase "<<m_curPhase<<" ("<<m_learner->getMethodName()<<")-------------"<<endl;	
	for(i=0;i<m_numTypeModel;i++){
		for(j=0;j<m_numTypeModel;j++){
			outfileGroupConnMatrix<<(groupMatrixA[i][j]+groupMatrixB[i][j])/2<<'\t';
		}
		outfileGroupConnMatrix<<endl;
	}
	//report end------------------------------------------------------------------------------

	//report begin----------------------------------------------------------------------------
	ofstream & outfileTypeMatrix=Report::getReport()->getTypematrixStream();
	ofstream & outfileConfusionMatrix=Report::getReport()->getConfusionmatrixStream();
	outfileTypeMatrix<<"-------------Phase "<<m_curPhase<<" ("<<"type classification matrix:"<<")-------------"<<endl;	
	outfileConfusionMatrix<<"-------------Phase "<<m_curPhase<<" ("<<"confusion matrix:"<<")-------------"<<endl;	
	double ** typeClassifiMatrix=new double * [m_numTypeGraph];
	for(i=0;i<m_numTypeGraph;i++)
		typeClassifiMatrix[i]=new double[m_numTypeModel];
	for(i=0;i<m_numTypeGraph;i++){
		for(j=0;j<m_numTypeModel;j++){
			typeClassifiMatrix[i][j]=0.0;
		}
	}
	int realtype;
	double ** vtxClassifiMatrixA=m_MC_A.getVtxClassifiMatrix();
	double ** vtxClassifiMatrixB=m_MC_B.getVtxClassifiMatrix();
	for(i=0;i<m_numVtx;i++){
		realtype=m_MC_A.getTypeModel().getGraph().getVertex(i).getType();
		for(j=0;j<m_numTypeModel;j++){
			typeClassifiMatrix[realtype][j]+=(vtxClassifiMatrixA[i][j]+vtxClassifiMatrixB[i][j])/2;
		}
	}
	/*for(i=0;i<m_numType;i++){
		for(j=0;j<m_numType;j++){
			typeClassifiMatrix[i][j]/=m_typeModelA.m_graph.getGroupCardi(i);
		}
	}*/
	//
	unsigned * topvtxGroupCardi=new unsigned[m_numTypeGraph];
	for(i=0;i<m_numTypeGraph;i++)
		topvtxGroupCardi[i]=0;
	set<unsigned>::const_iterator csiter;
	for(csiter=m_topVtxSet.begin();csiter!=m_topVtxSet.end();csiter++){
		realtype=m_typeModelA.m_graph.getVertex(*csiter).getType();
		topvtxGroupCardi[realtype]++;
	}
	//
	for(i=0;i<m_numTypeGraph;i++){
		for(j=0;j<m_numTypeModel;j++){
			if(i==j)
				outfileTypeMatrix<<typeClassifiMatrix[i][j]+topvtxGroupCardi[i]<<'\t';
			else
				outfileTypeMatrix<<typeClassifiMatrix[i][j]<<'\t';
			outfileConfusionMatrix<<typeClassifiMatrix[i][j]<<'\t';
		}
		outfileTypeMatrix<<endl;
		outfileConfusionMatrix<<endl;
	}
	for(i=0;i<m_numTypeGraph;i++)
		delete [] typeClassifiMatrix[i];
	delete [] typeClassifiMatrix;
	delete [] topvtxGroupCardi;
	//report end------------------------------------------------------------------------------
}

void ScalingTestAlg::runOneInit(){	
	
	if(m_klheuristic){	
		m_MC_A.initTypeModelKL(this->m_topVtxSet);	
		m_MC_B.initTypeModelKL(this->m_topVtxSet);	
	}else{
		m_MC_A.randInitTypeModel(this->m_topVtxSet);
		m_MC_B.randInitTypeModel(this->m_topVtxSet);	
	}

	this->m_MC_A.initBestTypeModel();
	this->m_MC_B.initBestTypeModel();

	m_learner->resetForNextInit();//this is very important for average agreement learner.

	m_llMaxIter=10*m_numVtx;

	for(m_llCurStep=1;m_llCurStep<=m_llMaxIter;m_llCurStep++){
		//cout<<"5"<<endl;
		//if(m_curStep%1000==0)
			//cout<<"step #: "<<m_curStep<<endl;
		runOneStep(false);
		//cout<<"6"<<endl;
	}
	m_llMaxIter+=10*m_numVtx;
	m_recordBroken=true;
	double prebestllvalue=0.0;
	double postbestllvalue=0.0;
	ofstream & outfileUpdatePoints=Report::getReport()->getUpdatePointsStream();
	while(m_recordBroken){
		m_recordBroken=false;
		prebestllvalue=m_MC_A.getBestLHvalue();
		while(m_llCurStep<=m_llMaxIter){
			//cout<<"5"<<endl;
			//if(m_curStep%1000==0)
				//cout<<"step #: "<<m_curStep<<endl;
			runOneStep(true);
			m_llCurStep++;
			//cout<<"6"<<endl;
		}
		postbestllvalue=m_MC_A.getBestLHvalue();
		if(postbestllvalue-prebestllvalue>0.001){
			m_llMaxIter+=10*m_numVtx;
			m_recordBroken=true;
			outfileUpdatePoints<<this->m_llCurStep<<"\t"<<postbestllvalue-prebestllvalue<<endl;
		}

	}
	//ofstream & outfileTypeMatrix=Report::getReport()->getTypematrixStream();
	//outfileTypeMatrix<<"current init: "<<m_curInit<<'\t'<<"max step number: "<<maxstep<<endl;
}

void ScalingTestAlg::runOneStep(bool bLearnerOn){	
	unsigned mutateVtxNo;
	unsigned sourceType;
	unsigned targetType;
	//typeModelA	
	do{
		mutateVtxNo=getRandRemainVtx();
		sourceType=m_typeModelA.m_vtxTypeTable[mutateVtxNo];
	}while(m_typeModelA.m_groupCardiTable[sourceType]==1);
	targetType=m_MC_A.getTargetType(mutateVtxNo);
#ifdef Debug
	cout<<"Type Model A (before mutation):"<<endl;
	m_typeModelA.showModelInfo();
	cout<<"mutateVtxNo:  "<<mutateVtxNo<<"\t"<<"targetType:  "<<targetType<<endl;
	showLHVari();
#endif
	m_MC_A.mutateTypeModel(mutateVtxNo,targetType);
#ifdef Debug
	cout<<"Type Model A (after mutation):"<<endl;
	m_typeModelA.showModelInfo();
#endif
	/*if((m_curInit<=m_numOptInit)&&(m_curStep>stabRatio*double(m_numOptStep))&&(m_curStep<=m_numOptStep)){
		updateAccuracyNum(m_typeModelA);
	}*/
	//


	if(!bLearnerOn)
		this->m_MC_A.updateBestTypeModel();
	else{
		updateAccumuMargDistri(mutateVtxNo,m_MC_A);	
		this->m_MC_A.updateGroupConnMatrix();	
		this->m_MC_A.updateVtxClassifiMatrix();		
		this->m_MC_A.updateBestTypeModel();
		//m_dSumLHvalueInPhase+=m_MC_A.getLHvalue();
		//this->m_lNumLHvalueInPhase++;
	}

	//typeModelB	
	do{
		mutateVtxNo=getRandRemainVtx();
		sourceType=m_typeModelB.m_vtxTypeTable[mutateVtxNo];
	}while(m_typeModelB.m_groupCardiTable[sourceType]==1);
	targetType=m_MC_B.getTargetType(mutateVtxNo);
#ifdef Debug
	cout<<"Type Model B (before mutation):"<<endl;
	m_typeModelB.showModelInfo();
	cout<<"mutateVtxNo:  "<<mutateVtxNo<<"\t"<<"targetType:  "<<targetType<<endl;
	showLHVari();
#endif
	m_MC_B.mutateTypeModel(mutateVtxNo,targetType);
#ifdef Debug
	cout<<"Type Model B (after mutation):"<<endl;
	m_typeModelB.showModelInfo();
#endif
	/*if((m_curInit<=m_numOptInit)&&(m_curStep>stabRatio*double(m_numOptStep))&&(m_curStep<=m_numOptStep)){
		updateAccuracyNum(m_typeModelB);		
	}*/
	//

	if(!bLearnerOn)
		this->m_MC_B.updateBestTypeModel();
	else{
		updateAccumuMargDistri(mutateVtxNo,m_MC_B);	
		this->m_MC_B.updateGroupConnMatrix();
		this->m_MC_B.updateVtxClassifiMatrix();	
		this->m_MC_B.updateBestTypeModel();
		//m_dSumLHvalueInPhase+=m_MC_B.getLHvalue();
		//this->m_lNumLHvalueInPhase++;
	}

	//
	if(bLearnerOn){
		m_learner->updateData();				
	}
}
int ScalingTestAlg::getRandRemainVtx(){
	unsigned index=randN(m_remainVtxSet.size());
	set<unsigned>::iterator setiter=m_remainVtxSet.begin();
	for(unsigned i=0;i<index;i++)
		setiter++;
	return *setiter;
}

void ScalingTestAlg::getTopVtx(){
	unsigned i;
	unsigned * arrayTop=new unsigned[m_numVtx];//may output more than "m_numTop" vertices
	unsigned numtop=m_learner->getTopVtx(arrayTop, m_numTop);	
	for(i=0;i<numtop;i++){
		m_topVtxSet.insert(arrayTop[i]);
		m_remainVtxSet.erase(arrayTop[i]);
		m_topVtxSeq.push_back(arrayTop[i]);
	}
	delete [] arrayTop;
}

/*void ScalingTestAlg::initAccuracyNum(){
	for(unsigned i=0;i<=m_numVtx;i++)
		m_accuracyNum[i]=0l;
}
void ScalingTestAlg::updateAccuracyNum(TypeModel& typeModel){
	for(unsigned i=0;i<m_numVtx;i++){
		if(typeModel.getVtxType(i)==typeModel.getGraph().vtxList[i].getType())
			m_accuracyNum[i]++;
	}
	m_accuracyNum[m_numVtx]++;
}
void ScalingTestAlg::initPhaseAccuracyMatrix(){
	for(unsigned i=0;i<m_numPhase;i++)
		for(unsigned j=0;j<numAccuracyBlock;j++)
			m_phaseAccuracyMatrix[i][j]=0.0;
}
void ScalingTestAlg::updatePhaseAccuracyMatrix(){
	unsigned i;
	double accuracyRatio;
	long numsteps=m_accuracyNum[m_numVtx];
	for(i=0;i<m_numVtx;i++){
		accuracyRatio=(double)(m_accuracyNum[i])/(double)(numsteps);
		unsigned blockNo=(unsigned)(accuracyRatio*numAccuracyBlock);
		if(blockNo==numAccuracyBlock)
			blockNo=numAccuracyBlock-1;
		m_phaseAccuracyMatrix[m_curPhase-1][blockNo]++;
	}
	for(i=0;i<numAccuracyBlock;i++){
		m_phaseAccuracyMatrix[m_curPhase-1][i]/=m_numVtx;
	}
}*/

void ScalingTestAlg::writeTopVtxSeq(){
	unsigned i;
	ofstream & outfile=Report::getReport()->getTopvtxseqStream();
	outfile<<"Top Vtx Sequence (No):\n";
	for(i=0;i<m_topVtxSeq.size();i++){
		outfile<<m_topVtxSeq[i]/*m_typeModel.getGraph().vtxList[m_topVtxSeq[i]].getId()*/<<"\t";		
	}
	outfile<<endl;
	outfile<<"Top Vtx Sequence (Id):\n";
	for(i=0;i<m_topVtxSeq.size();i++){
		outfile<<m_graph.getVertex(m_topVtxSeq[i]).getId()/*m_typeModel.getGraph().vtxList[m_topVtxSeq[i]].getId()*/<<"\t";		
	}
	outfile<<endl;
	outfile<<"Top Vtx Sequence (Type):\n";
	for(i=0;i<m_topVtxSeq.size();i++){
		outfile<<m_graph.getVertex(m_topVtxSeq[i]).getType()/*m_typeModel.getGraph().vtxList[m_topVtxSeq[i]].getId()*/<<"\t";		
	}
	outfile<<endl;
	outfile<<"Top Vtx Sequence (Value):\n";
	for(i=0;i<m_topVtxSeq.size();i++){
		outfile<<m_graph.getVertex(m_topVtxSeq[i]).getValue()/*m_typeModel.getGraph().vtxList[m_topVtxSeq[i]].getId()*/<<"\t";		
	}
	outfile<<endl<<endl;
}

/*void ScalingTestAlg::writePhaseAccuracyMatrix(){
	ofstream & outfile=Report::getReport()->getAccuracymatrixStream();
	outfile<<"phase accuracy matrix:"<<endl;
	for(unsigned i=0;i<m_numPhase;i++){
		for(unsigned j=0;j<numAccuracyBlock;j++){
			outfile<<m_phaseAccuracyMatrix[i][j]<<"\t";
		}
	}	
	outfile<<endl<<endl;
	outfile.close();
}*/

void ScalingTestAlg::initAccumuMargDistri(){
	unsigned i,j;
	for(i=0;i<m_numVtx;i++){
		for(j=0;j<m_numTypeModel;j++){
			m_accumuMargDistri[i][j]=0.0;
		}
	}
}
void ScalingTestAlg::updateAccumuMargDistri(unsigned mutatevtxno, MCMC & mcmc){
	unsigned i;
	const vector<pair<unsigned,double> >& lhvaripairs=mcmc.getLHVariPairs();
	for(i=0;i<lhvaripairs.size();i++){		
		m_accumuMargDistri[mutatevtxno][lhvaripairs[i].first]+=lhvaripairs[i].second;
	}
}

void ScalingTestAlg::checkTypeFixed(){
	if(!m_alltypefixed){
		unsigned type;
		set <unsigned> m_knownTypes;
		set<unsigned>::const_iterator csiiter=m_topVtxSet.begin();
		for(;csiiter!=m_topVtxSet.end();csiiter++){
			//m_typeModelA.m_graph.printGraph();
			type=m_graph.getVertex(*csiiter).getType();
			m_knownTypes.insert(type);
		}
		if(m_knownTypes.size()>=m_numTypeGraph-1){
			cout<<"the phase that all types are fixed:  "<<m_curPhase<<endl;
			m_alltypefixed=true;
		}
	}
}

void ScalingTestAlg::initAccuracyMatrix(){
	unsigned i,j;
	m_accuracyMatrix=new double * [numAccuracyBlock-1];
	for(i=0;i<numAccuracyBlock-1;i++)
		m_accuracyMatrix[i]=new double[m_numPhase];
	for(i=0;i<numAccuracyBlock-1;i++)
		for(j=0;j<m_numPhase;j++)
			m_accuracyMatrix[i][j]=0.0;
}

void ScalingTestAlg::updateAccuracyMatrix(){
	unsigned i;
	unsigned vtxno;
	unsigned realtype;
	double accuracyvalue;
	unsigned count=0;
	double accuracyRatio=1.0/numAccuracyBlock;
	for(vtxno=0;vtxno<m_numVtx;vtxno++){
		if(m_topVtxSet.count(vtxno))
			continue;
		realtype=m_typeModelA.getGraph().getVertex(vtxno).getType();
		accuracyvalue=m_accumuMargDistri[vtxno][realtype];
		for(i=1;i<numAccuracyBlock;i++){
			if(accuracyvalue>=accuracyRatio*i){
				m_accuracyMatrix[i-1][m_curPhase-1]++;				
			}else break;
		}
		count++;
	}
	for(i=1;i<numAccuracyBlock;i++){
		m_accuracyMatrix[i-1][m_curPhase-1]/=(double)count;
	}
}

void ScalingTestAlg::writeAccuracyMatrix(){
	unsigned i,j;
	ofstream & accuracymtxfile=Report::getReport()->getAccuracymatrixStream();
	for(i=0;i<numAccuracyBlock-1;i++){
		for(j=0;j<m_curPhase-2;j++){
			accuracymtxfile<<m_accuracyMatrix[i][j]<<" ";
		}
		accuracymtxfile<<m_accuracyMatrix[i][j]<<endl<<endl;
	}	
}
